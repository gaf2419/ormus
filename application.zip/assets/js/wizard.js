(function ($) {
    'use strict';
    var form = $("#wizard-form");
	if(form.hasClass('no-finish')){
		//enableFinishButton
		form.children("div").steps({
			headerTag: "h3",
			bodyTag: "section",
			labels: {
				cancel: "Regresar",
				current: "paso actual:",
				pagination: "Paginacion",
				finish: "Terminar",
				next: "Siguiente",
				previous: "Anterior",
				loading: "Cargando ..."
			},
			enableCancelButton: true,
			enableFinishButton: false,
			transitionEffect: "slideLeft",
			onCanceled: function (event) {
				location.href=form.data('prevweb');
			},
			onFinished: function (event, currentIndex) {
				form.submit();
			}
		});
	} else {
		form.children("div").steps({
			headerTag: "h3",
			bodyTag: "section",
			labels: {
				cancel: "Cancelar",
				current: "paso actual:",
				pagination: "Paginacion",
				finish: "Terminar",
				next: "Siguiente",
				previous: "Anterior",
				loading: "Cargando ..."
			},
			enableCancelButton: true,
			transitionEffect: "slideLeft",
			onCanceled: function (event) {
				location.href=form.data('prevweb');
			},
			onFinished: function (event, currentIndex) {
				form.submit();
			}
		});
	}
	
    var validationForm = $("#example-validation-form");
    validationForm.val({
        errorPlacement: function errorPlacement(error, element) {
            element.before(error);
        },
        rules: {
            confirm: {
                equalTo: "#password"
            }
        }
    });
    validationForm.children("div").steps({
        headerTag: "h3",
        bodyTag: "section",
        transitionEffect: "slideLeft",
        onStepChanging: function (event, currentIndex, newIndex) {
            validationForm.val({
                ignore: [":disabled",":hidden"]
            })
            return validationForm.val();
        },
        onFinishing: function (event, currentIndex) {
            validationForm.val({
                ignore: [':disabled']
            })
            return validationForm.val();
        },
        onFinished: function (event, currentIndex) {
            alert("Submitted!");
        }
    });
    var verticalForm = $("#example-vertical-wizard");
    verticalForm.children("div").steps({
        headerTag: "h3",
        bodyTag: "section",
        transitionEffect: "slideLeft",
        stepsOrientation: "vertical",
        onFinished: function (event, currentIndex) {
            alert("Submitted!");
        }
    });
})(jQuery);
