(function($) {
  'use strict';
  $('.dropify').dropify({
	messages: {
        'default': 'Arrastra y suelta un archivo aquí o haz clic',
        'replace': 'Arrastre y suelte o haga clic para reemplazar',
        'remove':  'Eliminar',
        'error':   'Vaya, sucedió algo malo.'
    }
  });
})(jQuery);
