(function(window, document, $) {
    'use strict';
	$(window).on('load', function() {
		if($('.btn-procesar-inicio-caja-fss').length > 0){
			$('.btn-procesar-inicio-caja-fss').on('click', function(event){
				event.preventDefault();
				var url = $(this).data('urlform');
				url = url + '/ad_inicio_caja';
				$.post(url, {
					valor: $('.inp-ini-valor').val()
				}, function (data) {
					if(data == 'ok'){
						$('.forms-sample-close-caja').fadeOut();
						$('.forms-sample-close-caja').html('<div class="alert alert-fill-success" role="alert">En hora buena!!! Su inicio de caja ha sido guardado correctamente.</div>');
						$('.forms-sample-close-caja').fadeIn();
						setInterval(function(){ location.reload(); }, 3000);
					} else {
						alert(data);
					}
				}, "html");
			});
		}
		if($('.btn-procesar-cierre-caja-fss').length > 0){
			$('.btn-procesar-cierre-caja-fss').on('click', function(event){
				event.preventDefault();
				var url = $(this).data('urlform');
				url = url + '/ad_cierre_caja';
				$.post(url, {
					cincuenta: $('.inp-cierre-cincuenta').val(),
					cien: $('.inp-cierre-cien').val(),
					doscientos: $('.inp-cierre-doscientos').val(),
					quinientos: $('.inp-cierre-quinientos').val(),
					mil: $('.inp-cierre-mil').val(),
					dosmil: $('.inp-cierre-dosmil').val(),
					cincomil: $('.inp-cierre-cincomil').val(),
					diezmil: $('.inp-cierre-diezmil').val(),
					veintemil: $('.inp-cierre-veintemil').val(),
					cincuentamil: $('.inp-cierre-cincuentamil').val(),
					cienmil: $('.inp-cierre-cienmil').val()
				}, function (data) {
					$('.shw_cerrado_caja').html('Cerrado: '+data);
					$('.btn-procesar-cierre-caja-fss').fadeOut();
					$('.forms-sample-close-caja .msj-succ').html('<div class="alert alert-fill-success" role="alert">En hora buena!!! Su cierre de caja ha sido procesado correctamente.</div>');
					$('.form-control').attr('disabled','disabled');
					//setInterval(function(){ $('.forms-sample-close-caja .msj-succ').html(''); }, 5000);
					setInterval(function(){ location.reload(); }, 3000);
				}, "html");
			});
		}
	});
	$(document).ready(function(){
	});
})(window, document, jQuery);