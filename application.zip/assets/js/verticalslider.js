(function(window, document, $) {
    'use strict';
	$(window).on('load', function() {
	});
	$(document).ready(function(){
		if($('#myCarousel_vertical').length > 0){
			$('#myCarousel_vertical').carousel({
				interval: false
			});
			$('.small-thumbnail img').click(function (e) {
				e.preventDefault();
				$('#DataDisplay').attr("src", $(this).attr("data-display"));
			});
		}
		
	});
})(window, document, jQuery);