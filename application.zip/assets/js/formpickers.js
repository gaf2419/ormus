(function($) {
  'use strict';
  if ($(".clockpicker").length) {
    $('.clockpicker').clockpicker({
		autoclose: true
    });
  }
  if ($(".color-picker").length) {
    $('.color-picker').asColorPicker();
  }
  if ($("#datepicker-popup").length) {
	  var currDate = new Date();
    $('#datepicker-popup').datepicker({
      enableOnReadonly: true,
      todayHighlight: true,
      format: 'yyyy-mm-dd',
	  language: 'es',
	  startDate : currDate,
	  autoclose: true
    });
  }
  if ($(".datepicker-popup").length) {
	  var currDate = new Date();
    $('.datepicker-popup').datepicker({
      enableOnReadonly: true,
      todayHighlight: true,
      format: 'yyyy-mm-dd',
	  language: 'es',
	  startDate : currDate,
	  autoclose: true
    });
  }
  if ($("#datepicker-mesyear").length) {
	  var currDate = new Date();
    $('#datepicker-mesyear').datepicker({
      enableOnReadonly: true,
      todayHighlight: true,
      format: 'yyyy-mm',
	  language: 'es',
	  minViewMode: 1,
	  endDate : currDate,
	  autoclose: true
    });
  }
  if ($("#inline-datepicker").length) {
    $('#inline-datepicker').datepicker({
      enableOnReadonly: true,
      todayHighlight: true,
    });
  }
  if ($(".datepicker-autoclose").length) {
    $('.datepicker-autoclose').datepicker({
      autoclose: true
    });
  }
  if ($('input[name="date-range"]').length) {
    $('input[name="date-range"]').daterangepicker();
  }
  if ($('input[name="date-time-range"]').length) {
    $('input[name="date-time-range"]').daterangepicker({
      timePicker: true,
      timePickerIncrement: 30,
      locale: {
        format: 'MM/DD/YYYY h:mm A'
      }
    });
  }
  if ($("#event_period").length) {
    $('#event_period').datepicker({
		format: 'yyyy-mm-dd',
		autoclose: true,
		toggleActive: true,
		todayHighlight: true,
		endDate: '0d',
		inputs: $('.actual_range'),
		language: 'es'
	});
  }
})(jQuery);
