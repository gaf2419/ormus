(function($) {
    'use strict';
    /*$.validator.setDefaults({
        submitHandler: function() {
            alert("submitted!");
        }
    });*/
    $(function() {
        // validate the forms whit class .form-to-validate
        $(".form-to-validate").validate({
          errorPlacement: function(label, element) {
            label.addClass('mt-2 text-danger');
            label.insertAfter(element);
          },
          highlight: function(element, errorClass) {
            $(element).parent().addClass('has-danger')
            $(element).addClass('form-control-danger')
          }
        });		
		// validate the forms whit class .form-to-validate-2
        $(".form-to-validate-2").validate({
          errorPlacement: function(label, element) {
            label.addClass('mt-2 text-danger');
            label.insertAfter(element);
          },
          highlight: function(element, errorClass) {
            $(element).parent().addClass('has-danger')
            $(element).addClass('form-control-danger')
          }
        });		
		// validate the forms whit class .form-to-validate-3
        $(".form-to-validate-3").validate({
          errorPlacement: function(label, element) {
            label.addClass('mt-2 text-danger');
            label.insertAfter(element);
          },
          highlight: function(element, errorClass) {
            $(element).parent().addClass('has-danger')
            $(element).addClass('form-control-danger')
          }
        });
    });
})(jQuery);
