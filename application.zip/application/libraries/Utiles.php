<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Utiles {

    protected $CI;

    public function __construct(){
        $this->CI =& get_instance();
    }

	public function encrypt_clave($string, $key='') {
		$k = $key;
		if(empty($key)){
			$k = '65245787345344354';
		}
		$result = '';
		for($i=0; $i<strlen($string); $i++) {
			$char = substr($string, $i, 1);
			$keychar = substr($k, ($i % strlen($k))-1, 1);
			$char = chr(ord($char)+ord($keychar));
			$result.=$char;
		}
		return base64_encode($result);
	}

	public function decrypt_clave($string, $key='') {
		$k = $key;
		if(empty($key)){
			$k = '65245787345344354';
		}
		$result = '';
		$string = base64_decode($string);
		for($i=0; $i<strlen($string); $i++) {
			$char = substr($string, $i, 1);
			$keychar = substr($k, ($i % strlen($k))-1, 1);
			$char = chr(ord($char)-ord($keychar));
			$result.=$char;
		}
		return $result;
	}

    function fss_enc($cadena){
        $key='65245787345344354';
        $encrypted = base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($key), $cadena, MCRYPT_MODE_CBC, md5(md5($key))));
        return $encrypted;

    }

    function fss_des($cadena){
        $key='65245787345344354';
        $decrypted = rtrim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, md5($key), base64_decode($cadena), MCRYPT_MODE_CBC, md5(md5($key))), "\0");
        return $decrypted;
    }

	public function gcode($t,$f,$l=''){
		$chs = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$e=true;
		$c="";
		if(empty($l)){
			$l = 8;
		}
		while($e){
			$randstring = '';
			for ($i = 0; $i < $l; $i++) {
				$randstring .= $chs[rand(0, strlen($chs)-1)];
			}
			$c=md5($randstring);
			$obj=$this->CI->default_model->default_get_one_where($t, array($f => $c));
			if(empty($obj)){
				$e=false;
			}
		}
		return $c;
	}

	public function gcode_simple($t,$f,$l=''){
		$chs = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$e=true;
		$c="";
		if(empty($l)){
			$l = 8;
		}
		while($e){
			$randstring = '';
			for ($i = 0; $i < $l; $i++) {
				$randstring .= $chs[rand(0, strlen($chs)-1)];
			}
			$c=$randstring;
			$obj=$this->CI->default_model->default_get_one_where($t, array($f => $c));
			if(empty($obj)){
				$e=false;
			}
		}
		return $c;
	}

	public function g_clave($l=''){
		$chs = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		if(empty($l)){
			$l = 8;
		}
		$r = '';
		for ($i = 0; $i < $l; $i++) {
			$r .= $chs[rand(0, strlen($chs)-1)];
		}
		return $r;
	}

	public function is_url_fss($url=''){
		$pattern = "|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i";
		//$pattern = "/^((ht|f)tp(s?)\:\/\/|~/|/)?([w]{2}([\w\-]+\.)+([\w]{2,5}))(:[\d]{1,5})?/";
		if(empty($url)){
			return false;
		} else {
			return preg_match($pattern, $url)==1;
		}
	}

	public function get_id_tube_fss($url=''){
		$arr_url = explode("/",$url);
		$url_c = count($arr_url);
		$url_v = $arr_url[$url_c-1];
		return $url_v;
	}
	
	function get_youtube_id_from_url($url) {
		preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $url, $match);
		$youtube_id = $match[1];
		return $youtube_id;
	}
	
	function date_avanced_fss($d) {
		$f = date('Y-m-j');
		$fn = strtotime('+'.$d.' day',strtotime($f));
		$fn = date('Y-m-d',$fn);
		return $fn;
    }
	
	public function mail_fss($email_to, $name_to, $subject, $body, $uploadfile = ''){
		$this->CI->load->library('email');
		$configFss = array(
		'protocol' => 'smtp',
		'smtp_host' => 'ssl://test.fullstackcolombia.tk',
		'smtp_port' => 465,
		'smtp_user' => 'info@test.fullstackcolombia.tk',
		'smtp_pass' => '1q2w3e4r5t*',
		'mailtype' => 'html',
		'charset' => 'utf-8',
		'newline' => "\r\n");
		$this->CI->email->initialize($configFss);
		$this->CI->email->from('info@test.fullstackcolombia.tk', 'Bordados Ormu');
		$this->CI->email->to($email_to);
		$this->CI->email->subject($subject);
		$this->CI->email->message($body);
		if(!empty($uploadfile)){
			$this->CI->email->attach($uploadfile);
		}
		$this->CI->email->send();
	}

	public function porciento($t,$p) {
		$x = ($t*$p)/100;
        return $x;
    }
}