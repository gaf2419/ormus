<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Test_default_tables extends CI_Model {

    function __construct() {
        parent::__construct();
    }

	private function encrypt_clave($string, $key) {
		$result = '';
		for($i=0; $i<strlen($string); $i++) {
			$char = substr($string, $i, 1);
			$keychar = substr($key, ($i % strlen($key))-1, 1);
			$char = chr(ord($char)+ord($keychar));
			$result.=$char;
		}
		return base64_encode($result);
	}

    function default_tables_test() {
        //mysql
        if (!($this->db->table_exists('usuario'))) {
			//usuario --- id_usuario,nombre,apellido,username,email,foto,password,rol,estado,telefono_empresa,direccion,cedula,telefono,empresa,nit,tipo_precio,is_sucursal,sucursal
            $sql = "CREATE TABLE IF NOT EXISTS `usuario` (`id_usuario` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`nombre` varchar(80), `apellido` varchar(80), `username` varchar(80),`email` varchar(80),`foto` text,`password` text,`rol` varchar(50),`estado` varchar(50),`telefono_empresa` varchar(80),`direccion` text,`cedula` varchar(80),`telefono` varchar(80),`empresa` varchar(180),`nit` varchar(80),`tipo_precio` Integer,`is_sucursal` varchar(50),`sucursal` Integer,UNIQUE KEY `id_usuario` (`id_usuario`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('producto'))) {
			//producto --- id_producto,nombre,descripcion,precio1,precio2,precio3,precio4,codigo,costo,cantidad,estado
            $sql = "CREATE TABLE IF NOT EXISTS `producto` (`id_producto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`nombre` varchar(250),`descripcion` text,`precio1` float,`precio2` float,`precio3` float,`precio4` float,`codigo` varchar(280),`costo` float,`cantidad` Integer,`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_producto` (`id_producto`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('categoria_producto'))) {
			//categoria_producto --- id_categoria_producto,nombre,descripcion,tipo,bordados,maquina,estado
            $sql = "CREATE TABLE IF NOT EXISTS `categoria_producto` (`id_categoria_producto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`nombre` varchar(250),`descripcion` text,`tipo` varchar(80),`bordados` text,`maquina` Integer,`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_categoria_producto` (`id_categoria_producto`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('bordado'))) {
			//bordado --- id_bordado,nombre,descripcion,precio1,precio2,precio3,precio4,alto,ancho,foto,estado
            $sql = "CREATE TABLE IF NOT EXISTS `bordado` (`id_bordado` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`nombre` varchar(250),`descripcion` text,`precio1` float,`precio2` float,`precio3` float,`precio4` float,`alto` varchar(80),`ancho` varchar(80),`foto` varchar(80),`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_bordado` (`id_bordado`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('maquina'))) {
			//maquina --- id_maquina,nombre,descripcion,calendario,capacidad,estado
            $sql = "CREATE TABLE IF NOT EXISTS `maquina` (`id_maquina` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`nombre` varchar(250),`descripcion` text,`calendario` varchar(80),`capacidad` varchar(80),`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_maquina` (`id_maquina`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('sucursal'))) {
			//sucursal --- id_sucursal,nombre,direccion,usuario,modulos,estado
            $sql = "CREATE TABLE IF NOT EXISTS `sucursal` (`id_sucursal` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`nombre` varchar(250),`direccion` text,`usuario` Integer,`modulos` text,`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_sucursal` (`id_sucursal`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('categoria'))) {
			//categoria --- id_categoria,nombre,descripcion,estado
            $sql = "CREATE TABLE IF NOT EXISTS `categoria` (`id_categoria` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`nombre` varchar(250),`descripcion` text,`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_categoria` (`id_categoria`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('ingreso'))) {
			//ingreso --- id_ingreso,nombre,producto,descripcion,cantidad,factura,total,fecha,estado
            $sql = "CREATE TABLE IF NOT EXISTS `ingreso` (`id_ingreso` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`nombre` varchar(250),`producto` Integer,`descripcion` text,`cantidad` Integer,`factura` varchar(80),`total` float,`fecha` varchar(80),`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_ingreso` (`id_ingreso`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('ajuste'))) {
			//ajuste --- id_ajuste,codigo,nombre,producto,cantidad,total,fecha,estado
            $sql = "CREATE TABLE IF NOT EXISTS `ajuste` (`id_ajuste` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`codigo` varchar(250),`nombre` varchar(250),`producto` Integer,`cantidad` Integer,`total` float,`fecha` varchar(80),`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_ajuste` (`id_ajuste`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('gasto'))) {
			//gasto --- id_gasto,nombre,descripcion,categoria,fecha,total,estado
            $sql = "CREATE TABLE IF NOT EXISTS `gasto` (`id_gasto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`nombre` varchar(250),`descripcion` text,`categoria` Integer,`fecha` varchar(80),`total` float,`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_gasto` (`id_gasto`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		
		if (!($this->db->table_exists('color'))) {
			//color --- id_color,nombre,foto,estado
            $sql = "CREATE TABLE IF NOT EXISTS `color` (`id_color` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`nombre` varchar(250),`foto` varchar(80),`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_color` (`id_color`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		
		if (!($this->db->table_exists('pedido'))) {
			//pedido --- id_pedido,codigo,usuario,tipo_precio,bordados,fecha_entrega,pago,costo,abonado,estado
            $sql = "CREATE TABLE IF NOT EXISTS `pedido` (`id_pedido` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`codigo` varchar(80),`usuario` Integer,`tipo_precio` Integer,`bordados` text,`fecha_entrega` varchar(80),`pago` varchar(80),`costo` float,`abonado` float,`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_pedido` (`id_pedido`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('pedido_bordado'))) {
			//pedido_bordado --- id_pedido_bordado,pedido,bordado,colores,cantidad,unidad_medida,radio,observaciones,obs_dissg,puntadas,realizadas,estado
            $sql = "CREATE TABLE IF NOT EXISTS `pedido_bordado` (`id_pedido_bordado` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`pedido` Integer,`bordado` Integer,`colores` text,`cantidad` Integer,`unidad_medida` varchar(50),`radio` varchar(50),`observaciones` text,`obs_dissg` text,`puntadas` float,`realizadas` Integer,`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_pedido_bordado` (`id_pedido_bordado`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('pedido_tipo_bordado'))) {
			//pedido_tipo_bordado --- id_pedido_tipo_bordado,pedido,bordado,tipo_bordado,nombre,alto,ancho,estado
            $sql = "CREATE TABLE IF NOT EXISTS `pedido_tipo_bordado` (`id_pedido_tipo_bordado` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`pedido` Integer,`bordado` Integer,`tipo_bordado` Integer,`nombre` varchar(80),`alto` varchar(80),`ancho` varchar(80),`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_pedido_tipo_bordado` (`id_pedido_tipo_bordado`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('pedido_archivo'))) {
			//pedido_archivo --- id_pedido_archivo,pedido,bordado,archivo,estado
            $sql = "CREATE TABLE IF NOT EXISTS `pedido_archivo` (`id_pedido_archivo` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`pedido` Integer,`bordado` Integer,`archivo` varchar(80),`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_pedido_archivo` (`id_pedido_archivo`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('pedido_archivo_extra'))) {
			//pedido_archivo_extra --- id_pedido_archivo_extra,pedido,bordado,archivo,estado
            $sql = "CREATE TABLE IF NOT EXISTS `pedido_archivo_extra` (`id_pedido_archivo_extra` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`pedido` Integer,`bordado` Integer,`archivo` varchar(80),`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_pedido_archivo_extra` (`id_pedido_archivo_extra`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('pedido_archivo_disgg'))) {
			//pedido_archivo_disgg --- id_pedido_archivo_disgg,pedido,bordado,archivo,estado
            $sql = "CREATE TABLE IF NOT EXISTS `pedido_archivo_disgg` (`id_pedido_archivo_disgg` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`pedido` Integer,`bordado` Integer,`archivo` varchar(80),`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_pedido_archivo_disgg` (`id_pedido_archivo_disgg`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('pedido_reporte'))) {
			//pedido_reporte --- id_pedido_reporte,pedido,bordado,archivo,estado
            $sql = "CREATE TABLE IF NOT EXISTS `pedido_reporte` (`id_pedido_reporte` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`pedido` Integer,`bordado` Integer,`archivo` varchar(80),`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_pedido_reporte` (`id_pedido_reporte`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('pedido_abono'))) {
			//pedido_abono --- id_pedido_abono,pedido,abono,fecha,estado
            $sql = "CREATE TABLE IF NOT EXISTS `pedido_abono` (`id_pedido_abono` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`pedido` Integer,`abono` float,`fecha` varchar(80),`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_pedido_abono` (`id_pedido_abono`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('venta'))) {
			//venta --- id_venta,factura,productos,cantidades,cliente,vendedor,total,fecha,estado
            $sql = "CREATE TABLE IF NOT EXISTS `venta` (`id_venta` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`factura` varchar(200),`productos` text,`cantidades` text,`cliente` Integer,`vendedor` Integer,`total` float,`fecha` varchar(80),`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_venta` (`id_venta`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		if (!($this->db->table_exists('box_xax'))) {
			//box_xax   ---  id_box_xax,usuario,cincuenta,cien,doscientos,quinientos,mil,dosmil,cincomil,diezmil,veintemil,cincuentamil,cienmil,entrada,salida,vendido,descuadre,fecha,inicio,cierre,estado_caja,estado
            $sql = "CREATE TABLE IF NOT EXISTS `box_xax` (`id_box_xax` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`usuario` Integer,`cincuenta` Integer,`cien` Integer,`doscientos` Integer,`quinientos` Integer,`mil` Integer,`dosmil` Integer,`cincomil` Integer,`diezmil` Integer,`veintemil` Integer,`cincuentamil` Integer,`cienmil` Integer,`entrada` float,`salida` float,`vendido` float,`descuadre` float,`fecha` varchar(80),`inicio` varchar(80),`cierre` varchar(80),`estado_caja` varchar(80),`estado` varchar(80),`created_at` timestamp NOT NULL DEFAULT now(),UNIQUE KEY `id_box_xax` (`id_box_xax`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
        }
		
		/*if (!($this->db->table_exists('epayco_fss'))) {
			//epayco_fss --- id_epayco_fss,public_key,p_key,p_cust_id_cliente,moneda,test
            $sql = "CREATE TABLE IF NOT EXISTS `epayco_fss` (`id_epayco_fss` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`public_key` varchar(300),`p_key` varchar(300),`p_cust_id_cliente` varchar(300),`moneda` varchar(50),`test` varchar(50),UNIQUE KEY `id_epayco_fss` (`id_epayco_fss`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
			$values = array('public_key' => '382c096da3f1534fc1af6f0d62361710','p_key' => '1897ccc8f9ac215a76007312c996d7ab96334088','p_cust_id_cliente' => '19473','moneda' => 'cop','test' => 'true');
			$this->default_model->default_insert_one("epayco_fss", $values);
        }*/
        //end mysql
        //Default query

		//Usuarios fields
        if ($this->default_model->default_count_all_elements('usuario') == 0) {
			//usuario --- id_usuario,nombre,apellido,username,email,foto,password,rol,estado,telefono_empresa,direccion,cedula,telefono,empresa,nit,tipo_precio
			$values = array('nombre' => 'Super Admin', 'apellido' => 'Administrator', 'username' => 'admin_ormu_fss', 'email' => 'admin_ormu_fss@fullstackcolombia.tk', 'password' => md5('admin'), 'rol' => 'administrator', 'estado' => 'activo');
            $this->default_model->default_insert_one("usuario", $values);
			$values = array('nombre' => 'Admin', 'apellido' => 'Administrator', 'username' => 'admin_ormu', 'email' => 'admin_ormu@bordadosormu.com.co', 'password' => md5('admin'), 'rol' => 'administrator', 'estado' => 'activo');
            $this->default_model->default_insert_one("usuario", $values);
        }
    }

}
