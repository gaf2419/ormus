<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Default_model extends CI_Model {

	function __construct() {
		$this->load->database();
        //parent::__construct();
    }

    function default_get_one_where($table_default, $conditions) {
        return $this->db->get_where($table_default, $conditions)->row();
    }
	
    function default_get_one_where_row_array($table_default, $conditions) {
        return $this->db->get_where($table_default, $conditions)->row_array();
    }

    function default_get_all_where($default_table, $default_array_condition) {
        return $this->db->get_where($default_table, $default_array_condition);
    }
	
	function default_get_all_or_where($default_table, $where_condition, $or_condition) {
        return $this->db->where($where_condition)->or_where($or_condition)->get($default_table)->row();
    }
	function default_get_all_or_where_items($default_table, $where_condition, $or_condition) {
        return $this->db->where($where_condition)->or_where($or_condition)->get($default_table);
    }
	
	function default_get_all_where_limit($default_table, $default_array_condition, $limit) {
        return $this->db->get_where($default_table, $default_array_condition, $limit);
    }
	
	function default_get_all_where_limit_s_e($t, $c, $s,$e) {
        $this->db->select('*')->from($t)->where($c);
		$this->db->limit($s, $e);
		return $this->db->get($t);
		//return $this->db->limit($s, $e)->get_where($t, $c);
    }

    function default_get_all_where_order_by($default_table, $orderby, $default_array_condition) {
        return $this->db->select("*")->order_by($orderby)->get_where($default_table, $default_array_condition);
    }

    function default_get_all_where_order_by_not_in($default_table, $orderby, $default_array_condition,$f,$w) {
        return $this->db->select("*")->where_not_in($f, $w)->order_by($orderby)->get_where($default_table, $default_array_condition);
    }

    function default_get_all_where_order_by_limit($t, $orderby, $w,$l) {
        return $this->db->select("*")->order_by($orderby)->get_where($t, $w,$l);
    }

    function default_get_all_where_order_by_limit_s_e($t, $orderby, $w,$l,$e) {
        return $this->db->select("*")->order_by($orderby)->get_where($t, $w,$l,$e);
    }
    
    function default_get_sum_where($default_table, $field, $default_array_condition) {
        return $this->db->select_sum($field)->get_where($default_table, $default_array_condition);
    }
    
    function default_get_all_group_by($default_table, $limit) {
        return $this->db->select("*")->order_by('created_at desc')->get($default_table, $limit);
    }
	
	function default_get_all_order_by_desc_limit($t, $f, $l) {
        return $this->db->select("*")->order_by($f.' desc')->get($t, $l);
    }
	function default_get_all_where_order_by_desc_limit($t, $w, $f, $l, $o='') {
        $asc = empty($o)?'DESC':$o;
		return $this->db->select("*")->order_by($f.' '.$asc)->get_where($t, $w, $l);
    }
    
    function default_get_all_where_group_by($default_table, $default_conditions, $limit) {
        return $this->db->select("*")->order_by('created_at desc')->get_where($default_table, $default_conditions, $limit);
    }
    
    function default_get_all_group_by_no_limit($default_table) {
        return $this->db->select("*")->order_by('created_at desc')->get($default_table);
    }
	
	function default_get_all_order_by_element($default_table, $order) {
        return $this->db->select("*")->order_by($order)->get($default_table);
    }

    function default_get_all_elements($table_default) {
        return $this->db->get($table_default);
    }

    function default_get_all_elements_limit($table_default, $limit, $offset) {
        return $this->db->limit($limit, $offset)->get($table_default);
    }

	function default_get_all_where_limit_b($default_table, $default_conditions, $limit) {
        return $this->db->select("*")->order_by('created_at desc')->get_where($default_table, $default_conditions, $limit);
    }
	function default_get_all_limit_order($t, $l, $o) {
        return $this->db->select("*")->order_by($o)->get($t, $l);
		//'created_at desc'
    }

    function default_get_all_elements_limit_order_desc($t, $f, $limit, $offset) {
        return $this->db->order_by($f.' desc')->limit($limit, $offset)->get($t);
    }
	
	//new   default_get_all_where_elements_field_in($table, $conditions, $field, $array_for_field,$field_order,$limit)
    function default_get_all_where_elements_field_in($t, $c, $f, $array,$fo,$l) {
        return $this->db->select("*")->order_by($fo, 'DESC')->where_in($f, $array)->get_where($t, $c,$l);
    }
	//new xn
    function default_get_all_where_and_field_in_fss($t, $f, $array,$w,$fo, $ord = '') {
        $asc = empty($ord)?'DESC':$ord;
		return $this->db->select("*")->order_by($fo, $asc)->where_in($f, $array)->get_where($t,$w);
    }
	//new
    function default_get_all_elements_field_in_fss($t, $f, $array,$fo, $ord = '') {
        $asc = empty($ord)?'DESC':$ord;
		return $this->db->select("*")->order_by($fo, $asc)->where_in($f, $array)->get($t);
    }
	//new
    function default_get_all_elements_field_where_fss($t,$w,$o, $ord = '') {
        $asc = empty($ord)?'DESC':$ord;
		return $this->db->select("*")->order_by($o, $asc)->get_where($t,$w);
    }

    function default_get_all_elements_like($table_default, $default_array_condition) {
        return $this->db->select("*")->like($default_array_condition)->get($table_default);
    }

    function default_get_all_like_or_like($t, $f,$before,$after,$both,$u) {
        return $this->db->select("*")->like($f,$before,'before')->or_like($f,$after,'after')->or_like($f,$both,'both')->or_where($u)->get($t);
    }

    function default_get_all_where_like_or_like($t,$w, $f,$before,$after,$both,$u) {
        return $this->db->select("*")->like($f,$before,'before')->or_like($f,$after,'after')->or_like($f,$both,'both')->or_where($u)->get_where($t,$w);
    }

    function default_get_all_where_like_or_like_or_where($t,$w, $f,$before,$after,$both,$u,$ot) {
        return $this->db->select("*")->like($f,$before,'before')->or_like($f,$after,'after')->or_like($f,$both,'both')->or_where($u)->or_where($ot)->get_where($t,$w);
    }

    function default_get_all_elements_join($select, $table_default_A, $table_default_B, $field_a, $field_b, $contition) {//->where($table_default_A.'.'.$field.'='."'$condition'")
        return $this->db->select($select)->join($table_default_B, $table_default_B . '.' . $field_b . ' = ' . $table_default_A . '.' . $field_a)->get_where($table_default_A, $contition);
    }

    function default_get_all_elements_distinct($table_default, $field) {
        return $this->db->select($field)->group_by($field)->get($table_default);
    }

    function default_count_all_elements($table_default) {
        return $this->db->count_all($table_default);
    }

    function default_max_element($table_default, $field) {
		return $this->db->select_max($field)->get($table_default)->row();
    }
	
	function default_max_element_where($table_default, $field, $arrar_conditions) {
		return $this->db->select_max($field)->where($arrar_conditions)->get($table_default)->row();
    }

    function default_count_all_elements_where($table_default, $default_array_condition) {
        $this->db->where($default_array_condition);
        $this->db->from($table_default);
        return $this->db->count_all_results();
    }

    function default_insert_one($table_default, $values_default) {
        return $this->db->insert($table_default, $values_default);
    }
    
    function default_insert_one_get_id($table_default, $values_default) {
        $this->db->insert($table_default, $values_default);
        return $this->db->insert_id();
    }

    function default_insert_data($table_default, $values_default) {
        return $this->db->insert_batch($table_default, $values_default);
    }

    function default_update($table_default, $id_field, $id, $params) {
        $this->db->where($id_field, $id);
        return $this->db->update($table_default, $params);
    }

    function default_update_batch($t,$params,$f) {
        return $this->db->update_batch($t,$params,$f);
    }

    function default_delete($table_default, $params) {
        return $this->db->delete($table_default, $params);
    }

    function default_get_all_elements_not_in($table_default, $field, $array_elements) {
        return $this->db->select("*")->where_not_in($field, $array_elements)->get($table_default);
    }

	//new   default_get_all_elements_field_in($table, $field, $array_for_field,$field_order,$limit)
    function default_get_all_elements_field_in($t, $f, $array,$fo,$l) {
        return $this->db->select("*")->order_by($fo, 'DESC')->where_in($f, $array)->get($t,$l);
    }
	
    function default_get_all_elements_field_in_array($t, $f, $array,$fo) {
        return $this->db->select("*")->order_by($fo, 'DESC')->where_in($f, $array)->get($t);
    }

    function default_get_all_where_elements_not_in($table_default, $conditions, $field, $array_elements) {
        return $this->db->select("*")->where_not_in($field, $array_elements)->get_where($table_default, $conditions);
    }
    
    function default_get_all_elements_not_in_and_where($table_default, $field, $array_elements, $conditions) {
        return $this->db->select("*")->where_not_in($field, $array_elements)->get_where($table_default, $conditions);
    }
	
	//new
    function default_get_all_elements_field_not_in_nn_fss($t, $f, $array,$fo, $ord = '') {
        $asc = empty($ord)?'DESC':$ord;
		return $this->db->select("*")->order_by($fo, $asc)->where_not_in($f, $array)->get($t);
    }

    function default_query_execute($sql){
        return $this->db->query($sql);
    }

    function default_query_import_excel($t,$d){
		$this->db->insert_batch($t,$d);
    }
	
	function add_column($table, $field, $type){
		$this->load->dbforge();
		$fields = array($field => array('type' => $type));
		$this->dbforge->add_column($table, $fields);
	}

}
