<?php $bs_arr = explode(",",$o->bordados); ?>
<div class="card">
	<div class="card-body">
		<h4 class="card-title">Reportes</h4>
		<div class="row mt-2">
			<div class="col-sm"><h6 class="font-weight-normal"><b>Pedido:</b> <?php echo $o->codigo; ?></h6></div>
			<div class="col-sm text-sm-right"><h6 class="font-weight-normal"><b>Entrega:</b> <?php echo $o->fecha_entrega; ?></h6></div>
		</div>
		<div class="row mt-2">
			<?php $o_us_cli = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $o->usuario)); ?>
			<div class="col-sm"><h6 class="font-weight-normal"><b>Cliente:</b> <?php echo $o_us_cli->nombre .' '. $o_us_cli->apellido; ?></h6></div>
			<div class="col-sm text-sm-right"><button data-idpedinn="<?php echo $o->id_pedido; ?>" type="button" class="btn btn-warning btn-rounded btn-fw super-end-pedido">Aprobar pedido</button></div>
		</div>
		
		<div class="">
            <ul class="nav nav-tabs tab-solid tab-solid-danger" role="tablist">
                <?php $arr_bdss = array(); ?>
				<?php foreach($bs_arr as $key => $row){ ?>
				<?php $o_bdd = $this->default_model->default_get_one_where('categoria_producto', array('id_categoria_producto' => $row)); ?>
				<?php array_push($arr_bdss,$o_bdd); ?>
				<li class="nav-item"><a class="nav-link <?php echo $key==0?'active':''; ?>" id="tab-bds-<?php echo $key; ?>" data-toggle="tab" href="#home-bds-<?php echo $key; ?>" role="tab" aria-controls="home-bds-<?php echo $key; ?>" aria-selected="true"><?php echo $o_bdd->nombre; ?></a></li>
				<?php } ?>
				
            </ul>
            <div class="tab-content tab-content-basic">
				<?php foreach($bs_arr as $key => $row){ ?>
							<?php $ax_ex_pb = $this->default_model->default_get_one_where('pedido_bordado',array('pedido' => $o->id_pedido,'bordado' => $row)); ?>
							<?php $selected_colores = explode(',',$ax_ex_pb->colores); ?>
							<?php  ?>
							<!--End Tab-->
							<div class="tab-pane fade <?php echo $key==0?'show active':''; ?>" id="home-bds-<?php echo $key; ?>" role="tabpanel" aria-labelledby="tab-bds-<?php echo $key; ?>">
								<h4 class="text-center text-danger"><?php echo $arr_bdss[$key]->nombre; ?></h4>
								<hr>
								<?php $fs_image = base_url('assets/images/image/1.gif'); ?>
								<div class="row">
									<div class="col-sm-3">
										<h6 class=""><b>Colores</b></h6>
										<div class="row h-100">
											<div class="col-sm colores-save-bbnn-tab">
												<div class="row p-0">
												<?php foreach($selected_colores as $clr_key => $cr_row){ ?>
												<?php $clr_row = $this->default_model->default_get_one_where('color', array('id_color' => $cr_row)); ?>
												<?php $url_color = !empty($clr_row->foto)?base_url('uploads/colores/thumbs/'.$clr_row->foto):base_url('assets/images/image/1.gif'); ?>
												<div class="col-sm-6 p-0 item-color-select" data-idcolorselectable="<?php echo $clr_row->id_color; ?>"><div class="span3"><a href="#imgccnn_<?php echo $key; ?>" class="small-thumbnail-cls"><img src="<?php echo $url_color; ?>" alt="Image" data-display="<?php echo $url_color; ?>" class="img-fluid"></a></div></div>
												<?php } ?>
												</div>
											</div>
										</div>
									</div>
									<div class="col-sm-6">
										<h6 class=""><b>Bordados</b></h6>
										<?php $ax_ex_tp_bd = $this->default_model->default_get_all_where('pedido_tipo_bordado',array('pedido' => $o->id_pedido,'bordado' => $row,'estado' => 'activo')); ?>
										<?php if($ax_ex_tp_bd->num_rows() > 0){ ?>
										<div class="row">
										<?php foreach($ax_ex_tp_bd->result() as $bdnm_key => $bdnm_row){ ?>
										<?php $o_bbdnm = $this->default_model->default_get_one_where('bordado', array('id_bordado' => $bdnm_row->tipo_bordado)); ?>
										<?php $url_bddnn = !empty($o_bbdnm->foto)?base_url('uploads/bordados/thumbs/'.$o_bbdnm->foto):base_url('assets/images/image/1.gif'); ?>
										<div class="col-sm-3 border item-bordados-tipos-images-fsnn text-center"><span><?php echo $o_bbdnm->nombre; ?></span><img src="<?php echo $url_bddnn; ?>" class="img-fluid"></div>
										<?php } ?>
										</div>
										<?php } ?>
									</div>
									<div class="col-sm-3">
										<h6 class=""><b>Medidas</b></h6>
										<div class="row">
											<div class="col-sm">
												<div class="form-group">
													<label for="cant_xxn_<?php echo $key; ?>-inp">Cantidad</label>
													<input disabled name="cant_camisas" min="1" type="number" class="form-control form-control-sm cantidad-innz-tab" value="<?php echo $ax_ex_pb->cantidad; ?>">
												</div>
											</div>
											<div class="col-sm">
												<div class="form-group">
													<label for="cant_xxn_<?php echo $key; ?>-inp">Puntadas</label>
													<input disabled name="puntadas_camisas" type="text" class="form-control form-control-sm" value="<?php echo $ax_ex_pb->puntadas; ?>">
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-sm">
												<div class="form-group">
													<label>U/medida</label>
													<select name="unidad_medida" class="form-control unidad-save-bbnn-tab" disabled>
														<option value="cm" <?php echo $ax_ex_pb->unidad_medida=='cm'?'selected':''; ?>>cm</option>
														<option value="m" <?php echo $ax_ex_pb->unidad_medida=='m'?'selected':''; ?>>m</option>
													</select>
												</div>
											</div>
											<div class="col-sm">
												<div class="form-group row">
													<label class="col-sm-12 text-right pt-1"><b>Medidas iguales</b></label>
													<div class="col-sm-12 text-right">No <input disabled <?php echo $ax_ex_pb->radio=='si'?'checked':''; ?> name="medidas_iguales" type="checkbox" class="js-switch m_iguales-save-bbnn-tab" data-color="#18cabe" data-secondary-color="#f62d51" data-size="small" value="si"/> Si</div>
												</div>
											</div>
										</div>
										
										<?php if($ax_ex_tp_bd->num_rows() > 0){ ?>
										<?php foreach($ax_ex_tp_bd->result() as $bdnm_key => $bdnm_row){ ?>
										<div class="row">
											<div class="col-sm">
												<div class="form-group row">
													<div class="col-sm-12"><label><?php echo $bdnm_row->nombre; ?></label></div>
													<div class="col-sm-5"><input disabled name="w" type="text" class="form-control form-control-sm" value="<?php echo $bdnm_row->ancho; ?>"></div>
													<div class="col-sm-2"><p class="m-0 text-center">x</p></div>
													<div class="col-sm-5"><input disabled name="h" type="text" class="form-control form-control-sm" value="<?php echo $bdnm_row->alto; ?>"></div>
												</div>
											</div>
										</div>
										<?php } ?>
										<?php } ?>
										
									</div>
								</div>
								<div class="row mt-2">
									<div class="col-sm">
										<textarea disabled name="observaciones" rows="13" class="form-control form-control-sm" placeholder="Escriba aqui las observaciones"><?php echo $ax_ex_pb->observaciones; ?></textarea>
									</div>
									<div class="col-sm">
										<textarea disabled name="observaciones" rows="13" class="form-control form-control-sm" placeholder="Escriba aqui las observaciones"><?php echo $ax_ex_pb->obs_dissg; ?></textarea>
									</div>
									<div class="col-sm">
										<form id="dz-fss-<?php echo $key; ?>" method="post" enctype="multipart/form-data" action="<?php echo site_url('reportes/upld_file'); ?>" class="dropzone d-flex align-items-center basic-dropzone">
											<input type="hidden" name="pedido_id" value="<?php echo $o->id_pedido; ?>"/>
											<input type="hidden" name="bordado" value="<?php echo $row; ?>"/>
										</form>
									</div>
								</div>
								<?php $files_pedido = $this->default_model->default_get_all_where('pedido_archivo',array('pedido' => $o->id_pedido,'bordado' => $row,'estado' => 'activo')); ?>
								<?php if($files_pedido->num_rows() > 0){ ?>
								<hr>
								<h5 class="text-primary">Archivos</h5>
								<ul class="list-group">
								<?php foreach($files_pedido->result() as $file_key => $file_row){ ?>
								<li class="list-group-item d-flex justify-content-between align-items-center"><a target="_blank" href="<?php echo base_url('uploads/archivos/'.$file_row->archivo); ?>"><?php echo $file_row->archivo; ?></a><a href="<?php echo base_url('uploads/archivos/'.$file_row->archivo); ?>" download><span class="badge badge-primary badge-pill"><i class="fa fa-download fa-lg m-0"></i></span></a></li>
								<?php } ?>
								</ul>
								<?php } ?>
								<?php $files_pedido = $this->default_model->default_get_all_where('pedido_archivo_extra',array('pedido' => $o->id_pedido,'bordado' => $row,'estado' => 'activo')); ?>
								<?php if($files_pedido->num_rows() > 0){ ?>
								<hr>
								<h5 class="text-primary">Bordados Extras</h5>
								<ul class="list-group">
								<?php foreach($files_pedido->result() as $file_key => $file_row){ ?>
								<li class="list-group-item d-flex justify-content-between align-items-center"><a target="_blank" href="<?php echo base_url('uploads/archivos/'.$file_row->archivo); ?>"><?php echo $file_row->archivo; ?></a><a href="<?php echo base_url('uploads/archivos/'.$file_row->archivo); ?>" download><span class="badge badge-primary badge-pill"><i class="fa fa-download fa-lg m-0"></i></span></a></li>
								<?php } ?>
								</ul>
								<?php } ?>
								
								<?php $files_pedido = $this->default_model->default_get_all_where('pedido_archivo_disgg',array('pedido' => $o->id_pedido,'bordado' => $row,'estado' => 'activo')); ?>
								<?php if($files_pedido->num_rows() > 0){ ?>
								<hr>
								<h5 class="text-primary">Archivos Dise&ntilde;ador</h5>
								<ul class="list-group">
								<?php foreach($files_pedido->result() as $file_key => $file_row){ ?>
								<li class="list-group-item d-flex justify-content-between align-items-center"><a target="_blank" href="<?php echo base_url('uploads/archivos/'.$file_row->archivo); ?>"><?php echo $file_row->archivo; ?></a><a href="<?php echo base_url('uploads/archivos/'.$file_row->archivo); ?>" download><span class="badge badge-primary badge-pill"><i class="fa fa-download fa-lg m-0"></i></span></a></li>
								<?php } ?>
								</ul>
								<?php } ?>
								
								<?php $files_pedido = $this->default_model->default_get_all_where('pedido_reporte',array('pedido' => $o->id_pedido,'bordado' => $row,'estado' => 'activo')); ?>
								<?php if($files_pedido->num_rows() > 0){ ?>
								<hr>
								<h5 class="text-primary">Reporte</h5>
								<ul class="list-group">
								<?php foreach($files_pedido->result() as $file_key => $file_row){ ?>
								<li class="list-group-item d-flex justify-content-between align-items-center"><a target="_blank" href="<?php echo base_url('uploads/archivos/'.$file_row->archivo); ?>"><?php echo $file_row->archivo; ?></a><a data-idfileinn="<?php echo $file_row->id_pedido_reporte; ?>" href="#" class="delete-file-reporte-bordado-inn"><span class="badge badge-primary badge-pill"><i class="fa fa-trash-o fa-lg m-0"></i></span></a></li>
								<?php } ?>
								</ul>
								<?php } ?>
							</div><!--End Tab-->
							<?php } ?>
				
            </div>
        </div>
	</div>
</div>