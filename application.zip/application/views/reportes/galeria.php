<?php $bs_arr = explode(",",$o->bordados); ?>
<div class="card">
	<div class="card-body">
		<h4 class="card-title">Reportes</h4>
		<div class="row mt-2">
			<div class="col-sm"><h6 class="font-weight-normal"><b>Pedido:</b> <?php echo $o->codigo; ?></h6></div>
			<div class="col-sm text-sm-right"><h6 class="font-weight-normal"><b>Entrega:</b> <?php echo $o->fecha_entrega; ?></h6></div>
		</div>
		<div class="row mt-2">
			<?php $o_us_cli = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $o->usuario)); ?>
			<div class="col-sm"><h6 class="font-weight-normal"><b>Cliente:</b> <?php echo $o_us_cli->nombre .' '. $o_us_cli->apellido; ?></h6></div>
			<div class="col-sm text-sm-right"></div>
		</div>
		
		<div class="">
            <ul class="nav nav-tabs tab-solid tab-solid-danger" role="tablist">
                <?php $arr_bdss = array(); ?>
				<?php foreach($bs_arr as $key => $row){ ?>
				<?php $o_bdd = $this->default_model->default_get_one_where('categoria_producto', array('id_categoria_producto' => $row)); ?>
				<?php array_push($arr_bdss,$o_bdd); ?>
				<li class="nav-item"><a class="nav-link <?php echo $key==0?'active':''; ?>" id="tab-bds-<?php echo $key; ?>" data-toggle="tab" href="#home-bds-<?php echo $key; ?>" role="tab" aria-controls="home-bds-<?php echo $key; ?>" aria-selected="true"><?php echo $o_bdd->nombre; ?></a></li>
				<?php } ?>
				
            </ul>
            <div class="tab-content tab-content-basic">
				<?php foreach($bs_arr as $key => $row){ ?>
							<?php $ax_ex_pb = $this->default_model->default_get_one_where('pedido_bordado',array('pedido' => $o->id_pedido,'bordado' => $row)); ?>
							<?php $selected_colores = explode(',',$ax_ex_pb->colores); ?>
							<?php  ?>
							<!--End Tab-->
							<div class="tab-pane fade <?php echo $key==0?'show active':''; ?>" id="home-bds-<?php echo $key; ?>" role="tabpanel" aria-labelledby="tab-bds-<?php echo $key; ?>">
								<h4 class="text-center text-primary">Reporte <?php echo $arr_bdss[$key]->nombre; ?></h4>
								<hr>
								<?php $files_pedido = $this->default_model->default_get_all_where('pedido_reporte',array('pedido' => $o->id_pedido,'bordado' => $row,'estado' => 'activo')); ?>
								<?php if($files_pedido->num_rows() > 0){ ?>
								<div class="row">
								<?php foreach($files_pedido->result() as $file_key => $file_row){ ?>
								<div class="col-sm-3"><img src="<?php echo base_url('uploads/archivos/'.$file_row->archivo); ?>" class="img-fluid"></div>
								<?php } ?>
								</div>
								<?php } ?>
							</div><!--End Tab-->
							<?php } ?>
				
            </div>
        </div>
	</div>
</div>