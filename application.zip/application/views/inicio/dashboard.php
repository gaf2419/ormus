<?php if($this->session->ormufss_user->rol == 'administrator') { ?>
		<div class="row">
            <div class="col-md-6 col-lg-3 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-md-center">
                    <i class="mdi mdi-basket icon-lg text-success"></i>
                    <div class="ml-3">
                      <p class="mb-0">Solicitudes</p>
                      <h6><?php echo $this->default_model->default_count_all_elements_where('pedido',array('estado' => 'solicitado')); ?></h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-md-center">
                    <i class="mdi mdi-rocket icon-lg text-warning"></i>
                    <div class="ml-3">
                      <p class="mb-0">En Proceso</p>
                      <h6><?php echo $this->default_model->default_count_all_elements_where('pedido',array('estado' => 'tarea')); ?></h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-md-center">
                    <i class="mdi mdi-diamond icon-lg text-info"></i>
                    <div class="ml-3">
                      <p class="mb-0">En Revisi&oacute;n</p>
                      <h6><?php echo $this->default_model->default_count_all_elements_where('pedido',array('estado' => 'preaprobado')); ?></h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-md-center">
                    <i class="mdi mdi-chart-line-stacked icon-lg text-danger"></i>
                    <div class="ml-3">
                      <p class="mb-0">Aprobadas</p>
                      <h6><?php echo $this->default_model->default_count_all_elements_where('pedido',array('estado' => 'aprobado')); ?></h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
		
		
		<div class="row">
            <div class="col-md-6 stretch-card">
              <div class="row flex-grow">
				<?php $gastos_totald = $this->default_model->default_query_execute("SELECT sum(total) as subtotal FROM `gasto` WHERE fecha >='".date('Y-m-d')."'")->row()->subtotal; ?>
				<?php $ss_gastos_numd = $this->default_model->default_count_all_elements_where('gasto',array('fecha >=' => date('Y-m-d'))); ?>
                <div class="col-12 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">
                      <h6 class="card-title mb-0">Total de Gastos</h6>
                      <div class="d-flex justify-content-between align-items-center">
                        <div class="d-inline-block pt-3">
                          <div class="d-lg-flex">
                            <h2 class="mb-0"><?php echo $this->cart->format_number($gastos_totald); ?><small class="text-danger">COP</small></h2>
                            <div class="d-flex align-items-center ml-lg-2">
                              <i class="mdi mdi-clock text-muted"></i>
                              <small class="ml-1 mb-0">Hoy <?php echo date('Y-m-d'); ?></small>
                            </div>
                          </div>
                          <small class="text-gray">Se han realizado <?php echo $ss_gastos_numd; ?> ordenes.</small>
                        </div>
                        <div class="d-inline-block">
                          <div class="bg-info px-3 px-md-4 py-2 rounded">
                            <i class="mdi mdi-fire text-white icon-lg"></i>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
				<?php $ingresos_totald = $this->default_model->default_query_execute("SELECT sum(total) as subtotal FROM `venta` WHERE fecha >='".date('Y-m-d')."'")->row()->subtotal; ?>
				<?php $ss_ingresos_numd = $this->default_model->default_count_all_elements_where('venta',array('fecha >=' => date('Y-m-d'))); ?>
                <div class="col-12 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">
                      <h6 class="card-title mb-0">Total de Ventas</h6>
                      <div class="d-flex justify-content-between align-items-center">
                        <div class="d-inline-block pt-3">
                          <div class="d-lg-flex">
                            <h2 class="mb-0"><?php echo $this->cart->format_number($ingresos_totald); ?><small class="text-danger">COP</small></h2>
                            <div class="d-flex align-items-center ml-lg-2">
                              <i class="mdi mdi-clock text-muted"></i>
                              <small class="ml-1 mb-0">Hoy <?php echo date('Y-m-d'); ?></small>
                            </div>
                          </div>
                          <small class="text-gray">Se han realizado <?php echo $ss_ingresos_numd; ?> ventas.</small>
                        </div>
                        <div class="d-inline-block">
                          <div class="bg-primary px-3 px-md-4 py-2 rounded">
                            <i class="mdi mdi-shopping text-white icon-lg"></i>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
			<?php $last_c_us = $this->default_model->default_get_all_where_order_by_desc_limit('usuario',array('rol' => 'cliente','estado' => 'activo'),'id_usuario',4); ?>
			<div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body pb-0">
                  <h6 class="card-title">&uacute;ltimos Clientes</h6>
                  <div class="row">
                    <?php if($last_c_us->num_rows() > 0){ ?>
					<?php foreach($last_c_us->result() as $key => $row){ ?>
					<div class="col-12">
                      <div class="wrapper border-bottom py-2">
                        <div class="d-flex">
                          <div class="wrapper ml-4">
                            <p class="mb-0"><?php echo $row->nombre .' '. $row->apellido; ?></p>
                            <small class="text-muted mb-0"><?php echo $row->email; ?></small>
                          </div>
                        </div>
                      </div>
                    </div>
					<?php } ?>
					<?php } ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
		  
		  
		<?php $last_gastos = $this->default_model->default_get_all_where_order_by_desc_limit('gasto',array('estado' => 'activo'),'id_gasto',4); ?>
		<?php if($last_gastos->num_rows() > 0){ ?>
		<div class="row grid-margin">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
                  <h6 class="card-title">&uacute;ltimos Gastos</h6>
                  <div class="table-responsive">
                    <table class="table mt-3 border-top">
                      <thead>
                        <tr>
                          <th>#</th>
                            <th>Nombre</th>
							<th>Descripci&oacute;n</th>
							<th>Fecha</th>
							<th>Categoria</th>
							<th>Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach($last_gastos->result() as $key => $row){ ?>
						<tr>
							<td><?php echo $key+1; ?></td>
                            <td><?php echo $row->nombre; ?></td>
							<td><?php echo character_limiter($row->descripcion,60); ?></td>
							<td><?php echo $row->fecha; ?></td>
							<?php $o_c_row = $this->default_model->default_get_one_where('categoria', array('id_categoria' => $row->categoria)); ?>
							<td><?php echo $o_c_row->nombre; ?></td>
							<td><?php echo $this->cart->format_number($row->total); ?><small class="text-danger">COP</small></td>
                        </tr>
						<?php } ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
        </div>
		<?php } ?>
		  
<?php } ?>