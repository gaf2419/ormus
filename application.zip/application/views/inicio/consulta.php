<!DOCTYPE html>
<html lang="es">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Bordados ORMU | <?php echo $active; ?></title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/materialdesignicons.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/simple-line-icons.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/flag-icon.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/perfect-scrollbar.min.css'); ?>">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/dropify.min.css'); ?>">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/consulta.css'); ?>">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo base_url('assets/images/icon.png'); ?>"/>
</head>

<body>
	<div class="container pt-5">
		<div class="row"><div class="col-sm"></div><div class="col-sm"><form method="post"><div class="form-group d-flex"><input name="cdd" type="text" class="form-control" placeholder="Introduzca el codigo aqui" value="<?php echo set_value('cdd'); ?>"><button type="submit" class="btn btn-primary ml-3">Consultar</button></div></form></div><div class="col-sm"></div></div>
		<?php if (@$error_credenciales or @validation_errors()) { ?>
		<div class="alert alert-fill-danger text-left">
		<?php if (@$error_credenciales): ?>
		Lo sentimos!!! No existen resultados para el c&oacute;digo introducido.<br>
		<?php endif; ?>
		<?php echo @validation_errors(); ?>
		</div>
		<?php } ?>
		<?php if (@$is_peddni): ?>
		<div class="mt-3 py-5">
			<ul class="progressbar">
				<li class="<?php echo $arr_actives['solicitado']; ?>">Solicitado</li>
				<li class="<?php echo $arr_actives['tarea']; ?>">Elaboraci&oacute;n</li>
				<li class="<?php echo $arr_actives['preaprobado']; ?>">Revisi&oacute;n</li>
				<li class="<?php echo $arr_actives['aprobado']; ?>">Finalizado</li>
			</ul>
		</div>
		<div class="w-100 mt-4 pt-5">
			<?php $o_us = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $o_peddni->usuario)); ?>
			<p><b>Cliente:</b> <?php echo $o_us->nombre .' '. $o_us->apellido .' - '. $o_us->email; ?></p>
			<?php $name_bdd = '';
			if(!empty($o_peddni->bordados)){
				$arr_bdd = explode(',',$o_peddni->bordados);
				foreach($arr_bdd as $key_b => $row_b){
					$o_nnbs = $this->default_model->default_get_one_where('categoria_producto', array('id_categoria_producto' => $row_b));
					$name_bdd .= $key_b==0?'<span class="badge badge-outline-primary badge-pill">'.$o_nnbs->nombre.'</span>':' <span class="badge badge-outline-primary badge-pill">'.$o_nnbs->nombre.'</span>';
				}
			} ?>
			<p><b>Bordados:</b> <?php echo $name_bdd; ?></p>
			<p><b>Entrega:</b> <?php echo $o_peddni->fecha_entrega; ?></p>
			<p><b>Costo:</b> <?php echo $this->cart->format_number($o_peddni->costo); ?></p>
			<p><b>Abonado:</b> <?php echo $this->cart->format_number($o_peddni->abonado); ?></p>
			<p><b>Estado:</b> <span class="badge badge-outline-success badge-pill"><?php echo $estado_title; ?></span></p>
		</div>
		<?php endif; ?>
	</div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/popper.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/perfect-scrollbar.jquery.min.js'); ?>"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="<?php echo base_url('assets/js/off-canvas.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/hoverable-collapse.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/misc.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/settings.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/todolist.js'); ?>"></script>
  <!-- endinject -->
</body>
</html>