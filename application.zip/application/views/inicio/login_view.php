<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Bordados ORMU | <?php echo $active; ?></title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/materialdesignicons.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/simple-line-icons.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/flag-icon.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/perfect-scrollbar.min.css'); ?>">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/dropify.min.css'); ?>">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo base_url('assets/images/icon.png'); ?>"/>
  <style>
	.fondo-bg {
		background-repeat: no-repeat !important;
		background-size: cover !important;
		background-position: center !important;
	}
	.img-fluid-full {
		width: 100%;
		height: 100%;
	}
  </style>
</head>

<body>
  <div class="container-scroller">
	<div class="container-fluid page-body-wrapper">
      <div class="row">
        <div class="content-wrapper full-page-wrapper d-flex align-items-center auth login-full-bg fondo-bg" style="background: url(<?php echo base_url('assets/images/bg3.jpg'); ?>);">
          <div class="row w-100">
            <div class="col-lg-8 mx-auto">
              <div class="row">
				<div class="col-lg-6 mx-auto p-0">
                  <div class="auth-form-light text-left p-5">
                    <h2 class="text-dark text-center">Acceso Bordados ORMU</h2>
                    <h6 class="font-weight-light text-primary">Hola! ya puedes iniciar</h6>
					<?php if (@$error_credenciales or @validation_errors()) { ?>
						<div class="alert alert-fill-danger text-left">
						<?php if (@$error_credenciales): ?>
							Sus credenciales no son v&aacute;lidas
							<br>
						<?php endif; ?>
						<?php echo @validation_errors(); ?>
						</div>
					<?php } ?>
                      <form class="pt-2 cmxform form-to-validate" method="post" novalidate="novalidate">
                        <div class="form-group">
                          <label for="username">Usuario</label>
                          <input type="text" class="form-control" id="username" name="username" aria-describedby="emailHelp" placeholder="Usuario" value="<?php echo set_value('username'); ?>" autocomplete="off" required>
                          <i class="mdi mdi-email"></i>
                        </div>
                        <div class="form-group">
                          <label for="password">Contrase&ntilde;a</label>
                          <input type="password" class="form-control" id="password" name="password" placeholder="Contrase&ntilde;a" value="<?php echo set_value('password'); ?>" required>
                          <i class="mdi mdi-lock"></i>
                        </div>
                        <div class="mt-2">
                          <button class="btn btn-block btn-primary btn-lg font-weight-medium" type="submit">Iniciar</button>
                        </div>
                      </form>                  
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
      </div>
      <!-- row ends -->
    </div>
    <!-- page-body-wrapper ends -->
	</div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/popper.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/perfect-scrollbar.jquery.min.js'); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="<?php echo base_url('assets/js/dropify.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/jquery.validate.min.js'); ?>"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo base_url('assets/js/off-canvas.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/hoverable-collapse.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/misc.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/settings.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/todolist.js'); ?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo base_url('assets/js/dropify.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/form-validation.js'); ?>"></script>
  <!-- End custom js for this page-->
</body>
</html>