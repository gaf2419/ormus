<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Bordados ORMU | <?php echo $active; ?></title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/materialdesignicons.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/simple-line-icons.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/flag-icon.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/perfect-scrollbar.min.css'); ?>">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/dropify.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/select2.min.css'); ?>">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo base_url('assets/images/icon.png'); ?>"/>
  <style>
	.fondo-bg {
		background-repeat: no-repeat !important;
		background-size: cover !important;
		background-position: center !important;
	}
	.img-fluid-full {
		width: 100%;
		height: 100%;
	}
  </style>
</head>

<body>
  <div class="container-scroller">
	<div class="container-fluid page-body-wrapper">
      <div class="row">
        <div class="content-wrapper full-page-wrapper d-flex align-items-center auth login-full-bg fondo-bg" style="background: url(<?php echo base_url('assets/images/bg.png'); ?>);">
          <div class="row w-100">
            <div class="col-lg-9 mx-auto">
              <div class="row">
                <div class="col-lg-6 d-flex flex-row p-0 fondo-bg" style="background-image: url(<?php echo base_url('assets/images/login.png'); ?>);">
					<img class="img-fluid-full d-block d-lg-none" src="<?php echo base_url('assets/images/login.png'); ?>">
                </div>
				<div class="col-lg-6 mx-auto p-0">
                  <div class="auth-form-dark text-left p-5">
                    <h2 class="text-center">Registrarme</h2>
                    <h6 class="font-weight-light text-danger m-0"><small>Hola! para registrarte ingresa tus datos b&aacute;sicos en el siguiente formulario</small></h6>
					<?php if (@validation_errors()) { ?>
						<div class="alert alert-fill-danger text-left">
						<?php echo @validation_errors(); ?>
						</div>
					<?php } ?>
                      <form class="pt-2 cmxform form-to-validate" method="post" enctype="multipart/form-data" novalidate="novalidate">
                        
						<div class="row">
							<div class="col-md">
								<div class="form-group">
									<label for="nombre2-inp">Nombre</label>
									<input name="nombre" type="text" id="nombre2-inp" class="form-control form-control-sm" placeholder="nombre" value="<?php echo set_value('nombre'); ?>" required>
								</div>
							</div>
							<div class="col-md">
								<div class="form-group">
									<label for="apellido2-inp">Apellidos</label>
									<input name="apellido" type="text" id="apellido2-inp" class="form-control form-control-sm" placeholder="apellidos" value="<?php echo set_value('apellido'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row mt-1">
							<div class="col-md">
								<div class="form-group">
									<label for="email2-inp">E-mail</label>
									<input name="email" type="email" id="email2-inp" class="form-control form-control-sm" placeholder="email" value="<?php echo set_value('email'); ?>" required>
								</div>
							</div>
							<div class="col-md">
								<div class="form-group">
									<label for="foto2-inp">Foto</label>
									<input name="foto" type="file" id="foto2-inp" class="form-control form-control-sm">
								</div>
							</div>
						</div>
						
						<div class="row mt-1">
							<div class="col-md">
								<div class="form-group">
									<label for="cedula2-inp">C&eacute;dula</label>
									<input name="cedula" type="text" id="cedula2-inp" class="form-control form-control-sm" placeholder="cedula" value="<?php echo set_value('cedula'); ?>" required>
								</div>
							</div>
							<div class="col-md">
								<div class="form-group">
									<label for="telefono2-inp">Tel&eacute;fono</label>
									<input name="telefono" type="text" id="telefono2-inp" class="form-control form-control-sm" placeholder="telefono" value="<?php echo set_value('telefono'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row mt-1">
							<div class="col-md">
								<div class="form-group">
									<label for="password2-inp">Contrase&ntilde;a</label>
									<input name="password" type="password" id="password2-inp" class="form-control form-control-sm" placeholder="contrase&ntilde;a" value="<?php echo set_value('password'); ?>" required>
								</div>
							</div>
							<div class="col-md">
								<div class="form-group">
									<label for="password_repeat2-inp">Repetir contrase&ntilde;a</label>
									<input name="password_repeat" type="password" id="password_repeat2-inp" class="form-control form-control-sm" placeholder="repetir contrase&ntilde;a" value="<?php echo set_value('password_repeat'); ?>" required>
								</div>
							</div>
						</div>
						
                        <div class="mt-2">
                          <button class="btn btn-block btn-danger btn-lg font-weight-medium" type="submit">Registrarme</button>
                        </div>
                      </form>                  
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
      </div>
      <!-- row ends -->
    </div>
    <!-- page-body-wrapper ends -->
	</div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/popper.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/perfect-scrollbar.jquery.min.js'); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="<?php echo base_url('assets/js/dropify.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/jquery.validate.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/select2.min.js'); ?>"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo base_url('assets/js/off-canvas.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/hoverable-collapse.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/misc.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/settings.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/todolist.js'); ?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo base_url('assets/js/dropify.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/select2.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/form-validation.js'); ?>"></script>
  <!-- End custom js for this page-->
</body>
</html>