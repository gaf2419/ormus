<div class="card">
	<div class="card-body">
		<h4 class="card-title"><?php echo $title_page; ?></h4>
		<form class="forms-sample" enctype="multipart/form-data" method="post">
			<?php if (@validation_errors()) { ?>
			<?php echo validation_errors('<div class="alert alert-danger">', '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>'); ?>
			<?php } ?>
			
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="producto-inp">Producto</label>
						<?php if($select_p_all->num_rows() > 0){ ?>
						<select name="producto" id="producto-inp" class="form-control form-control-sm">
							<?php foreach($select_p_all->result() as $key => $row){ ?>
							<option value="<?php echo $row->id_producto; ?>"><?php echo $row->nombre; ?></option>
							<?php } ?>
						</select>
						<?php } ?>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="cantidad-inp">Cantidad</label>
						<input name="cantidad" min="1" type="number" id="cantidad-inp" class="form-control form-control-sm" placeholder="cantidad" value="<?php echo set_value('cantidad'); ?>" required>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="factura-inp">Factura</label>
						<input name="factura" type="text" id="factura-inp" class="form-control form-control-sm" placeholder="factura" value="<?php echo set_value('factura'); ?>">
					</div>
				</div>
				
			</div>
			
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="descripcion-inp">Descripci&oacute;n</label>
						<textarea name="descripcion" rows="2" id="descripcion-inp" class="form-control form-control-sm" placeholder="Descripci&oacute;n"><?php echo set_value('descripcion'); ?></textarea>
					</div>
				</div>
			</div>
			
			<button type="submit" class="btn btn-success btn-sm mr-2">Adicionar</button>
			<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Cancelar</a>
		</form>
	</div>
</div>