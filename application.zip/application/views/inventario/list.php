<div class="row">
    <div class="col-lg-12">
        <div class="card px-3">
            <div class="card-body">
                <h4 class="card-title">Inventario</h4>
				<ul class="nav nav-tabs tab-basic" role="tablist">
                    <li class="nav-item"><a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Productos Agotados</a></li>
                    <li class="nav-item"><a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Ingresos</a></li>
                    <li class="nav-item"><a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Ajustes</a></li>
				</ul>
				<div class="tab-content tab-content-basic">
					<div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
						
						<h4 class="card-title">Listado de Productos Agotados <span class="container-excel-fss1 float-right"></span></h4>
						<div class="row">
							<div class="col-12">
								<div class="table-responsive">
								<?php if($o_all->num_rows() > 0) { ?>
								<table class="table order-listing excel_x" data-containerexcel=".container-excel-fss1">
									<thead>
									<tr>
										<th>#</th>
										<th>C&oacute;digo</th>
										<th>Nombre</th>
										<th>Costo</th>
										<th>Precio 1</th>
										<th>Precio 2</th>
										<th>Precio 3</th>
										<th>Precio 4</th>
										<th>Cantidad</th>
									</tr>
									</thead>
									<tbody>
									<?php foreach($o_all->result() as $key => $row){ ?>
									<tr>
										<td><?php echo $key+1; ?></td>
										<td><?php echo $row->codigo; ?></td>
										<td><?php echo $row->nombre; ?></td>
										<td><?php echo $row->costo; ?></td>
										<td><?php echo $row->precio1; ?></td>
										<td><?php echo $row->precio2; ?></td>
										<td><?php echo $row->precio3; ?></td>
										<td><?php echo $row->precio4; ?></td>
										<td><?php echo $row->cantidad; ?></td>
									</tr>
									<?php } ?>
									</tbody>
								</table>
								<?php } else { ?>
								<h5 class="text-warning">Lo sentimos!!! No existen Productos Agotados en los registros de la plataforma.</h5>
								<?php } ?>
								</div>
							</div>
						</div>
						
					</div>
					<div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
						<h4 class="card-title">Listado de Ingresos <a class="btn btn-success btn-sm ml-2 float-right" href="<?php echo site_url($controller.'/add'); ?>"><i class="icon-plus menu-icon"></i> adicionar</a> <span class="container-excel-fss2 float-right"></span></h4>
						<div class="row">
							<div class="col-12">
								<div class="table-responsive">
								<?php if($o_ing_all->num_rows() > 0) { ?>
								<table class="table order-listing excel_x" data-containerexcel=".container-excel-fss2">
									<thead>
									<tr>
										<th>#</th>
										<th>Nombre</th>
										<th>Descripci&oacute;n</th>
										<th>Cantidad</th>
										<th>Factura</th>
										<th>Total</th>
										<th>Fecha</th>
									</tr>
									</thead>
									<tbody>
									<?php foreach($o_ing_all->result() as $key => $row){ ?>
									<tr>
										<td><?php echo $key+1; ?></td>
										<td><a href="<?php echo site_url('productos/details/'.$row->producto); ?>"><?php echo $row->nombre; ?></a></td>
										<td><?php echo character_limiter($row->descripcion,60); ?></td>
										<td><?php echo $row->cantidad; ?></td>
										<td><?php echo $row->factura; ?></td>
										<td><?php echo $row->total; ?></td>
										<td><?php echo $row->fecha; ?></td>
									</tr>
									<?php } ?>
									</tbody>
								</table>
								<?php } else { ?>
								<h5 class="text-warning">Lo sentimos!!! No existen Ingresos en los registros de la plataforma.</h5>
								<?php } ?>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
						<h4 class="card-title">Listado de Ajustes de Productos <a class="btn btn-success btn-sm ml-2 float-right" href="<?php echo site_url($controller.'/ajuste'); ?>"><i class="icon-plus menu-icon"></i> adicionar</a> <span class="container-excel-fss3 float-right"></span></h4>
						<div class="row">
							<div class="col-12">
								<div class="table-responsive">
								<?php if($o_ajuste_all->num_rows() > 0) { ?>
								<table class="table order-listing excel_x" data-containerexcel=".container-excel-fss3">
									<thead>
									<tr>
										<th>#</th>
										<th>C&oacute;digo</th>
										<th>Nombre</th>
										<th>Cantidad</th>
										<th>Total</th>
										<th>Fecha</th>
									</tr>
									</thead>
									<tbody>
									<?php foreach($o_ajuste_all->result() as $key => $row){ ?>
									<tr>
										<td><?php echo $key+1; ?></td>
										<td><?php echo $row->codigo; ?></td>
										<td><?php echo $row->nombre; ?></td>
										<td><?php echo $row->cantidad; ?></td>
										<td><?php echo $row->total; ?></td>
										<td><?php echo $row->fecha; ?></td>
									</tr>
									<?php } ?>
									</tbody>
								</table>
								<?php } else { ?>
								<h5 class="text-warning">Lo sentimos!!! No existen Ajustes de Productos en los registros de la plataforma.</h5>
								<?php } ?>
								</div>
							</div>
						</div>
					</div>
				</div>
            </div>
        </div>
    </div>
</div>