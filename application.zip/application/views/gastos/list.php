<div id="delete_c_modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="dModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
        <form>
		<div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Confirmaci&oacute;n de procedimiento</h4>
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <p>Usted est&aacute; seguro que desea <span class="text-warning">Eliminar</span> este elemento?, este proceso es <span class="text-danger">irreversible</span>.</p>
                <p>Usted desea <span class="text-info">continuar</span> con este procedimiento?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Cerrar</button>
				<a class="btn btn-danger btn-ok waves-effect waves-light">Eliminar</a>
            </div>
        </div>
		</form>
    </div>
</div>

			<div class="card">
            <div class="card-body">
              <h4 class="card-title"><?php echo $title_page; ?> <a class="badge badge-success float-right" href="<?php echo site_url($controller.'/add'); ?>"><i class="icon-plus menu-icon"></i> adicionar</a></h4>
              <div id="container-excel-fss" class="w-100 mb-2 text-right"></div>
			  <div class="row">
                <div class="col-12">
					<div id="container-date-range-fss" class="w-100 mb-2">
						<form method="post">
							<div id="event_period" class="row">
								<div class="col-sm">
									<div class="form-group">
										<label for="fecha_inicio" style="width: 100%;" class="form-control-label">Fecha de inicio</label>
										<div class="input-group date datepicker actual_range">
											<input id="fecha_inicio" name="fecha_inicio" type="text" class="form-control" value="<?php echo $d_start; ?>"><div class="input-group-addon input-group-text"><span class="mdi mdi-calendar"></span></div>
										</div>
									</div>
								</div>
								<div class="col-sm">
									<div class="form-group">
										<label for="fecha_final" style="width: 100%;" class="form-control-label">Fecha final</label>
										<div class="input-group date datepicker actual_range">
											<input id="fecha_final" name="fecha_final" type="text" class="form-control" value="<?php echo $d_end; ?>"><div class="input-group-addon input-group-text"><span class="mdi mdi-calendar"></span></div>
										</div>
									</div>
								</div>
								<div class="col-sm">
									<div class="form-group">
										<label style="width: 100%;" class="form-control-label"></label>
										<button type="submit" class="btn btn-info btn-xs btn-block mt-2">Actualizar lista</button>
									</div>
								</div>
								<div class="col-sm">
									<p class="m-0 pt-3 mt-3 text-right">Total Ventas: <b><?php echo $this->cart->format_number($subtotal_ingresos); ?><small class="text-danger">COP</small></b></p>
									<p class="m-0 pt-0 mt-0 text-right">Total Gastos: <b><?php echo $this->cart->format_number($subtotal); ?><small class="text-danger">COP</small></b></p>
									<?php $t_utilidades = $subtotal_ingresos > $subtotal?$subtotal_ingresos - $subtotal:0; ?>
									<p class="m-0 pt-0 mt-0 text-right">Utilidad: <b class="text-success"><?php echo $this->cart->format_number($t_utilidades); ?><small class="text-danger">COP</small></b></p>
								</div>
							</div>
						</form>
					</div>
				
                  <div class="table-responsive">
				  <?php if($o_all->num_rows() > 0) { ?>
                    <table class="table order-listing excel">
                      <thead>
                        <tr>
							<th>#</th>
                            <th>Nombre</th>
							<th>Descripci&oacute;n</th>
							<th>Fecha</th>
							<th>Categor&iacute;a</th>
							<th>Total</th>
                        </tr>
                      </thead>
                      <tbody>
						<?php $arr_users_id = array(); ?>
						<?php $arr_users_name = array(); ?>
					  <?php foreach($o_all->result() as $key => $row){ ?>
                        <tr>
							<td><?php echo $key+1; ?></td>
                            <td><?php echo $row->nombre; ?></td>
							<td><?php echo character_limiter($row->descripcion,60); ?></td>
							<td><?php echo $row->fecha; ?></td>
							<?php
								$name_cat = 'Desconocido';
								if(!in_array($row->categoria,$arr_users_id)){
									array_push($arr_users_id,$row->categoria);
									$cat = $this->default_model->default_get_one_where('categoria', array('id_categoria' => $row->categoria));
									$name_cat = $cat->nombre;
									$name_cat = !empty($name_cat)?$name_cat:'Desconocido';
									$arr_users_name[$row->categoria] = $name_cat;
								} else {
									$name_cat = $arr_users_name[$row->categoria];
								}
							?>
							<td><?php echo $name_cat; ?></td>
							<td><?php echo $this->cart->format_number($row->total); ?></td>
                        </tr>
					  <?php } ?>
                      </tbody>
                    </table>
				  <?php } else { ?>
				  <h5 class="text-warning">Lo sentimos!!! No existen <?php echo $active_mod; ?> en los registros de la plataforma.</h5>
				  <?php } ?>
                  </div>
                </div>
              </div>
            </div>
          </div>