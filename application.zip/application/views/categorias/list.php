<div id="delete_c_modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="dModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
        <form>
		<div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Confirmaci&oacute;n de procedimiento</h4>
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <p>Usted est&aacute; seguro que desea <span class="text-warning">Eliminar</span> este elemento?, este proceso es <span class="text-danger">irreversible</span>.</p>
                <p>Usted desea <span class="text-info">continuar</span> con este procedimiento?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Cerrar</button>
				<a class="btn btn-danger btn-ok waves-effect waves-light">Eliminar</a>
            </div>
        </div>
		</form>
    </div>
</div>

			<div class="card">
            <div class="card-body">
              <h4 class="card-title"><?php echo $title_page; ?> <a class="badge badge-success float-right" href="<?php echo site_url($controller.'/add'); ?>"><i class="icon-plus menu-icon"></i> adicionar</a></h4>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
				  <?php if($o_all->num_rows() > 0) { ?>
                    <table id="order-listing" class="table">
                      <thead>
                        <tr>
							<th>#</th>
                            <th>Nombre</th>
							<th>Descripci&oacute;n</th>
							<th class="no-sort text-center">Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
					  <?php foreach($o_all->result() as $key => $row){ ?>
                        <tr>
							<td><?php echo $key+1; ?></td>
                            <td><?php echo $row->nombre; ?></td>
							<td><?php echo character_limiter($row->descripcion,60); ?></td>
                            <td class="text-center">
                              <a class="text-info" href="<?php echo site_url($controller.'/details/'.$row->$id_o); ?>"><i class="fa fa-eye fa-lg m-0"></i></a>
                              <a class="text-warning ml-3" href="<?php echo site_url($controller.'/update/'.$row->$id_o); ?>"><i class="fa fa-edit fa-lg m-0"></i></a>
							  <a class="text-danger ml-3" style="cursor:pointer;" data-toggle="modal" data-target="#delete_c_modal" data-href="<?php echo site_url($controller.'/delete/'.$row->$id_o); ?>"><i class="fa fa-trash-o fa-lg m-0"></i></a>
                            </td>
                        </tr>
					  <?php } ?>
                      </tbody>
                    </table>
				  <?php } else { ?>
				  <h5 class="text-warning">Lo sentimos!!! No existen <?php echo $active_mod; ?> en los registros de la plataforma.</h5>
				  <?php } ?>
                  </div>
                </div>
              </div>
            </div>
          </div>