<div class="card">
	<div class="card-body">
		<h4 class="card-title"><?php echo $title_page; ?></h4>
		<form class="forms-sample" enctype="multipart/form-data" method="post">
			<?php if (@validation_errors()) { ?>
			<?php echo validation_errors('<div class="alert alert-danger">', '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>'); ?>
			<?php } ?>
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="nombre1-inp">Nombre</label>
						<input name="nombre" type="text" id="nombre1-inp" class="form-control form-control-sm" placeholder="nombre" value="<?php echo set_value('nombre'); ?>" required>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="apellido1-inp">Apellidos</label>
						<input name="apellido" type="text" id="apellido1-inp" class="form-control form-control-sm" placeholder="apellidos" value="<?php echo set_value('apellido'); ?>" required>
					</div>
				</div>
			</div>

			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="username1-inp">Username</label>
						<input name="username" type="text" id="username1-inp" class="form-control form-control-sm" placeholder="username" value="<?php echo set_value('username'); ?>" required>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="email1-inp">E-mail</label>
						<input name="email" type="email" id="email1-inp" class="form-control form-control-sm" placeholder="email" value="<?php echo set_value('email'); ?>" required>
					</div>
				</div>
			</div>

			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="foto1-inp">Foto</label>
						<input name="foto" type="file" id="foto1-inp" class="file-upload-default">
						<div class="input-group col-xs-12">
							<input type="text" class="form-control form-control-sm file-upload-info" disabled placeholder="Cargar imagen">
							<div class="input-group-append">
							  <button class="file-upload-browse btn btn-info" type="button">Cargar</button>                          
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="rol-inp">Rol</label>
						<select name="rol" id="rol-inp" class="form-control form-control-sm">
							<option value="administrator" <?php echo set_select('rol', 'administrator',TRUE); ?>>Administrador</option>
							<option value="supervisor" <?php echo set_select('rol', 'supervisor'); ?>>Supervisor</option>
							<option value="recepcion" <?php echo set_select('rol', 'recepcion'); ?>>Recepcion</option>
							<option value="disenador" <?php echo set_select('rol', 'disenador'); ?>>Dise&ntilde;ador</option>
							<option value="operario" <?php echo set_select('rol', 'operario'); ?>>Operario</option>
							<option value="sucursal" <?php echo set_select('rol', 'sucursal'); ?>>Sucursal</option>
						</select>
					</div>
				</div>
			</div>

			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="password1-inp">Contrase&ntilde;a</label>
						<input name="password" type="password" id="password1-inp" class="form-control form-control-sm" placeholder="contrase&ntilde;a" value="<?php echo set_value('password'); ?>" required>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="password_repeat1-inp">Repetir contrase&ntilde;a</label>
						<input name="password_repeat" type="password" id="password_repeat1-inp" class="form-control form-control-sm" placeholder="repetir contrase&ntilde;a" value="<?php echo set_value('password_repeat'); ?>" required>
					</div>
				</div>
			</div>
			<input name="estado" type="hidden" value="activo">
			<button type="submit" class="btn btn-success btn-sm mr-2">Adicionar</button>
			<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Cancelar</a>
		</form>
	</div>
</div>