<?php $disabled_fss = $o_disabled?'disabled':''; ?>
<?php $disabled_required_fss = $o_disabled?'disabled':'required'; ?>

<div class="card">
	<div class="card-body">
		<h4 class="card-title"><?php echo $title_page; ?></h4>
		<form class="forms-sample" enctype="multipart/form-data" method="post">
			<?php if (@validation_errors()) { ?>
			<?php echo validation_errors('<div class="alert alert-danger">', '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>'); ?>
			<?php } ?>
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="nombre1-inp">Nombre</label>
						<input name="nombre" type="text" id="nombre1-inp" class="form-control form-control-sm" placeholder="nombre" value="<?php echo !empty($_POST)?set_value('nombre'):$o->nombre; ?>" <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="apellido1-inp">Apellidos</label>
						<input name="apellido" type="text" id="apellido1-inp" class="form-control form-control-sm" placeholder="apellidos" value="<?php echo !empty($_POST)?set_value(apellido):$o->apellido; ?>"  <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
			</div>

			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="username1-inp">Username</label>
						<input name="username" type="text" id="username1-inp" class="form-control form-control-sm" placeholder="username" value="<?php echo !empty($_POST)?set_value('username'):$o->username; ?>"  <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="email1-inp">E-mail</label>
						<input name="email" type="email" id="email1-inp" class="form-control form-control-sm" placeholder="email" value="<?php echo !empty($_POST)?set_value('email'):$o->email; ?>"  <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
			</div>

			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="foto-inp">foto</label>
						<img src="<?php echo !empty($o->foto)?base_url('uploads/'.$url_b_uploads.'/thumbs/'.$o->foto):base_url('assets/images/user.png'); ?>" style="max-width: 80px;">
					</div>
				</div>
				<div class="col-sm">
					<?php if(!$o_disabled){ ?>
					<div class="form-group">
						<label for="foto1-inp">Foto</label>
						<input name="foto" type="file" id="foto1-inp" class="file-upload-default">
						<div class="input-group col-xs-12">
							<input type="text" class="form-control form-control-sm file-upload-info" disabled placeholder="Cargar imagen">
							<div class="input-group-append">
							  <button class="file-upload-browse btn btn-info" type="button">Cargar</button>                          
							</div>
						</div>
					</div>
					<?php } ?>
				</div>
			</div>
			<?php if(!$o_disabled){ ?>
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="password1-inp">Contrase&ntilde;a</label>
						<input name="password" type="password" id="password1-inp" class="form-control form-control-sm" placeholder="contrase&ntilde;a" value="<?php echo set_value('password'); ?>" required>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="password_repeat1-inp">Repetir contrase&ntilde;a</label>
						<input name="password_repeat" type="password" id="password_repeat1-inp" class="form-control form-control-sm" placeholder="repetir contrase&ntilde;a" value="<?php echo set_value('password_repeat'); ?>" required>
					</div>
				</div>
			</div>
			<?php } ?>

			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="estado2-inp">Estado</label>
						<select name="estado" id="estado2-inp" class="form-control form-control-sm" <?php echo $disabled_fss; ?>>
							<option value="activo" <?php echo !empty($_POST)?set_select('estado', 'activo',TRUE):$o->estado=='activo'?'selected':''; ?>>Aprobado</option>
							<option value="pendiente" <?php echo !empty($_POST)?set_select('estado', 'pendiente'):$o->estado=='pendiente'?'selected':''; ?>>Pendiente</option>
							<option value="inactivo" <?php echo !empty($_POST)?set_select('estado', 'inactivo'):$o->estado=='inactivo'?'selected':''; ?>>Inactivo</option>
							<option value="denegado" <?php echo !empty($_POST)?set_select('estado', 'denegado'):$o->estado=='denegado'?'selected':''; ?>>Rechazado</option>
						</select>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="rol-inp">Rol</label>
						<select name="rol" id="rol-inp" class="form-control form-control-sm" <?php echo $disabled_fss; ?>>
							<option value="administrator" <?php echo !empty($_POST)?set_select('rol', 'administrator',TRUE):$o->rol=='administrator'?'selected':''; ?>>Administrador</option>
							<option value="supervisor" <?php echo !empty($_POST)?set_select('rol', 'supervisor'):$o->rol=='supervisor'?'selected':''; ?>>Supervisor</option>
							<option value="recepcion" <?php echo !empty($_POST)?set_select('rol', 'recepcion'):$o->rol=='recepcion'?'selected':''; ?>>Recepcion</option>
							<option value="disenador" <?php echo !empty($_POST)?set_select('rol', 'disenador'):$o->rol=='disenador'?'selected':''; ?>>Dise&ntilde;ador</option>
							<option value="operario" <?php echo !empty($_POST)?set_select('rol', 'operario'):$o->rol=='operario'?'selected':''; ?>>Operario</option>
							<option value="sucursal" <?php echo !empty($_POST)?set_select('rol', 'sucursal'):$o->rol=='sucursal'?'selected':''; ?>>Sucursal</option>
						</select>
					</div>
				</div>
			</div>

			<?php if(!$o_disabled){ ?>
			<button type="submit" class="btn btn-warning btn-sm mr-2">Actualizar</button>
			<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Cancelar</a>
			<?php } else { ?>
			<a href="<?php echo site_url($controller.'/update/'.$o->$id_o); ?>" class="btn btn-warning btn-sm mr-2">Editar</a>
			<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Regresar</a>
			<?php } ?>
		</form>
	</div>
</div>
