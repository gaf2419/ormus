<!doctype html>
<html lang="es">
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="https://369969691f476073508a-60bf0867add971908d4f26a64519c2aa.ssl.cf5.rackcdn.com/logos/logo_epayco_200px.png" type="image/x-icon">
	<title>Epayco Response</title>
	<!-- Bootstrap -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
	</head>
	<body>
	<div class="container">
		<div class="py-5 text-center">
			<img class="d-block mx-auto mb-3" src="https://369969691f476073508a-60bf0867add971908d4f26a64519c2aa.ssl.cf5.rackcdn.com/logos/logo_epayco_200px.png" style="max-width: 100%;height: auto;" >
			<div class="bx-all-cont-nn-fss">
			<img class="d-block mx-auto mb-1" src="<?php echo base_url('assets/images/load.gif'); ?>" style="max-width: 300px;" >
			<p class="lead text-info">Pago Seguro con Epayco</p>
			<p class="text-danger">Espere un momento por favor mientras se procesan los datos de su pago, si usted realiza un pago por consignaci&oacute;n, puede usted cerrar esta p&aacute;gina si as&iacute; lo desea, y asegurese de recibir su tiquete o comprobante de pago en la entidad donde realice el pago, cuando la entidad realiza la confirmaci&oacute;n de su pago con nuestra plataforma, entonces se ver&aacute; reflejado su pago en el m&oacute;dulo correspondiente, esta acci&oacute;n de confirmaci&oacute;n puede tardar hasta 3 horas.</p>
			<ul class="list-group mb-3 bx-data-pay">
				<li class="list-group-item d-flex justify-content-between lh-condensed">
					<div>
						<h6 class="my-0">Referencia</h6>
						<small class="text-muted"></small>
					</div>
					<span id="referencia" class="text-muted"></span>
				</li>
				<li class="list-group-item d-flex justify-content-between lh-condensed">
					<div>
						<h6 class="my-0">Fecha</h6>
						<small class="text-muted"></small>
					</div>
					<span id="fecha" class="text-muted"></span>
				</li>
				<li class="list-group-item d-flex justify-content-between lh-condensed">
					<div>
						<h6 class="my-0">Respuesta</h6>
						<small class="text-muted"></small>
					</div>
					<span id="respuesta" class="text-muted"></span>
				</li>
				<li class="list-group-item d-flex justify-content-between lh-condensed">
					<div>
						<h6 class="my-0">Motivo</h6>
						<small class="text-muted"></small>
					</div>
					<span id="motivo" class="text-muted"></span>
				</li>
				<li class="list-group-item d-flex justify-content-between lh-condensed">
					<div>
						<h6 class="my-0">Banco</h6>
						<small class="text-muted"></small>
					</div>
					<span id="banco" class="text-muted"></span>
				</li>
				<li class="list-group-item d-flex justify-content-between lh-condensed">
					<div>
						<h6 class="my-0">Recibo</h6>
						<small class="text-muted"></small>
					</div>
					<span id="recibo" class="text-muted"></span>
				</li>
				<li class="list-group-item d-flex justify-content-between lh-condensed">
					<div>
						<h6 class="my-0">C&oacute;digo de Aprobaci&oacute;n</h6>
						<small class="text-muted"></small>
					</div>
					<span id="approval_code" class="text-muted"></span>
				</li>
				<li class="list-group-item d-flex justify-content-between">
					<span>Total (COP)</span>
					<strong><span id="total"></span></strong>
				</li>
			</ul>
			</div>
		</div>
	</div>
		<nav class="navbar fixed-bottom navbar-light bg-light">
			<div class="container">
				<div class="py-5 text-center">
					<img class="d-block mx-auto" src="http://0523aae09f0cadbd79f4-60bf0867add971908d4f26a64519c2aa.r62.cf5.rackcdn.com/btns/powered.png" style="max-width: 100%;height: auto;" >
				</div>
			</div>
		</nav>
	
	
	
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
	<script>
    function getQueryParam(param) {
      location.search.substr(1)
        .split("&")
        .some(function(item) { // returns first occurence and stops
          return item.split("=")[0] == param && (param = item.split("=")[1])
        })
      return param
    }
    $(document).ready(function() {
		$('.bx-data-pay').fadeOut();
      //llave publica del comercio
      //Referencia de payco que viene por url
      var ref_payco = getQueryParam('ref_payco');
      //Url Rest Metodo get, se pasa la llave y la ref_payco como paremetro
      var urlapp = "https://secure.epayco.co/validation/v1/reference/" + ref_payco;
      $.get(urlapp, function(response) {
        if (response.success) {
          if (response.data.x_cod_response == 1) {
            console.log('transacción aceptada');
			$('#fecha').html(response.data.x_transaction_date);
			$('#respuesta').html(response.data.x_response);
			$('#referencia').text(response.data.x_id_invoice);
			//$('#x_extra1').text(response.data.x_extra1);
			//$('#x_extra2').text(response.data.x_extra2);
			//$('#x_extra3').text(response.data.x_extra3);
			$('#motivo').text(response.data.x_response_reason_text);
			$('#recibo').text(response.data.x_transaction_id);
			$('#approval_code').text(response.data.x_approval_code);
			$('#banco').text(response.data.x_bank_name);
			$('#autorizacion').text(response.data.x_approval_code);
			$('#total').text(response.data.x_amount + ' ' + response.data.x_currency_code);
			$('.bx-data-pay').fadeIn();
			$.post("<?php echo site_url('epayco/pro_data'); ?>", {
				referencia: response.data.x_id_invoice,
				recibo: response.data.x_transaction_id,
				ref_payco: ref_payco,
				extra1: response.data.x_extra1,
				extra2: response.data.x_extra2,
				extra3: response.data.x_extra3,
				monto: response.data.x_amount,
				moneda: response.data.x_currency_code,
				respuesta: response.data.x_response
			}, function (data) {
				location.href = "<?php echo site_url('epayco/success'); ?>";
			}, "html");
          }
          //Transaccion Rechazada
          if (response.data.x_cod_response == 2) {
            console.log('transacción rechazada');
				//alert('transacción rechazada');
				$('.bx-all-cont-nn-fss').html('<div class="alert alert-danger pt-4 pb-4" role="alert"><p class="lead m-0">Lo Sentimos!!! La transacci&oacute;n ha sido rechazada.</p></div><a href="<?php echo site_url(); ?>" class="btn btn-dark btn-xs mx-auto">Inicio</a>');
          }
          //Transaccion Pendiente
          if (response.data.x_cod_response == 3) {
            console.log('transacción pendiente');
            //alert('transacción pendiente');
			$('.bx-all-cont-nn-fss').html('<div class="alert alert-warning pt-4 pb-4" role="alert"><p class="lead m-0">Lo Sentimos!!! La transacci&oacute;n se encuentra pendiente, cada 10 segundos se actualizara la p&aacute;gina hasta que cambie el estado de la transacci&oacute;n, o si desea puede regresar al inicio:</p></div><a href="<?php echo site_url(); ?>" class="btn btn-dark btn-xs mx-auto">Inicio</a>');
			setInterval(function(){location.reload();}, 10000);
          }
          //Transaccion Fallida
          if (response.data.x_cod_response == 4) {
            console.log('transacción fallida');
				//alert('transacción fallida');
				$('.bx-all-cont-nn-fss').html('<div class="alert alert-danger pt-4 pb-4" role="alert"><p class="lead m-0">Lo Sentimos!!! La transacci&oacute;n es fallida</p></div><a href="<?php echo site_url(); ?>" class="btn btn-dark btn-xs mx-auto">Inicio</a>');
          }
        } else {
			//alert("Error consultando la información");
			$('.bx-all-cont-nn-fss').html('<div class="alert alert-danger pt-4 pb-4" role="alert"><p class="lead m-0">Lo Sentimos!!! Ha ocurrido un error consultando la informaci&oacute;n. Los datos de la transacci&oacute;n no son v&aacute;lidos</p></div><a href="<?php echo site_url(); ?>" class="btn btn-dark btn-xs mx-auto">Inicio</a>');
        }
      });
    });
	</script>
	</body>
</html>