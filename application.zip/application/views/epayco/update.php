<?php $o_disabled = false; ?>
<?php $disabled_fss = $o_disabled?'disabled':''; ?>
<?php $disabled_required_fss = $o_disabled?'disabled':'required'; ?>
<div class="card">
	<div class="card-body">
		<h4 class="card-title text-warning"><?php echo $title_page; ?></h4>
		<form class="forms-sample" enctype="multipart/form-data" method="post">
			<?php if (@validation_errors()) { ?>
			<?php echo validation_errors('<div class="alert alert-danger">', '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>'); ?>
			<?php } ?>
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="public_key-inp">public_key</label>
						<input name="public_key" type="text" id="public_key-inp" class="form-control form-control-sm" placeholder="public_key" value="<?php echo !empty($_POST)?set_value('public_key'):$o->public_key; ?>" <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="p_key-inp">p_key</label>
						<input name="p_key" type="text" id="p_key-inp" class="form-control form-control-sm" placeholder="p_key" value="<?php echo !empty($_POST)?set_value('p_key'):$o->p_key; ?>" <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
			</div>
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="p_cust_id_cliente-inp">p_cust_id_cliente</label>
						<input name="p_cust_id_cliente" type="text" id="p_cust_id_cliente-inp" class="form-control form-control-sm" placeholder="p_cust_id_cliente" value="<?php echo !empty($_POST)?set_value('p_cust_id_cliente'):$o->p_cust_id_cliente; ?>" <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="test-inp">Modo</label>
						<select name="test" id="test-inp" class="form-control form-control-sm" <?php echo $disabled_fss; ?>>
							<option value="false" <?php echo !empty($_POST)?set_select('test', 'false',TRUE):$o->test=='false'?'selected':''; ?>>Produccion</option>
							<option value="true" <?php echo !empty($_POST)?set_select('test', 'true'):$o->test=='true'?'selected':''; ?>>Prueba</option>
						</select>
					</div>
				</div>
			</div>

			<button type="submit" class="btn btn-warning btn-sm mr-2">Actualizar</button>
			<a href="<?php echo site_url('configuraciones'); ?>" class="btn btn-sm btn-light">Regresar</a>
		</form>
	</div>
</div>
