<?php $disabled_fss = $o_disabled?'disabled':''; ?>
<?php $disabled_required_fss = $o_disabled?'disabled':'required'; ?>

<div class="card">
	<div class="card-body">
		<h4 class="card-title"><?php echo $title_page; ?></h4>
		<div class="">
            <div class="">
				<?php if($o->rol=='administrator'){ ?>
				<div class="">
					<form class="forms-sample" enctype="multipart/form-data" method="post">
						<?php if (@validation_errors()) { ?>
						<?php echo validation_errors('<div class="alert alert-danger">', '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>'); ?>
						<?php } ?>
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="nombre1-inp">Nombre</label>
									<input name="nombre" type="text" id="nombre1-inp" class="form-control form-control-sm" placeholder="nombre" value="<?php echo !empty($_POST)?set_value('nombre'):$o->nombre; ?>" <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="apellido1-inp">Apellidos</label>
									<input name="apellido" type="text" id="apellido1-inp" class="form-control form-control-sm" placeholder="apellidos" value="<?php echo !empty($_POST)?set_value(apellido):$o->apellido; ?>"  <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
						</div>
						
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="username1-inp">Username</label>
									<input name="username" type="text" id="username1-inp" class="form-control form-control-sm" placeholder="username" value="<?php echo !empty($_POST)?set_value('username'):$o->username; ?>"  <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="email1-inp">E-mail</label>
									<input name="email" type="email" id="email1-inp" class="form-control form-control-sm" placeholder="email" value="<?php echo !empty($_POST)?set_value('email'):$o->email; ?>"  <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
						</div>
						
						<div class="row mt-2">
							<div class="col-sm">
								<?php if(!$o_disabled){ ?>
								<div class="form-group">
									<label for="foto1-inp">Foto</label>
									<input name="foto" type="file" id="foto-inp" class="dropify" data-max-file-size="2M" data-max-file-size-preview="2M" data-default-file="<?php echo !empty($o->foto)?base_url('uploads/'.$url_b_uploads.'/thumbs/'.$o->foto):base_url('assets/images/default_avatar.jpg'); ?>">
								</div>
								<?php } ?>
							</div>
							<div class="col-sm"></div>
							<div class="col-sm"></div>
							<div class="col-sm"></div>
						</div>
						<?php if(!$o_disabled){ ?>
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="password1-inp">Contrase&ntilde;a</label>
									<input name="password" type="password" id="password1-inp" class="form-control form-control-sm" placeholder="contrase&ntilde;a" value="<?php echo set_value('password'); ?>" required>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="password_repeat1-inp">Repetir contrase&ntilde;a</label>
									<input name="password_repeat" type="password" id="password_repeat1-inp" class="form-control form-control-sm" placeholder="repetir contrase&ntilde;a" value="<?php echo set_value('password_repeat'); ?>" required>
								</div>
							</div>
						</div>
						<?php } ?>
						
						<?php if(!$o_disabled){ ?>
						<button type="submit" class="btn btn-warning btn-sm mr-2">Actualizar</button>
						<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Cancelar</a>
						<?php } else { ?>
						<a href="<?php echo site_url($controller.'/update/'.$o->$id_o); ?>" class="btn btn-warning btn-sm mr-2">Editar</a>
						<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Regresar</a>
						<?php } ?>
					</form>
				</div>
				<?php } else if($o->rol=='empleado'){ ?>
				<div>
					<form class="forms-sample" enctype="multipart/form-data" method="post">
						<?php if (@validation_errors()) { ?>
						<?php echo validation_errors('<div class="alert alert-danger">', '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>'); ?>
						<?php } ?>
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="nombre2-inp">Nombre</label>
									<input name="nombre" type="text" id="nombre2-inp" class="form-control form-control-sm" placeholder="nombre" value="<?php echo !empty($_POST)?set_value('nombre'):$o->nombre; ?>" <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="apellido2-inp">Apellidos</label>
									<input name="apellido" type="text" id="apellido2-inp" class="form-control form-control-sm" placeholder="apellidos" value="<?php echo !empty($_POST)?set_value(apellido):$o->apellido; ?>" <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
						</div>
						
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="username2-inp">Username</label>
									<input name="username" type="text" id="username2-inp" class="form-control form-control-sm" placeholder="username" value="<?php echo !empty($_POST)?set_value('username'):$o->username; ?>" <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="email2-inp">E-mail</label>
									<input name="email" type="email" id="email2-inp" class="form-control form-control-sm" placeholder="email" value="<?php echo !empty($_POST)?set_value('email'):$o->email; ?>" <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
						</div>
						
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="cedula2-inp">C&eacute;dula</label>
									<input name="cedula" type="text" id="cedula2-inp" class="form-control form-control-sm" placeholder="cedula" value="<?php echo !empty($_POST)?set_value('cedula'):$o->cedula; ?>" <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="telefono2-inp">Tel&eacute;fono</label>
									<input name="telefono" type="text" id="telefono2-inp" class="form-control form-control-sm" placeholder="telefono" value="<?php echo !empty($_POST)?set_value('telefono'):$o->telefono; ?>" <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
						</div>
						
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="no_empresa-inp">No empresa</label>
									<input name="no_empresa" type="text" id="no_empresa-inp" class="form-control form-control-sm" placeholder="no empresa" value="<?php echo !empty($_POST)?set_value('no_empresa'):$o->no_empresa; ?>" <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="nit-inp">Nit</label>
									<input name="nit" type="text" id="nit-inp" class="form-control form-control-sm" placeholder="nit" value="<?php echo !empty($_POST)?set_value('nit'):$o->nit; ?>" <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="representante-inp">Representante</label>
									<input name="representante" type="text" id="representante-inp" class="form-control form-control-sm" placeholder="representante" value="<?php echo !empty($_POST)?set_value('representante'):$o->representante; ?>" <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
						</div>
						
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="direccion2-inp">Direcci&oacute;n</label>
									<textarea name="direccion" rows="2" id="direccion2-inp" class="form-control form-control-sm" placeholder="direccion" <?php echo $disabled_required_fss; ?>><?php echo !empty($_POST)?set_value('direccion'):$o->direccion; ?></textarea>
								</div>
							</div>
						</div>
						
						<div class="row mt-2">
							<div class="col-sm">
								<?php if(!$o_disabled){ ?>
								<div class="form-group">
									<label for="foto1-inp">Foto</label>
									<input name="foto" type="file" id="foto-inp" class="dropify" data-max-file-size="2M" data-max-file-size-preview="2M" data-default-file="<?php echo !empty($o->foto)?base_url('uploads/'.$url_b_uploads.'/thumbs/'.$o->foto):base_url('assets/images/default_avatar.jpg'); ?>">
								</div>
								<?php } ?>
							</div>
							<div class="col-sm"></div>
							<div class="col-sm"></div>
							<div class="col-sm"></div>
						</div>
						
						<?php if(!$o_disabled){ ?>
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="password2-inp">Contrase&ntilde;a</label>
									<input name="password" type="password" id="password2-inp" class="form-control form-control-sm" placeholder="contrase&ntilde;a" value="<?php echo set_value('password'); ?>" required>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="password_repeat2-inp">Repetir contrase&ntilde;a</label>
									<input name="password_repeat" type="password" id="password_repeat2-inp" class="form-control form-control-sm" placeholder="repetir contrase&ntilde;a" value="<?php echo set_value('password_repeat'); ?>" required>
								</div>
							</div>
						</div>
						<?php } ?>
						
						<?php if(!$o_disabled){ ?>
						<button type="submit" class="btn btn-warning btn-sm mr-2">Actualizar</button>
						<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Cancelar</a>
						<?php } else { ?>
						<a href="<?php echo site_url($controller.'/update/'.$o->$id_o); ?>" class="btn btn-warning btn-sm mr-2">Editar</a>
						<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Regresar</a>
						<?php } ?>
					</form>
				</div>
				<?php } else { ?>
				<div>
					<form class="forms-sample" enctype="multipart/form-data" method="post">
						<?php if (@validation_errors()) { ?>
						<?php echo validation_errors('<div class="alert alert-danger">', '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>'); ?>
						<?php } ?>
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="nombre-inp">Nombre</label>
									<input name="nombre" type="text" id="nombre-inp" class="form-control form-control-sm" placeholder="nombre" value="<?php echo !empty($_POST)?set_value('nombre'):$o->nombre; ?>" <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="apellido-inp">Apellidos</label>
									<input name="apellido" type="text" id="apellido-inp" class="form-control form-control-sm" placeholder="apellidos" value="<?php echo !empty($_POST)?set_value(apellido):$o->apellido; ?>"  <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
						</div>
						
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="username-inp">Username</label>
									<input name="username" type="text" id="username-inp" class="form-control form-control-sm" placeholder="username" value="<?php echo !empty($_POST)?set_value('username'):$o->username; ?>"  <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="email-inp">E-mail</label>
									<input name="email" type="email" id="email-inp" class="form-control form-control-sm" placeholder="email" value="<?php echo !empty($_POST)?set_value('email'):$o->email; ?>"  <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
						</div>
						
						<div class="row mt-2">
							<div class="col-sm">
								<?php if(!$o_disabled){ ?>
								<div class="form-group">
									<label for="foto1-inp">Foto</label>
									<input name="foto" type="file" id="foto-inp" class="dropify" data-max-file-size="2M" data-max-file-size-preview="2M" data-default-file="<?php echo !empty($o->foto)?base_url('uploads/'.$url_b_uploads.'/thumbs/'.$o->foto):base_url('assets/images/default_avatar.jpg'); ?>">
								</div>
								<?php } ?>
							</div>
							<div class="col-sm"></div>
							<div class="col-sm"></div>
							<div class="col-sm"></div>
						</div>
						
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="cedula3-inp">C&eacute;dula</label>
									<input name="cedula" type="text" id="cedula3-inp" class="form-control form-control-sm" placeholder="cedula" value="<?php echo !empty($_POST)?set_value('cedula'):$o->cedula; ?>" <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="telefono3-inp">Tel&eacute;fono</label>
									<input name="telefono" type="text" id="telefono3-inp" class="form-control form-control-sm" placeholder="telefono" value="<?php echo !empty($_POST)?set_value('telefono'):$o->telefono; ?>" <?php echo $disabled_required_fss; ?>>
								</div>
							</div>
						</div>
						
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="direccion3-inp">Direcci&oacute;n</label>
									<textarea name="direccion" rows="2" id="direccion3-inp" class="form-control form-control-sm" placeholder="direccion" <?php echo $disabled_required_fss; ?>><?php echo !empty($_POST)?set_value('direccion'):$o->direccion; ?></textarea>
								</div>
							</div>
						</div>
						
						<?php if(!$o_disabled){ ?>
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="password-inp">Contrase&ntilde;a</label>
									<input name="password" type="password" id="password-inp" class="form-control form-control-sm" placeholder="contrase&ntilde;a" value="<?php echo set_value('password'); ?>" required>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="password_repeat-inp">Repetir contrase&ntilde;a</label>
									<input name="password_repeat" type="password" id="password_repeat-inp" class="form-control form-control-sm" placeholder="repetir contrase&ntilde;a" value="<?php echo set_value('password_repeat'); ?>" required>
								</div>
							</div>
						</div>
						<?php } ?>
						
						<?php if(!$o_disabled){ ?>
						<button type="submit" class="btn btn-warning btn-sm mr-2">Actualizar</button>
						<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Cancelar</a>
						<?php } else { ?>
						<a href="<?php echo site_url($controller.'/update/'.$o->$id_o); ?>" class="btn btn-warning btn-sm mr-2">Editar</a>
						<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Regresar</a>
						<?php } ?>
					</form>
				</div>
				<?php } ?>
            </div>
        </div>
	</div>
</div>
