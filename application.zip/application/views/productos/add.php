<div class="card">
	<div class="card-body">
		<h4 class="card-title"><?php echo $title_page; ?></h4>
		<form class="forms-sample" enctype="multipart/form-data" method="post">
			<?php if (@validation_errors()) { ?>
			<?php echo validation_errors('<div class="alert alert-danger">', '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>'); ?>
			<?php } ?>
			
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="nombre-inp">Nombre</label>
						<input name="nombre" type="text" id="nombre-inp" class="form-control form-control-sm" placeholder="nombre" value="<?php echo set_value('nombre'); ?>" required>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="codigo-inp">C&oacute;digo</label>
						<input name="codigo" type="text" id="codigo-inp" class="form-control form-control-sm" placeholder="codigo" value="<?php echo set_value('codigo'); ?>" required>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="costo-inp">Costo</label>
						<input name="costo" type="text" id="costo-inp" class="form-control form-control-sm" placeholder="costo" value="<?php echo set_value('costo'); ?>" required>
					</div>
				</div>
			</div>
			
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="precio1-inp">Precio 1</label>
						<input name="precio1" type="text" id="precio1-inp" class="form-control form-control-sm" placeholder="precio 1" value="<?php echo set_value('precio1'); ?>" required>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="precio2-inp">Precio 2</label>
						<input name="precio2" type="text" id="precio2-inp" class="form-control form-control-sm" placeholder="precio 2" value="<?php echo set_value('precio2'); ?>" required>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="precio3-inp">Precio 3</label>
						<input name="precio3" type="text" id="precio3-inp" class="form-control form-control-sm" placeholder="precio 3" value="<?php echo set_value('precio3'); ?>" required>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="precio4-inp">Precio 4</label>
						<input name="precio4" type="text" id="precio4-inp" class="form-control form-control-sm" placeholder="precio 4" value="<?php echo set_value('precio4'); ?>" required>
					</div>
				</div>
			</div>
			
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="descripcion-inp">Descripci&oacute;n</label>
						<textarea name="descripcion" rows="2" id="descripcion-inp" class="form-control form-control-sm" placeholder="Descripci&oacute;n"><?php echo set_value('descripcion'); ?></textarea>
					</div>
				</div>
			</div>
			
			<input name="estado" type="hidden" value="activo">
			<button type="submit" class="btn btn-success btn-sm mr-2">Adicionar</button>
			<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Cancelar</a>
		</form>
	</div>
</div>