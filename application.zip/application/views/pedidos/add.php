<div class="card">
	<div class="card-body">
		<h4 class="card-title">Recepci&oacute;n de Pedidos</h4>
		<div class="">
            <ul class="nav nav-tabs tab-solid tab-solid-danger" role="tablist">
                <li class="nav-item"><a class="nav-link active" id="tab-3-1" data-toggle="tab" href="#home-3-1" role="tab" aria-controls="home-3-1" aria-selected="true">Datos cliente</a></li>
                <li class="nav-item"><a class="nav-link disabled text-muted bb-tab-pedido" id="tab-3-2" data-toggle="tab" href="#profile-3-2" role="tab" aria-controls="profile-3-2" aria-selected="false">Pedido</a></li>
                <li class="nav-item"><a class="nav-link disabled text-muted" id="tab-3-3" data-toggle="tab" href="#contact-3-3" role="tab" aria-controls="contact-3-3" aria-selected="false">Pago</a></li>
            </ul>
            <div class="tab-content tab-content-basic">
				<div class="tab-pane fade show active" id="home-3-1" role="tabpanel" aria-labelledby="tab-3-1">
					<form class="forms-sample" enctype="multipart/form-data" method="post">
						<?php if (@validation_errors()) { ?>
						<?php echo validation_errors('<div class="alert alert-danger">', '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>'); ?>
						<?php } ?>
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group d-flex">
									<input name="cedula_nit" type="hidden" class="buscar_cedula_nit_data">
									<input type="text" class="form-control inp_buscar_cliente_cn" placeholder="Cedula/Nit">
									<button type="button" class="btn btn-primary ml-3 btn_buscar_cliente_cn">Buscar</button>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group row">
									<label class="col-sm-6 col-form-label pt-1 text-right"><b>Empresa</b></label>
									<div class="col-sm-3">
										<div class="form-radio mt-0">
											<label class="form-check-label"><input type="radio" class="form-check-input empresa_sis_fss" name="isempresa" id="empresa1" value="no" checked>No</label>
										</div>
									</div>
									<div class="col-sm-3">
										<div class="form-radio mt-0">
											<label class="form-check-label"><input type="radio" class="form-check-input empresa_sis_fss" name="isempresa" id="empresa2" value="si">Si</label>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group row">
									<label class="col-sm-6 text-right pt-1" for="nuevo-inp"><b>Cliente nuevo</b></label>
									<div class="col-sm-6">No <input name="cliente_nuevo" type="checkbox" class="js-switch cliente_cn_nuevo" data-color="#18cabe" data-secondary-color="#f62d51" data-size="small" value="si" checked /> Si</div>
								</div>
							</div>
						</div>
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="nombre-inp">Nombre</label>
									<input name="nombre" type="text" id="nombre-inp" class="form-control form-control-sm cliente_cn_nombre" placeholder="nombre" value="<?php echo set_value('nombre'); ?>" required>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="apellido-inp">Apellidos</label>
									<input name="apellido" type="text" id="apellido-inp" class="form-control form-control-sm cliente_cn_apellido" placeholder="apellidos" value="<?php echo set_value('apellido'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="cedula-inp">C&eacute;dula</label>
									<input name="cedula" type="text" id="cedula-inp" class="form-control form-control-sm cliente_cn_cedula" placeholder="cedula" value="<?php echo set_value('cedula'); ?>" required>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="telefono-inp">Tel&eacute;fono</label>
									<input name="telefono" type="text" id="telefono-inp" class="form-control form-control-sm cliente_cn_telefono" placeholder="telefono" value="<?php echo set_value('telefono'); ?>" required>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="email-inp">E-mail</label>
									<input name="email" type="email" id="email-inp" class="form-control form-control-sm cliente_cn_email" placeholder="email" value="<?php echo set_value('email'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="nit-inp">Nit</label>
									<input name="nit" type="text" id="nit-inp" class="form-control form-control-sm modo_emp_sis_fss cliente_cn_nit" placeholder="nit" value="<?php echo set_value('nit'); ?>" required>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="empresa-inp">Empresa</label>
									<input name="empresa" type="text" id="empresa-inp" class="form-control form-control-sm modo_emp_sis_fss cliente_cn_empresa" placeholder="empresa" value="<?php echo set_value('empresa'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="direccion-inp">Direccion</label>
									<input name="direccion" type="text" id="direccion-inp" class="form-control form-control-sm modo_emp_sis_fss cliente_cn_direccion" placeholder="direccion" value="<?php echo set_value('direccion'); ?>" required>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="telefono_empresa-inp">Tel&eacute;fono Empresa</label>
									<input name="telefono_empresa" type="text" id="telefono_empresa-inp" class="form-control form-control-sm modo_emp_sis_fss cliente_cn_telefono_empresa" placeholder="telefono empresa" value="<?php echo set_value('telefono_empresa'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
									<label for="tipo_precio-inp">Tipo de precio</label>
									<select name="tipo_precio" id="tipo_precio-inp" class="form-control cliente_cn_tipo_precio">
										<option value="1" <?php echo set_select('tipo_precio', 1,TRUE); ?>>Precio 1</option>
										<option value="2" <?php echo set_select('tipo_precio', 2); ?>>Precio 2</option>
										<option value="3" <?php echo set_select('tipo_precio', 3); ?>>Precio 3</option>
										<option value="4" <?php echo set_select('tipo_precio', 4); ?>>Precio 4</option>
									</select>
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
									<label for="bordados-inp">Bordados</label>
									<?php if($select_b_all->num_rows() > 0){ ?>
									<select name="bordados[]" id="bordados-inp" class="js-example-basic-single" multiple required style="width:100%">
										<?php foreach($select_b_all->result() as $key => $row){ ?>
										<option value="<?php echo $row->id_categoria_producto; ?>"><?php echo $row->nombre; ?></option>
										<?php } ?>
									</select>
									<?php } ?>
								</div>
							</div>
						</div>
						
						<div class="row mt-2">
							<div class="col-sm">
								<button type="submit" class="btn btn-success btn-block mt-4">Siguiente</button>
								<a href=".bb-tab-pedido" class="btn btn-primary btn-block mt-4 next-tab-go d-none">Siguiente</a>
							</div>
						</div>
						
					</form>
				</div>
				<div class="tab-pane fade" id="profile-3-2" role="tabpanel" aria-labelledby="tab-3-2">
					<div class="w-100">
						<div class="w-50 mx-auto p-3" style="background-color: #f3f3f3;border-radius: 80px;">
						<div class="row text-center">
							<div class="col-sm">
								<i class="fa fa-map-marker fa-3x"></i>
								<p class="m-0">Ubicacion</p>
							</div>
							<div class="col-sm">
								<i class="fa fa-file-text-o fa-3x"></i>
								<p class="m-0">Observaciones</p>
							</div>
							<div class="col-sm">
								<i class="fa fa-tint fa-3x"></i>
								<p class="m-0">Colores</p>
							</div>
							<div class="col-sm">
								<i class="fa fa-photo fa-3x"></i>
								<p class="m-0">Archivos</p>
							</div>
						</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-3">
							
							<div class="row">
								<div class="col-sm">
									
									<div class="">
										<div id="myCarousel_vertical" class="carousel vertical slide">
										  <div class="w-100 text-center"><a class="left carousel-control" href="#myCarousel_vertical" data-slide="prev"><i class="icon-arrow-up"></i></a></div>
										  <!-- Carousel items -->
										  <div class="custom-carousel-inner carousel-inner">
											<div class="carousel-item active">
												<table>
												  <tr>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/1.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/1.gif" class="img-fluid"></a></div></td>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/2.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/2.gif" class="img-fluid"></a></div></td>
												  </tr>
												  <tr>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/3.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/3.gif" class="img-fluid"></a></div></td>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/4.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/4.gif" class="img-fluid"></a></div></td>
												  </tr>
												  <tr>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/5.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/5.gif" class="img-fluid"></a></div></td>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/6.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/6.gif" class="img-fluid"></a></div></td>
												  </tr>
												  <tr>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/7.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/7.gif" class="img-fluid"></a></div></td>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/8.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/8.gif" class="img-fluid"></a></div></td>
												  </tr>
												  <tr>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/9.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/9.gif" class="img-fluid"></a></div></td>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/1.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/1.gif" class="img-fluid"></a></div></td>
												  </tr>
												  <tr>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/2.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/2.gif" class="img-fluid"></a></div></td>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/3.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/3.gif" class="img-fluid"></a></div></td>
												  </tr>
												</table>
											</div><!--/item-->
											<div class="carousel-item">
												<table>
												  <tr>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/1.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/1.gif" class="img-fluid"></a></div></td>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/2.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/2.gif" class="img-fluid"></a></div></td>
												  </tr>
												  <tr>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/3.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/3.gif" class="img-fluid"></a></div></td>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/4.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/4.gif" class="img-fluid"></a></div></td>
												  </tr>
												  <tr>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/5.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/5.gif" class="img-fluid"></a></div></td>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/6.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/6.gif" class="img-fluid"></a></div></td>
												  </tr>
												  <tr>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/7.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/7.gif" class="img-fluid"></a></div></td>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/8.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/8.gif" class="img-fluid"></a></div></td>
												  </tr>
												  <tr>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/9.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/9.gif" class="img-fluid"></a></div></td>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/1.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/1.gif" class="img-fluid"></a></div></td>
												  </tr>
												  <tr>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/2.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/2.gif" class="img-fluid"></a></div></td>
													<td><div class="span3"><a href="#" class="small-thumbnail"><img src="<?php echo base_url('assets/images/'); ?>image/3.gif" alt="Image" data-display="<?php echo base_url('assets/images/'); ?>image/3.gif" class="img-fluid"></a></div></td>
												  </tr>
												</table>
											</div><!--/item-->
										  </div><!--/carousel-inner--> 

										  <div class="w-100 text-center"><a class="right carousel-control" href="#myCarousel_vertical" data-slide="next"><i class="icon-arrow-down"></i></a>    </div>
										</div><!--/myCarousel-->
									</div><!--/well-->
									
									
									
									
								</div>
								<div class="col-sm">
									<div class="d-flex align-items-center h-100"><img class="img-fluid" src="<?php echo base_url('assets/images/'); ?>image/1.gif" id="DataDisplay"/></div>
								</div>
							</div>
							
						</div>
						<div class="col-sm-6">
							
						</div>
						<div class="col-sm-3">
							<div class="w-100">
								<?php if($select_b_all->num_rows() > 0){ ?>
								<div class="form-group">
								<select name="bordados" class="js-example-basic-single w-100" multiple="multiple" style="width:100%">
									<?php foreach($select_b_all->result() as $key => $row){ ?>
									<option value="<?php echo $row->id_bordado; ?>"><?php echo $row->nombre; ?></option>
									<?php } ?>
								</select>
								</div>
								<?php } ?>
							</div>
							<div class="row">
								<div class="col-sm">
									<div class="form-group">
										<label for="cant_camisas-inp">Cantidad de camisas</label>
										<input name="cant_camisas" type="text" id="cant_camisas-inp" class="form-control form-control-sm" placeholder="cantidad camisas" value="<?php echo set_value('cant_camisas'); ?>">
									</div>
								</div>
								<div class="col-sm"></div>
							</div>
							<div class="row">
								<div class="col-sm">
									<div class="form-group">
										<label for="unidad_medida-inp">Unidad de medida</label>
										<select name="unidad_medida" id="unidad_medida-inp" class="form-control">
											<option value="cm" <?php echo set_select('unidad_medida', 'cm',TRUE); ?>>Centimetros</option>
											<option value="mm" <?php echo set_select('unidad_medida', 'mm'); ?>>Milimetros</option>
											<option value="p" <?php echo set_select('unidad_medida', 'p'); ?>>Pulgadas</option>
											<option value="m" <?php echo set_select('unidad_medida', 'm'); ?>>Metros</option>
										</select>
									</div>
								</div>
								<div class="col-sm">
									<div class="form-group row">
										<label class="col-sm-12 text-right pt-1" for="medidas_iguales-inp"><b>Medidas iguales</b></label>
										<div class="col-sm-12 text-right">No <input name="medidas_iguales" type="checkbox" class="js-switch" data-color="#18cabe" data-secondary-color="#f62d51" data-size="small" value="si"/> Si</div>
									</div>
								</div>
							</div>
							
							<div class="row">
								<div class="col-sm">
									<div class="form-group row">
										<div class="col-sm-12">
											<label for="frente_izq_wh-inp">Frente Izq</label>
										</div>
										<div class="col-sm-5">
											<input name="frente_izq_w" type="text" id="frente_izq_w-inp" class="form-control form-control-sm" placeholder="10 cm" value="<?php echo set_value('frente_izq_w'); ?>">
										</div>
										<div class="col-sm-2"><p class="m-0 text-center">x</p></div>
										<div class="col-sm-5">
											<input name="frente_izq_h" type="text" id="frente_izq_h-inp" class="form-control form-control-sm" placeholder="10 cm" value="<?php echo set_value('frente_izq_h'); ?>">
										</div>
									</div>
								</div>
							</div>
							
							<div class="row">
								<div class="col-sm">
									<div class="form-group row">
										<div class="col-sm-12">
											<label for="frente_dre_wh-inp">Frente Dre</label>
										</div>
										<div class="col-sm-5">
											<input name="frente_dre_w" type="text" id="frente_dre_w-inp" class="form-control form-control-sm" placeholder="10 cm" value="<?php echo set_value('frente_dre_w'); ?>">
										</div>
										<div class="col-sm-2"><p class="m-0 text-center">x</p></div>
										<div class="col-sm-5">
											<input name="frente_dre_h" type="text" id="frente_dre_h-inp" class="form-control form-control-sm" placeholder="10 cm" value="<?php echo set_value('frente_dre_h'); ?>">
										</div>
									</div>
								</div>
							</div>
							
							<div class="row">
								<div class="col-sm">
									<div class="form-group row">
										<div class="col-sm-12">
											<label for="espalda-inp">Espalda</label>
										</div>
										<div class="col-sm-5">
											<input name="espalda_w" type="text" id="espalda_w-inp" class="form-control form-control-sm" placeholder="10 cm" value="<?php echo set_value('espalda_w'); ?>">
										</div>
										<div class="col-sm-2"><p class="m-0 text-center">x</p></div>
										<div class="col-sm-5">
											<input name="espalda_h" type="text" id="espalda_h-inp" class="form-control form-control-sm" placeholder="10 cm" value="<?php echo set_value('espalda_h'); ?>">
										</div>
									</div>
								</div>
							</div>
							
						</div>
					</div>
				</div>
				<div class="tab-pane fade" id="contact-3-3" role="tabpanel" aria-labelledby="tab-3-3">
					
				</div>
            </div>
        </div>
	</div>
</div>