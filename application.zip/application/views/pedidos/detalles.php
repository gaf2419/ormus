<?php $disabled_fss = $o_disabled?'disabled':''; ?>
<?php $disabled_required_fss = $o_disabled?'disabled':'disabled'; ?>
<div class="row d-print-block">
	<div class="col-lg-12">
		<div class="card px-2">
			<div class="card-body">
				<div class="container-fluid">
					<h3 class="my-5">Recibo <span class="float-right">#<?php echo $o->codigo; ?></span></h3>
					<hr>
				</div>
				<div class="container-fluid d-flex justify-content-between">
					<div class="col-lg-3 pl-0">
						<p class="mt-5"><b>Bordados Ormus</b></p>
						<p class="mb-0">Nit: 9000855585-7<br>Direcci&oacute;n: carrera 78 no. 1755<br>Tel: 8999999999</p>
						<p class="mb-2 m-0">Fecha: <?php echo $o->created_at; ?></p>
					</div>
					<div class="col-lg-3 pr-0">
						<p class="mt-5 mb-2 text-right"><b>Factura para</b></p>
						<p class="text-right"><?php echo $o_us->nombre .' '. $o_us->apellido; ?><br><?php echo $o_us->email; ?><br>Tel: <?php echo $o_us->telefono; ?><br>CC: <?php echo $o_us->cedula; ?></p>
					</div>
				</div>
				
				<div class="container-fluid mt-4 w-100">
							<div class="table-responsive w-100">
								<table class="table">
									<thead>
										<tr class="bg-dark text-white">
											<th>#</th>
											<th>Cantidad</th>
											<th>Producto</th>
											<th>Descripci&oacute;n</th>
											<th class="text-right">Precio</th>
										</tr>
									</thead>
									<tbody>
									<?php //valoracion_cita --- id_valoracion_cita,valoracion,cita,fecha,hora,programaciones,estado ?>
									<?php $o_bdds = explode(',',$o->bordados); ?>
									<?php if(count($o_bdds) > 0){ ?>
									<?php foreach($o_bdds as $key => $row){ ?>
									<?php $o_bbd = $this->default_model->default_get_one_where('categoria_producto', array('id_categoria_producto' => $row)); ?>
									<?php $o_bbd_p = $this->default_model->default_get_one_where('pedido_bordado', array('pedido' => $o->id_pedido,'bordado' => $row)); ?>
									<tr class="text-right">
										<td class="text-left"><?php echo $key+1; ?></td>
										<td class="text-left"><?php echo $o_bbd_p->cantidad; ?></td>
										<td class="text-left"><?php echo $o_bbd->nombre; ?></td>
										<td class="text-left"><?php echo character_limiter($o_bbd->descripcion,40); ?></td>
										<?php $bb_tp = $this->default_model->default_get_all_where('pedido_tipo_bordado',array('pedido' => $o->id_pedido,'bordado' => $row)); ?>
										<?php $sum_costo = 0; ?>
										<?php $tag_precio = 'precio'.$o_us->tipo_precio; ?>
										<?php if($bb_tp->num_rows() > 0){ ?>
										<?php foreach($bb_tp->result() as $tp_row){ ?>
										<?php $o_tybbd = $this->default_model->default_get_one_where('bordado', array('id_bordado' => $tp_row->tipo_bordado)); ?>
										<?php $sum_costo += $o_tybbd->$tag_precio; ?>
										<?php } ?>
										<?php } ?>
										<?php $sum_costo_ff = $sum_costo*$o_bbd_p->cantidad; ?>
										<td><?php echo $this->cart->format_number($sum_costo_ff); ?></td>
									</tr>
									<?php } ?>
									<?php } ?>
									</tbody>
								</table>
							</div>
				</div>
				<div class="container-fluid mt-3 w-100">
					<div class="row">
						<div class="col-sm">
							<p class="pt-4"><b>Nota:</b> Puede verificar el estado de su pedido en linea con el recibo <b><?php echo $o->codigo; ?></b>, a traves de nuestra plataforma web: <?php echo site_url('consulta'); ?></p>
						</div>
						<div class="col-sm text-right">
							<p class="mb-2">Abono: <?php echo $this->cart->format_number($o_factura->abono); ?><small class="text-danger">COP</small></p>
							<p class="mb-2">Abonado: <?php echo $this->cart->format_number($o->abonado); ?><small class="text-danger">COP</small></p>
							<p class="mb-2">Adeuda: <?php echo $this->cart->format_number($o->costo-$o->abonado); ?><small class="text-danger">COP</small></p>
							<p class="">Total: <?php echo $this->cart->format_number($o->costo); ?><small class="text-danger">COP</small></p>
						</div>
					</div>
					<hr>
				</div>
				<div class="container-fluid w-100 d-print-none">
					<a href="#" class="btn btn-primary float-right mt-3 ml-2 btn-printer-fss"><i class="mdi mdi-printer mr-1"></i>Imprimir</a>
					<a href="<?php echo site_url($controller); ?>" class="btn btn-light float-right mt-3">Cancelar</a>
				</div>
            </div>
        </div>
	</div>
</div>