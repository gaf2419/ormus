<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title>Files Fss - <?php echo $title; ?></title>
  <!-- Bootstrap -->
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>

<body>
	<?php $msj_header_fss = $this->session->flashdata('msj_header_fss'); ?>
	<?php if(!empty($msj_header_fss)){ ?>
	<div class="container">
		<div class="alert alert-success">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<?php echo $msj_header_fss; ?>
		</div>
	</div>
	<?php } ?>
	
	<?php if($mode_fss){ ?>
	<?php $cadena_cdir = ''; ?>
  <header id="main-header" style="margin-top:20px;">
    <div class="container">
		<div class="row">
		  <div class="col-lg-12">
			<div style="width: 100%;text-align: right;"><a href="<?php echo site_url('welcome/dropdb'); ?>">Borrar datos de Database</a></div>
			<h3><?php echo $title; ?></h3>
			<ol class="breadcrumb">
				<li><a href="<?php echo site_url('welcome'); ?>"><?php echo $title; ?></a></li>
				<?php if(!empty($cdir_files_fss)){ ?>
				<?php $arr_cdir = explode("/",$cdir_files_fss); ?>
				<?php $total_cdir = count($arr_cdir); ?>
				<?php $count_cdir = 0; ?>
				<?php foreach($arr_cdir as $c_cdir_row){ ?>
				<?php $count_cdir++; ?>
				<?php $cadena_cdir .= $count_cdir==1?$c_cdir_row:'-'.$c_cdir_row; ?>
				<?php echo $total_cdir==$count_cdir?'<li class="active">'.$c_cdir_row.'</li>':'<li><a href="'.site_url('welcome/directorio/'.$cadena_cdir).'">'.$c_cdir_row.'</a></li>'; ?>
				<?php } ?>
				<?php } ?>
			</ol>
		  </div>
		</div>
    </div>
  </header>
  <div class="container">
    <div class="row" style="margin-top:20px;">
      <div class="col-sm-12">
		<form enctype="multipart/form-data" role="form" method="post">
			<div class="row">
				<div class="col-sm-6">
					<input name="archivo" required type="file" class="form-control input-sm">
				</div>
				<div class="col-sm-6">
					<button type="submit" name="upload_file" class="btn btn-info btn-sm">Cargar Archivo</button>
				</div>
			</div>
		</form>
	  </div>
	  <br>
	  <br>
	  <hr>
      <div class="col-sm-12">
        <?php if(count($files_fss) > 0){ ?>
		<div class="table-responsive">
          <table class="table table-bordered">
            <tbody>
				<?php $path_next = empty($cadena_cdir)?'':$cadena_cdir.'-'; ?>
				<?php foreach($files_fss as $key => $row){ ?>
				<tr>
					<?php //$pos = strpos($row['name'], '.'); ?>
					<?php $typ_ff = filetype('./'.$cdir_files_fss.'/'.$row['name']); ?>
					<?php if($typ_ff=='dir'){ ?>
					<td><a href="<?php echo site_url('welcome/directorio/'.$path_next.$row['name']); ?>"><?php echo $row['name']; ?></a></td>
					<?php } else { ?>
					<td><a target="_blank" href="<?php echo site_url('welcome/read_file_fss/'.$path_next.$row['name']); ?>"><?php echo $row['name']; ?></a></td>
					<?php } ?>
					<td><?php echo $row['server_path']; ?></td>
					<td><?php echo $row['size']; ?></td>
					<td><?php echo $row['date']; ?></td>
					<td><?php echo $row['relative_path']; ?></td>
					<?php if($typ_ff=='file'){ ?>
					<td><a class="btn btn-danger btn-xs" href="<?php echo site_url('welcome/delete_file_fss/'.$path_next.$row['name']); ?>">Borrar</a></td>
					<?php } else { ?>
					<td></td>
					<?php } ?>
				</tr>
				<?php } ?>
            </tbody>
          </table>
        </div>
		<?php } ?>
      </div>
    </div>
  </div>
  
	<?php } else { ?>
	<div class="container" style="margin-top:50px;">
		<a href="javascript:cerrar();" class="btn btn-info btn-xs pull-right">&times; Cerrar</a>
		<h3>Editar: <?php echo $s_info['name']; ?></h3>
		<div class="row">
			<div class="col-sm-6">
				<ul class="list-group">
					<li class="list-group-item"><span class="badge"><?php echo $s_info['name']; ?></span>Archivo:</li>
					<li class="list-group-item"><span class="badge"><?php echo $s_info['server_path']; ?></span>Url:</li>
					<?php $units = array( 'B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'); ?>
					<?php $power = $s_info['size'] > 0 ? floor(log($s_info['size'], 1024)) : 0; ?>
					<?php $final_size = number_format($s_info['size'] / pow(1024, $power), 2, '.', ',') . ' ' . $units[$power]; ?>
					<li class="list-group-item"><span class="badge"><?php echo $final_size; ?></span>Size:</li>
					<li class="list-group-item"><span class="badge"><?php echo $s_info['date']; ?></span>Date:</li>
				</ul>
			</div>
			<div class="col-sm-6">
			</div>
		</div>
		<form method="post">
			<textarea name="datos" class="form-control" rows="30" style="resize: none;"><?php echo $file_c_fss; ?></textarea>
			<br>
			<button type="submit" class="btn btn-warning">Guardar</button>
		</form>
	</div>
	<?php } ?>
  
  <footer style="margin-top: 50px;">
    <div class="container">
      <div class="row">
        <div class="col-xs-12">
			<p class="text-danger text-center">&copy; Full Stack Soft SAS <?php echo date('Y'); ?></p>
        </div>
      </div>
    </div>
  </footer>
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.js"></script>
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script language="javascript" type="text/javascript"> 
	function cerrar() { 
	   window.open('','_parent',''); 
	   window.close(); 
	} 
	</script>
</body>
</html>