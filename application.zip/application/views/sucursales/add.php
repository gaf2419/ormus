<div class="card">
	<div class="card-body">
		<h4 class="card-title"><?php echo $title_page; ?></h4>
		<form class="forms-sample" enctype="multipart/form-data" method="post">
			<?php if (@validation_errors()) { ?>
			<?php echo validation_errors('<div class="alert alert-danger">', '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>'); ?>
			<?php } ?>
			
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="nombre-inp">Nombre</label>
						<input name="nombre" type="text" id="nombre-inp" class="form-control form-control-sm" placeholder="nombre" value="<?php echo set_value('nombre'); ?>" required>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="usuario-inp">Usuario</label>
						<?php if($select_us_all->num_rows() > 0){ ?>
						<select name="usuario" id="usuario-inp" class="js-example-basic-single" style="width:100%">
							<?php foreach($select_us_all->result() as $key => $row){ ?>
							<option value="<?php echo $row->id_usuario; ?>"><?php echo $row->nombre .' '. $row->apellido; ?></option>
							<?php } ?>
						</select>
						<?php } ?>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="modulos-inp">Modulos</label>
						<?php if(count($select_m_all) > 0){ ?>
						<select name="modulos[]" id="modulos-inp" class="js-example-basic-single" multiple style="width:100%">
							<?php foreach($select_m_all as $key => $row){ ?>
							<option value="<?php echo $key; ?>"><?php echo $row; ?></option>
							<?php } ?>
						</select>
						<?php } ?>
					</div>
				</div>
			</div>
			
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="direccion-inp">Direcci&oacute;n</label>
						<textarea name="direccion" rows="2" id="direccion-inp" class="form-control form-control-sm" placeholder="Direcci&oacute;n"><?php echo set_value('direccion'); ?></textarea>
					</div>
				</div>
			</div>
			
			<input name="estado" type="hidden" value="activo">
			<button type="submit" class="btn btn-success btn-sm mr-2">Adicionar</button>
			<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Cancelar</a>
		</form>
	</div>
</div>