<div class="card">
	<div class="card-body">
		<h4 class="card-title">Adicionar Venta de Productos <small class="text-lowercase text-warning float-right">Nota: primero elejir el cliente, despues agregar los productos.</small></h4>
		
		<div class="row mt-2 border border-info p-3">
			<div class="col-sm">
				<div class="form-group">
					<label for="productos_base">Productos</label>
					<?php if($select_p_all->num_rows() > 0){ ?>
					<select name="productos[]" id="productos_base" class="js-example-basic-single" style="width:100%">
						<?php foreach($select_p_all->result() as $key => $row){ ?>
						<option value="<?php echo $row->id_producto; ?>" data-namepro="<?php echo $row->nombre; ?>" data-preciopro="<?php echo $row->precio1 .','. $row->precio2 .','. $row->precio3 .','. $row->precio4; ?>"><?php echo $row->nombre; ?></option>
						<?php } ?>
					</select>
					<?php } ?>
				</div>
			</div>
			<div class="col-sm">
				<div class="form-group">
					<label for="cantidad_base">Cantidad</label>
					<input name="cantidad" type="number" min="1" id="cantidad_base" class="form-control form-control-sm" placeholder="cantidad" value="1">
				</div>
			</div>
			<div class="col-sm">
				<button type="button" class="btn btn-primary btn-sm mt-4 btn-add-cart-fact-fss">Adicionar</button>
			</div>
		</div>
		
		<form class="forms-sample mt-3" enctype="multipart/form-data" method="post">
			<?php if (@validation_errors()) { ?>
			<?php echo validation_errors('<div class="alert alert-danger">', '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>'); ?>
			<?php } ?>
			
			<div class="row my-2">
				<div class="col-sm-6">
					<div class="form-group">
						<label for="cliente_base">Cliente</label>
						<?php if($select_c_all->num_rows() > 0){ ?>
						<select name="cliente" id="cliente_base" class="js-example-basic-single" style="width:100%">
							<?php foreach($select_c_all->result() as $key => $row){ ?>
							<option value="<?php echo $row->id_usuario; ?>" data-tipoprecio="<?php echo $row->tipo_precio; ?>"><?php echo $row->nombre .' '. $row->apellido; ?></option>
							<?php } ?>
						</select>
						<?php } ?>
					</div>
				</div>
				<div class="col-sm-12">
					<div class="table-responsive my-4">
						<table class="table">
							<thead>
								<tr>
									<th>Producto</th>
									<th>Cantidad</th>
									<th>Costo</th>
									<th></th>
								</tr>
							</thead>
							<tbody class="box-inpts-pdts">
							</tbody>
						</table>
					</div>
					<h6 class="text-right">Total: <span class="totalinnfssnn">0</span></h6>
				</div>
			</div>
			
			<input name="estado" type="hidden" value="activo">
			<button type="submit" class="btn btn-success btn-sm mr-2">Adicionar</button>
			<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Cancelar</a>
		</form>
	</div>
</div>