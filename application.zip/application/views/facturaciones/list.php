<div class="row">
    <div class="col-lg-12">
        <div class="card px-3">
            <div class="card-body">
                <h4 class="card-title">Facturaciones <a class="btn btn-info btn-sm float-right" href="<?php echo site_url($controller.'/caja'); ?>"><i class="fa fa-money"></i> Caja</a></h4>
				<ul class="nav nav-tabs tab-basic" role="tablist">
                    <li class="nav-item"><a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Pedidos</a></li>
                    <li class="nav-item"><a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Productos</a></li>
                </ul>
				<div class="tab-content tab-content-basic">
					<div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
						
						<h4 class="card-title">Facturaciones de Pedidos <span class="container-excel-fss1 float-right"></span></h4>
						<div class="row">
							<div class="col-12">
								<div class="table-responsive">
								<?php if($o_all->num_rows() > 0) { ?>
								<table class="table order-listing excel_x" data-containerexcel=".container-excel-fss1">
									<thead>
									<tr>
										<th>#</th>
										<th>recibo</th>
										<th>cliente</th>
										<th>creacion</th>
										<th>entrega</th>
										<th>costo</th>
										<th>abonado</th>
										<th>falta</th>
										<th>estado</th>
										<th class="no-sort text-center">Acciones</th>
									</tr>
									</thead>
									<tbody>
									
									<?php $arr_sstads = array('solicitado' => 'Solicitado','tarea' => 'Elaboraci&oacute;n','preaprobado' => 'Revisi&oacute;n','aprobado' => 'Finalizado'); ?>
									<?php $arr_labels = array('solicitado' => 'info','tarea' => 'primary','preaprobado' => 'warning','aprobado' => 'success'); ?>
									<?php foreach($o_all->result() as $key => $row){ ?>
									<tr>
										<td><?php echo $key+1; ?></td>
										<td><?php echo $row->codigo; ?></td>
										<?php $o_us = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $row->usuario)); ?>
										<td><?php echo $o_us->nombre .' '. $o_us->apellido .' - '. $o_us->email; ?></td>
										<td><?php echo $row->created_at; ?></td>
										<td><?php echo $row->fecha_entrega; ?></td>
										<td><?php echo str_replace('.00','',$this->cart->format_number($row->costo)); ?></td>
										<td><?php echo str_replace('.00','',$this->cart->format_number($row->abonado)); ?></td>
										<td><?php echo str_replace('.00','',$this->cart->format_number($row->costo - $row->abonado)); ?></td>
										<td><span class="badge badge-outline-<?php echo $arr_labels[$row->estado]; ?> badge-pill"><?php echo $arr_sstads[$row->estado]; ?></span></td>
										<td class="text-center">
										  <a class="text-warning" href="<?php echo site_url($controller.'/facturas/'.$row->$id_o); ?>"><i class="fa fa-book fa-lg m-0"></i></a>
										  <a class="text-primary ml-2" href="<?php echo site_url($controller.'/historial/'.$row->$id_o); ?>"><i class="fa fa-eye fa-lg m-0"></i></a>
										</td>
									</tr>
									<?php } ?>
									</tbody>
								</table>
								<?php } else { ?>
								<h5 class="text-warning">Lo sentimos!!! No existen Facturaciones de Pedidos en los registros de la plataforma.</h5>
								<?php } ?>
								</div>
							</div>
						</div>
						
					</div>
					<div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
						<h4 class="card-title">Facturaciones de Productos <a class="btn btn-success btn-sm ml-2 float-right" href="<?php echo site_url($controller.'/add'); ?>"><i class="icon-plus menu-icon"></i> adicionar</a> <span class="container-excel-fss2 float-right"></span></h4>
						<div class="row">
							<div class="col-12">
								<div class="table-responsive">
								<?php if($o_v_all->num_rows() > 0) { ?>
								<table class="table order-listing excel_x" data-containerexcel=".container-excel-fss2">
									<thead>
									<tr>
										<th>#</th>
										<th>recibo</th>
										<th>cliente</th>
										<th>vendedor</th>
										<th>total</th>
										<th>fecha</th>
										<th class="no-sort text-center">Acciones</th>
									</tr>
									</thead>
									<tbody>
									<?php foreach($o_v_all->result() as $key => $row){ ?>
									<tr>
										<td><?php echo $key+1; ?></td>
										<td><?php echo $row->factura; ?></td>
										<?php $o_us = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $row->cliente)); ?>
										<td><?php echo $o_us->nombre .' '. $o_us->apellido .' - '. $o_us->email; ?></td>
										<?php $o_us = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $row->vendedor)); ?>
										<td><?php echo $o_us->nombre .' '. $o_us->apellido .' - '. $o_us->email; ?></td>
										<td><?php echo $this->cart->format_number($row->total); ?></td>
										<td><?php echo $row->created_at; ?></td>
										<td class="text-center">
										  <a class="text-warning ml-3" href="<?php echo site_url($controller.'/venta/'.$row->id_venta); ?>"><i class="fa fa-print fa-lg m-0"></i></a>
										</td>
									</tr>
									<?php } ?>
									</tbody>
								</table>
								<?php } else { ?>
								<h5 class="text-warning">Lo sentimos!!! No existen Facturaciones de Productos en los registros de la plataforma.</h5>
								<?php } ?>
								</div>
							</div>
						</div>
					</div>
				</div>
            </div>
        </div>
    </div>
</div>