<?php $disabled_fss = $o_disabled?'disabled':''; ?>
<?php $disabled_required_fss = $o_disabled?'disabled':'disabled'; ?>
<div class="row d-print-block">
	<div class="col-lg-12">
		<div class="card px-2">
			<div class="card-body">
				<div class="container-fluid">
					<h3 class="my-5">Recibo <span class="float-right">#<?php echo $o->factura; ?></span></h3>
					<hr>
				</div>
				<div class="container-fluid d-flex justify-content-between">
					<div class="col-lg-3 pl-0">
						<p class="mt-5"><b>Bordados Ormus</b></p>
						<p class="mb-0">Nit: 9000855585-7<br>Direcci&oacute;n: carrera 78 no. 1755<br>Tel: 8999999999</p>
						<p class="mb-2 m-0">Fecha: <?php echo $o->created_at; ?></p>
					</div>
					<div class="col-lg-3 pr-0">
						<p class="mt-5 mb-2 text-right"><b>Factura para</b></p>
						<p class="text-right"><?php echo $o_us->nombre .' '. $o_us->apellido; ?><br><?php echo $o_us->email; ?><br>Tel: <?php echo $o_us->telefono; ?><br>CC: <?php echo $o_us->cedula; ?></p>
					</div>
				</div>
				
				<div class="container-fluid mt-4 w-100">
							<div class="table-responsive w-100">
								<table class="table">
									<thead>
										<tr class="bg-dark text-white">
											<th>#</th>
											<th>Producto</th>
											<th>Descripci&oacute;n</th>
											<th>Cantidad</th>
											<th class="text-right">Precio</th>
										</tr>
									</thead>
									<tbody>
									<?php //valoracion_cita --- id_valoracion_cita,valoracion,cita,fecha,hora,programaciones,estado ?>
									<?php $o_bdds = explode(',',$o->productos); ?>
									<?php $o_cants = explode(',',$o->cantidades); ?>
									<?php if(count($o_bdds) > 0){ ?>
									<?php $tag_precio = 'precio'.$o_us->tipo_precio; ?>
									<?php foreach($o_bdds as $key => $row){ ?>
									<?php $o_bbd = $this->default_model->default_get_one_where('producto', array('id_producto' => $row)); ?>
									<tr class="text-right">
										<td class="text-left"><?php echo $key+1; ?></td>
										<td class="text-left"><?php echo $o_bbd->nombre; ?></td>
										<td class="text-left"><?php echo character_limiter($o_bbd->descripcion,40); ?></td>
										<td class="text-left"><?php echo $o_cants[$key]; ?></td>
										<td><?php echo $this->cart->format_number($o_bbd->$tag_precio*$o_cants[$key]); ?></td>
									</tr>
									<?php } ?>
									<?php } ?>
									</tbody>
								</table>
							</div>
				</div>
				<div class="container-fluid mt-3 w-100">
					<div class="row">
						<div class="col-sm">
						</div>
						<div class="col-sm text-right">
							<p class="">Total: <?php echo $this->cart->format_number($o->total); ?><small class="text-danger">COP</small></p>
						</div>
					</div>
					<hr>
				</div>
				<div class="container-fluid w-100 d-print-none">
					<a href="#" class="btn btn-primary float-right mt-3 ml-2 btn-printer-fss"><i class="mdi mdi-printer mr-1"></i>Imprimir</a>
					<a href="<?php echo site_url($controller); ?>" class="btn btn-light float-right mt-3">Cancelar</a>
				</div>
            </div>
        </div>
	</div>
</div>