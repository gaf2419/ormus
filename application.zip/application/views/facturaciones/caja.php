<?php if(@$o_inicio_caja){ ?>
	<div class="modal fade" id="inicio_caja_Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel-2" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel-2">Inicio de Caja</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form class="forms-sample-close-caja">
                        <div class="form-group">
                          <label for="valrecibido-inp">Valor Recibido</label>
                          <input type="text" class="form-control form-control-sm inp-ini-valor" id="valrecibido-inp" placeholder="valor">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success btn-procesar-inicio-caja-fss" data-urlform="<?php echo site_url('facturaciones'); ?>">Procesar</button>
                    <button type="button" class="btn btn-light" data-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Ends -->
	<?php } ?>
	<?php if(@$o_cierre_caja){ ?>
	<div class="modal fade" id="cierre_caja_Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel-2" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel-2">Cierre de Caja</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form class="forms-sample-close-caja">
                        <div class="msj-succ"></div>
                        <div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
								  <label for="cincuenta-inp">50</label>
								  <input type="number" min="0" class="form-control form-control-sm inp-cierre-cincuenta" id="cincuenta-inp" placeholder="cincuenta">
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
								  <label for="cien-inp">100</label>
								  <input type="number" min="0" class="form-control form-control-sm inp-cierre-cien" id="cien-inp" placeholder="cien">
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
								  <label for="doscientos-inp">200</label>
								  <input type="number" min="0" class="form-control form-control-sm inp-cierre-doscientos" id="valrecibido-inp" placeholder="doscientos">
								</div>
							</div>
						</div>
						
                        <div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
								  <label for="quinientos-inp">500</label>
								  <input type="number" min="0" class="form-control form-control-sm inp-cierre-quinientos" id="quinientos-inp" placeholder="quinientos">
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
								  <label for="mil-inp">1000</label>
								  <input type="text" class="form-control form-control-sm inp-cierre-mil" id="mil-inp" placeholder="mil">
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
								  <label for="dosmil-inp">2 mil</label>
								  <input type="number" min="0" class="form-control form-control-sm inp-cierre-dosmil" id="dosmil-inp" placeholder="dos mil">
								</div>
							</div>
						</div>
						
                        <div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
								  <label for="cincomil-inp">5 mil</label>
								  <input type="number" min="0" class="form-control form-control-sm inp-cierre-cincomil" id="cincomil-inp" placeholder="cinco mil">
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
								  <label for="diezmil-inp">10 mil</label>
								  <input type="text" class="form-control form-control-sm inp-cierre-diezmil" id="diezmil-inp" placeholder="diez mil">
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
								  <label for="veintemil-inp">20 mil</label>
								  <input type="number" min="0" class="form-control form-control-sm inp-cierre-veintemil" id="veintemil-inp" placeholder="veinte mil">
								</div>
							</div>
						</div>
						
                        <div class="row mt-2">
							<div class="col-sm">
								<div class="form-group">
								  <label for="cincuentamil-inp">50 mil</label>
								  <input type="number" min="0" class="form-control form-control-sm inp-cierre-cincuentamil" id="cincuentamil-inp" placeholder="cincuenta mil">
								</div>
							</div>
							<div class="col-sm">
								<div class="form-group">
								  <label for="cienmil-inp">100 mil</label>
								  <input type="text" class="form-control form-control-sm inp-cierre-cienmil" id="cienmil-inp" placeholder="cien mil">
								</div>
							</div>
							<div class="col-sm">
							</div>
						</div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success btn-procesar-cierre-caja-fss" data-urlform="<?php echo site_url('facturaciones'); ?>">Procesar</button>
                    <button type="button" class="btn btn-light" data-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Ends -->
	<?php } ?>




<div class="card">
	<div class="card-body">
		<h4 class="card-title">Caja
		<?php if(@$o_inicio_caja){ ?>
		<a class="btn btn-danger btn-sm float-right" href="#" data-toggle="modal" data-target="#inicio_caja_Modal"><i class="icon-settings"></i> Iniciar</a>
		<?php } ?>
		<?php if(@$o_cierre_caja){ ?>
		<a class="btn btn-success btn-sm float-right" href="#" data-toggle="modal" data-target="#cierre_caja_Modal"><i class="icon-settings"></i> Cerrar</a>
		<?php } ?>
		</h4>
		<div class="row">
			<div class="col-sm">
				<form method="post">
					<div class="row">
						<div class="col-sm">
							<div id="datepicker-mesyear" class="input-group date datepicker">
								<input name="d_date" type="text" class="form-control" value="<?php echo $d_date; ?>">
								<div class="input-group-addon input-group-text">
									<span class="mdi mdi-calendar"></span>
								</div>
							</div>
						</div>
						<div class="col-sm">
							<button class="btn btn-primary btn-block" style="margin-top: 5px;" type="submit">Actualizar</button>
						</div>
					</div>
				</form>
			</div>
			<div class="col-sm">
			</div>
			<div class="col-sm">
				<div id="container-excel-fss" class="w-100 mb-2 text-right"></div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="table-responsive">
					<table id="order-listing" class="table">
						<thead>
							<tr class="text-right">
								<th class="text-center">#</th>
								<?php if($this->session->$session_role->rol == 'administrator') { ?>
								<th class="text-left">usuario</th>
								<?php } ?>
								<th>50</th>
								<th>100</th>
								<th>200</th>
								<th>500</th>
								<th>mil</th>
								<th>2 mil</th>
								<th>5 mil</th>
								<th>10 mil</th>
								<th>20 mil</th>
								<th>50 mil</th>
								<th>100 mil</th>
								<th>entrada</th>
								<th>salida</th>
								<th>vendido</th>
								<th>descuadre</th>
								<th>fecha</th>
								<th>inicio</th>
								<th>cierre</th>
								<th>estado</th>
							</tr>
						</thead>
						<tbody>
							<?php if($o_all->num_rows() > 0){ ?>
							<?php $arr_users_id = array(); ?>
							<?php $arr_users_name = array(); ?>
							<?php foreach($o_all->result() as $key => $row){ ?>
							<tr class="text-right">
								<td class="text-center"><?php echo $key+1; ?></td>
								<?php if($this->session->$session_role->rol == 'administrator') { ?>
								<?php
								$name_user = 'Desconocido';
								if(!in_array($row->usuario,$arr_users_id)){
									array_push($arr_users_id,$row->usuario);
									$us = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $row->usuario));
									$name_user = !empty($us->nombre)?$us->nombre.' '.$us->apellido:$us->email;
									$name_user = !empty($name_user)?$name_user:'Desconocido';
									$arr_users_name[$row->usuario] = $name_user;
								} else {
									$name_user = $arr_users_name[$row->usuario];
								}
								?>
								<td class="text-left"><?php echo $name_user; ?></td>
								<?php } ?>
								<td><?php echo $row->cincuenta; ?></td>
								<td><?php echo $row->cien; ?></td>
								<td><?php echo $row->doscientos; ?></td>
								<td><?php echo $row->quinientos; ?></td>
								<td><?php echo $row->mil; ?></td>
								<td><?php echo $row->dosmil; ?></td>
								<td><?php echo $row->cincomil; ?></td>
								<td><?php echo $row->diezmil; ?></td>
								<td><?php echo $row->veintemil; ?></td>
								<td><?php echo $row->cincuentamil; ?></td>
								<td><?php echo $row->cienmil; ?></td>
								<td><small><?php echo $row->entrada; ?></small></td>
								<td><small><?php echo $row->salida; ?></small></td>
								<td><small><?php echo $row->vendido; ?></small></td>
								<td><small><?php echo $row->descuadre; ?></small></td>
								<td><small><?php echo $row->fecha; ?></small></td>
								<td><small><?php echo $row->inicio; ?></small></td>
								<td><small><?php echo $row->cierre; ?></small></td>
								<td><small><?php echo $row->estado_caja; ?></small></td>
							</tr>
							<?php } ?>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>