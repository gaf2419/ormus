<div class="card">
    <div class="card-body">
              <h4 class="card-title"><?php echo $title_page; ?></h4>
              <div id="container-excel-fss" class="w-100 mb-2 text-right"></div>
			  <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
				  <?php if($o_all->num_rows() > 0) { ?>
                    <table id="order-listing" class="table">
                      <thead>
                        <tr>
							<th>#</th>
                            <th>Pedido</th>
							<th>Abono</th>
							<th>Fecha</th>
							<th class="no-sort text-center">Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
						<?php $arr_users_id = array(); ?>
						<?php $arr_users_name = array(); ?>
					  <?php foreach($o_all->result() as $key => $row){ ?>
                        <tr>
							<td><?php echo $key+1; ?></td>
                            <?php $pedd = $this->default_model->default_get_one_where('pedido', array('id_pedido' => $row->pedido)); ?>
                            <td><?php echo $pedd->codigo; ?></td>
							<td><?php echo $this->cart->format_number($row->abono); ?></td>
							<td><?php echo $row->fecha; ?></td>
							<td class="text-center">
                              <a class="text-warning ml-3" href="<?php echo site_url($controller.'/details/'.$row->id_pedido_abono); ?>"><i class="fa fa-print fa-lg m-0"></i></a>
							</td>
                        </tr>
					  <?php } ?>
                      </tbody>
                    </table>
				  <?php } else { ?>
				  <h5 class="text-warning">Lo sentimos!!! No existen <?php echo $active_mod; ?> en los registros de la plataforma.</h5>
				  <?php } ?>
                  </div>
                </div>
              </div>
    </div>
</div>