<div class="card">
	<div class="card-body">
		<h4 class="card-title"><?php echo $title_page; ?></h4>
		<form class="forms-sample" enctype="multipart/form-data" method="post">
			<?php if (@validation_errors()) { ?>
			<?php echo validation_errors('<div class="alert alert-danger">', '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>'); ?>
			<?php } ?>
			
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="nombre-inp">Nombre</label>
						<input name="nombre" type="text" id="nombre-inp" class="form-control form-control-sm" placeholder="nombre" value="<?php echo set_value('nombre'); ?>" required>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group row pt-4">
						<label class="col-sm-4 col-form-label text-right pt-3"><b>Tipo</b></label>
						<div class="col-sm-4">
                            <div class="form-radio">
								<label class="form-check-label"><input type="radio" class="form-check-input" name="tipo" id="tipo1" value="Definido" checked>Definido</label>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-radio">
								<label class="form-check-label"><input type="radio" class="form-check-input" name="tipo" id="tipo2" value="No Definido">No Definido</label>
                            </div>
                        </div>
					</div>
				</div>
			</div>
			
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="bordados-inp">Bordados</label>
						<?php if($select_b_all->num_rows() > 0){ ?>
						<select name="bordados[]" id="bordados-inp" class="js-example-basic-single" multiple style="width:100%">
							<?php foreach($select_b_all->result() as $key => $row){ ?>
							<option value="<?php echo $row->id_bordado; ?>"><?php echo $row->nombre; ?></option>
							<?php } ?>
						</select>
						<?php } ?>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="maquina-inp">Maquina</label>
						<?php if($select_m_all->num_rows() > 0){ ?>
						<select name="maquina" id="maquina-inp" class="js-example-basic-single" style="width:100%">
							<?php foreach($select_m_all->result() as $key => $row){ ?>
							<option value="<?php echo $row->id_maquina; ?>"><?php echo $row->nombre; ?></option>
							<?php } ?>
						</select>
						<?php } ?>
					</div>
				</div>
			</div>
			
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="descripcion-inp">Descripci&oacute;n</label>
						<textarea name="descripcion" rows="2" id="descripcion-inp" class="form-control form-control-sm" placeholder="Descripci&oacute;n"><?php echo set_value('descripcion'); ?></textarea>
					</div>
				</div>
			</div>
			
			<input name="estado" type="hidden" value="activo">
			<button type="submit" class="btn btn-success btn-sm mr-2">Adicionar</button>
			<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Cancelar</a>
		</form>
	</div>
</div>