<?php $disabled_fss = $o_disabled?'disabled':''; ?>
<?php $disabled_required_fss = $o_disabled?'disabled':'required'; ?>
<div class="card">
	<div class="card-body">
		<h4 class="card-title text-warning"><?php echo $title_page; ?></h4>
		<form class="forms-sample" enctype="multipart/form-data" method="post">
			<?php if (@validation_errors()) { ?>
			<?php echo validation_errors('<div class="alert alert-danger">', '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>'); ?>
			<?php } ?>
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="nombre-inp">Nombre</label>
						<input name="nombre" type="text" id="nombre-inp" class="form-control form-control-sm" placeholder="nombre" value="<?php echo !empty($_POST)?set_value('nombre'):$o->nombre; ?>" <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group row pt-4">
						<label class="col-sm-4 col-form-label text-right pt-3"><b>Tipo</b></label>
						<div class="col-sm-4">
                            <div class="form-radio">
								<label class="form-check-label"><input type="radio" class="form-check-input" name="tipo" id="tipo1" value="Definido" <?php echo $o->tipo=='Definido'?'checked':''; ?> <?php echo $disabled_required_fss; ?>>Definido</label>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-radio">
								<label class="form-check-label"><input type="radio" class="form-check-input" name="tipo" id="tipo2" value="No Definido" <?php echo $o->tipo=='No Definido'?'checked':''; ?> <?php echo $disabled_required_fss; ?>>No Definido</label>
                            </div>
                        </div>
					</div>
				</div>
			</div>
			
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="bordados-inp">Bordados</label>
						<?php if($select_b_all->num_rows() > 0){ ?>
						<select name="bordados[]" id="bordados-inp" class="js-example-basic-single" multiple style="width:100%" <?php echo $disabled_required_fss; ?>>
							<?php $bs_arr = explode(",",$o->bordados); ?>
							<?php foreach($select_b_all->result() as $key => $row){ ?>
							<option value="<?php echo $row->id_bordado; ?>" <?php echo in_array($row->id_bordado,$bs_arr)?'selected':''; ?>><?php echo $row->nombre; ?></option>
							<?php } ?>
						</select>
						<?php } ?>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="maquina-inp">Maquina</label>
						<?php if($select_m_all->num_rows() > 0){ ?>
						<select name="maquina" id="maquina-inp" class="js-example-basic-single" style="width:100%" <?php echo $disabled_required_fss; ?>>
							<?php foreach($select_m_all->result() as $key => $row){ ?>
							<option value="<?php echo $row->id_maquina; ?>" <?php echo !empty($_POST)?set_select('maquina', $row->id_maquina):$o->maquina==$row->id_maquina?'selected':''; ?>><?php echo $row->nombre; ?></option>
							<?php } ?>
						</select>
						<?php } ?>
					</div>
				</div>
			</div>
			
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="descripcion-inp">Descripci&oacute;n</label>
						<textarea name="descripcion" rows="2" id="descripcion-inp" class="form-control form-control-sm" placeholder="Descripci&oacute;n" <?php echo $disabled_fss; ?>><?php echo !empty($_POST)?set_value('descripcion'):$o->descripcion; ?></textarea>
					</div>
				</div>
			</div>
			
			<?php if(!$o_disabled){ ?>
			<button type="submit" class="btn btn-warning btn-sm mr-2">Actualizar</button>
			<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Cancelar</a>
			<?php } else { ?>
			<a href="<?php echo site_url($controller.'/update/'.$o->$id_o); ?>" class="btn btn-warning btn-sm mr-2">Editar</a>
			<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Regresar</a>
			<?php } ?>
		</form>
	</div>
</div>
