<div class="card">
	<div class="card-body">
		<h4 class="card-title"><?php echo $title; ?></h4>
		<div class="row">
			<div class="col-sm">
				<form method="post">
					<div class="row">
						<div class="col-sm">
							<div id="date_select_nn_fss" class="input-group date datepicker">
								<input name="d_date" type="text" class="form-control" value="<?php echo $d_date; ?>">
								<div class="input-group-addon input-group-text">
									<span class="mdi mdi-calendar"></span>
								</div>
							</div>
						</div>
						<div class="col-sm">
							<button class="btn btn-primary btn-block" style="margin-top: 5px;" type="submit">Actualizar</button>
						</div>
					</div>
				</form>
			</div>
			<div class="col-sm">
			</div>
			<div class="col-sm">
				<div id="container-excel-fss" class="w-100 mb-2 text-right"></div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="table-responsive">
					<table class="table order-listing excel">
						<thead>
							<tr class="text-right">
								<th class="text-center">#</th>
								<?php if($this->session->$session_role->rol == 'administrator') { ?>
								<th class="text-left">usuario</th>
								<?php } ?>
								<th>50</th>
								<th>100</th>
								<th>200</th>
								<th>500</th>
								<th>1000</th>
								<th>2000</th>
								<th>5000</th>
								<th>10 mil</th>
								<th>20 mil</th>
								<th>50 mil</th>
								<th>100 mil</th>
								<th>Tipo</th>
								<th>fecha</th>
								<th>Vendido</th>
								<th>Total</th>
							</tr>
						</thead>
						<tbody>
							<?php if($o_all->num_rows() > 0){ ?>
							<?php $arr_users_id = array(); ?>
							<?php $arr_users_name = array(); ?>
							<?php foreach($o_all->result() as $key => $row){ ?>
							<tr class="text-right">
								<td class="text-center"><?php echo $key+1; ?></td>
								<?php if($this->session->$session_role->rol == 'administrator') { ?>
								<?php
								$name_user = 'Desconocido';
								if(!in_array($row->usuario,$arr_users_id)){
									array_push($arr_users_id,$row->usuario);
									$us = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $row->usuario));
									$name_user = !empty($us->nombre)?$us->nombre.' '.$us->apellido:$us->email;
									$name_user = !empty($name_user)?$name_user:'Desconocido';
									$arr_users_name[$row->usuario] = $name_user;
								} else {
									$name_user = $arr_users_name[$row->usuario];
								}
								?>
								<td class="text-left"><?php echo $name_user; ?></td>
								<?php } ?>
								<td><?php echo $row->cincuenta; ?></td>
								<td><?php echo $row->cien; ?></td>
								<td><?php echo $row->doscientos; ?></td>
								<td><?php echo $row->quinientos; ?></td>
								<td><?php echo $row->mil; ?></td>
								<td><?php echo $row->dosmil; ?></td>
								<td><?php echo $row->cincomil; ?></td>
								<td><?php echo $row->diezmil; ?></td>
								<td><?php echo $row->veintemil; ?></td>
								<td><?php echo $row->cincuentamil; ?></td>
								<td><?php echo $row->cienmil; ?></td>
								<td><small><?php echo $row->categoria; ?></small></td>
								<td><small><?php echo $row->fecha; ?></small></td>
								<?php if($row->categoria=='cierre'){ ?>
								<?php $sql_total="SELECT sum(total) as subtotal FROM `ingreso` WHERE fecha ='".date('Y-m-d')."' && tipo='efectivo' && recibido_user=".$row->usuario; ?>
								<?php $t_bb = $this->default_model->default_query_execute($sql_total)->row()->subtotal; ?>
								<td><?php echo $this->cart->format_number($t_bb); ?> <small class="text-danger">COP</small></td>
								<?php } else { ?>
								<td></td>
								<?php } ?>
								<td><?php echo $this->cart->format_number($row->total); ?> <small class="text-danger">COP</small></td>
							</tr>
							<?php } ?>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>