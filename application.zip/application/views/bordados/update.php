<?php $disabled_fss = $o_disabled?'disabled':''; ?>
<?php $disabled_required_fss = $o_disabled?'disabled':'required'; ?>
<div class="card">
	<div class="card-body">
		<h4 class="card-title text-warning"><?php echo $title_page; ?></h4>
		<form class="forms-sample" enctype="multipart/form-data" method="post">
			<?php if (@validation_errors()) { ?>
			<?php echo validation_errors('<div class="alert alert-danger">', '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>'); ?>
			<?php } ?>
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="nombre-inp">Nombre</label>
						<input name="nombre" type="text" id="nombre-inp" class="form-control form-control-sm" placeholder="nombre" value="<?php echo !empty($_POST)?set_value('nombre'):$o->nombre; ?>" <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="alto-inp">Alto</label>
						<input name="alto" type="text" id="alto-inp" class="form-control form-control-sm" placeholder="alto" value="<?php echo !empty($_POST)?set_value('alto'):$o->alto; ?>" <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="ancho-inp">Ancho</label>
						<input name="ancho" type="text" id="ancho-inp" class="form-control form-control-sm" placeholder="ancho" value="<?php echo !empty($_POST)?set_value('ancho'):$o->ancho; ?>" <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
			</div>
			
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="foto-inp">foto</label>
						<img src="<?php echo !empty($o->foto)?base_url('uploads/'.$url_b_uploads.'/thumbs/'.$o->foto):base_url('assets/images/not-found.png'); ?>" style="max-width: 80px;">
					</div>
				</div>
				<div class="col-sm">
					<?php if(!$o_disabled){ ?>
					<div class="form-group">
						<label for="foto1-inp">Foto</label>
						<input name="foto" type="file" id="foto1-inp" class="file-upload-default">
						<div class="input-group col-xs-12">
							<input type="text" class="form-control form-control-sm file-upload-info" disabled placeholder="Cargar imagen">
							<div class="input-group-append">
							  <button class="file-upload-browse btn btn-info" type="button">Cargar</button>                          
							</div>
						</div>
					</div>
					<?php } ?>
				</div>
			</div>
			
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="precio1-inp">Precio 1</label>
						<input name="precio1" type="text" id="precio1-inp" class="form-control form-control-sm" placeholder="precio 1" value="<?php echo !empty($_POST)?set_value('precio1'):$o->precio1; ?>" <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="precio2-inp">Precio 2</label>
						<input name="precio2" type="text" id="precio2-inp" class="form-control form-control-sm" placeholder="precio 2" value="<?php echo !empty($_POST)?set_value('precio2'):$o->precio2; ?>" <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="precio3-inp">Precio 3</label>
						<input name="precio3" type="text" id="precio3-inp" class="form-control form-control-sm" placeholder="precio 3" value="<?php echo !empty($_POST)?set_value('precio3'):$o->precio3; ?>" <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="precio4-inp">Precio 4</label>
						<input name="precio4" type="text" id="precio4-inp" class="form-control form-control-sm" placeholder="precio 4" value="<?php echo !empty($_POST)?set_value('precio4'):$o->precio4; ?>" <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
			</div>
			
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="descripcion-inp">Descripci&oacute;n</label>
						<textarea name="descripcion" rows="2" id="descripcion-inp" class="form-control form-control-sm" placeholder="Descripci&oacute;n" <?php echo $disabled_fss; ?>><?php echo !empty($_POST)?set_value('descripcion'):$o->descripcion; ?></textarea>
					</div>
				</div>
			</div>
			
			<?php if(!$o_disabled){ ?>
			<button type="submit" class="btn btn-warning btn-sm mr-2">Actualizar</button>
			<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Cancelar</a>
			<?php } else { ?>
			<a href="<?php echo site_url($controller.'/update/'.$o->$id_o); ?>" class="btn btn-warning btn-sm mr-2">Editar</a>
			<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Regresar</a>
			<?php } ?>
		</form>
	</div>
</div>
