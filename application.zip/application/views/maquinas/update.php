<?php $disabled_fss = $o_disabled?'disabled':''; ?>
<?php $disabled_required_fss = $o_disabled?'disabled':'required'; ?>
<div class="card">
	<div class="card-body">
		<h4 class="card-title text-warning"><?php echo $title_page; ?></h4>
		<form class="forms-sample" enctype="multipart/form-data" method="post">
			<?php if (@validation_errors()) { ?>
			<?php echo validation_errors('<div class="alert alert-danger">', '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>'); ?>
			<?php } ?>
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="nombre-inp">Nombre</label>
						<input name="nombre" type="text" id="nombre-inp" class="form-control form-control-sm" placeholder="nombre" value="<?php echo !empty($_POST)?set_value('nombre'):$o->nombre; ?>" <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="calendario-inp">Calendario</label>
						<input name="calendario" type="text" id="calendario-inp" class="form-control form-control-sm" placeholder="calendario" value="<?php echo !empty($_POST)?set_value('calendario'):$o->calendario; ?>" <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="capacidad-inp">Capacidad</label>
						<input name="capacidad" type="text" id="capacidad-inp" class="form-control form-control-sm" placeholder="capacidad" value="<?php echo !empty($_POST)?set_value('capacidad'):$o->capacidad; ?>" <?php echo $disabled_required_fss; ?>>
					</div>
				</div>
			</div>
			
			<div class="row mt-2">
				<div class="col-sm">
					<div class="form-group">
						<label for="descripcion-inp">Descripci&oacute;n</label>
						<textarea name="descripcion" rows="2" id="descripcion-inp" class="form-control form-control-sm" placeholder="Descripci&oacute;n" <?php echo $disabled_fss; ?>><?php echo !empty($_POST)?set_value('descripcion'):$o->descripcion; ?></textarea>
					</div>
				</div>
			</div>
			
			<?php if(!$o_disabled){ ?>
			<button type="submit" class="btn btn-warning btn-sm mr-2">Actualizar</button>
			<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Cancelar</a>
			<?php } else { ?>
			<a href="<?php echo site_url($controller.'/update/'.$o->$id_o); ?>" class="btn btn-warning btn-sm mr-2">Editar</a>
			<a href="<?php echo site_url($controller); ?>" class="btn btn-sm btn-light">Regresar</a>
			<?php } ?>
		</form>
	</div>
</div>
