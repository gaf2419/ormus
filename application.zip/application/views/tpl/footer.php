        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
        <footer class="footer d-print-none">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">&copy; Bordados ORMU <?php echo date('Y'); ?></span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- row-offcanvas ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/popper.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/bootstrap-confirmation.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/perfect-scrollbar.jquery.min.js'); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="<?php echo base_url('assets/js/jquery.dataTables.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/dataTables.bootstrap4.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/dropify.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/jquery.toast.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/jquery.validate.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/select2.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/clipboard.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/icheck.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/progressbar.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/jquery.steps.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/bootstrap-datepicker.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/bootstrap-datepicker.es.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/jquery-clockpicker.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/plugins/lightgallery/js/lightgallery-all.js'); ?>"></script>
  <script src="https://www.gstatic.com/charts/loader.js"></script>
  <!-- End plugin js for this page-->
  
	<script src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.bootstrap4.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
	<script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
  
  <!-- inject:js -->
  <script src="<?php echo base_url('assets/js/off-canvas.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/hoverable-collapse.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/misc.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/settings.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/todolist.js'); ?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo base_url('assets/js/wizard.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/moment.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/fullcalendar.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/locale-all.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/owl.carousel.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/switchery.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/jQuery.style.switcher.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/data-table.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/jquery.barrating.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/dropify.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/form-validation.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/select2.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/tooltips.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/popover.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/clipboard.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/iCheck.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/file-upload.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/light-gallery.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/formpickers.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/owl-carousel.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/jquery.tagsinput.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/dropzone.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/dashboard.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/app-caja.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/verticalslider.js'); ?>"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.4.0/jspdf.min.js"></script>
  <script type="text/javascript" src="https://checkout.epayco.co/checkout.js"></script>
  <!-- End custom js for this page-->
  <script>
	$(document).ready(function(){
		if($('.small-thumbnail-cls').length > 0){
			$('.small-thumbnail-cls').on('click',function(e){
				e.preventDefault();
				var selector_conn = $(this).attr('href');
				$(selector_conn).attr('src',$(this).find('img').attr('src'));
			});
		}
		if($('.tags').length > 0){
			$('.tags').tagsInput({
				'width': '100%',
				'height': '50%',
				'interactive': true,
				'defaultText': '....',
				'removeWithBackspace': true,
				'minChars': 0,
				'maxChars': 20, // if not provided there is no limit
				'placeholderColor': '#fb9678'
			});
		}
		if($('.btn_buscar_cliente_cn').length > 0){
			$(".btn_buscar_cliente_cn").on('click',function(e){
				e.preventDefault();
				var val_field = $('.inp_buscar_cliente_cn').val();
				if(val_field.length == 0){
					showErrorToast('Lo sentimos!!! Debe escribir la cedula o el nit de un cliente para realizar una busqueda');
				} else {
					$.post("<?php echo site_url('pedidos/buscar_cliente_cn'); ?>", {
						cedula_nit: val_field
					}, function (data) {
						if(data!='no_found'){
							showSuccessToast('En hora buena!!! Existe un cliente que coincide con el resultado de busqueda');
							$('.buscar_cedula_nit_data').val(data);
							if($('input.cliente_cn_nuevo').is(':checked')){
								$('.cliente_cn_nuevo').trigger('click');
							}
							get_cninn_data(data,'nombre','.cliente_cn_nombre');
							get_cninn_data(data,'apellido','.cliente_cn_apellido');
							get_cninn_data(data,'cedula','.cliente_cn_cedula');
							get_cninn_data(data,'telefono','.cliente_cn_telefono');
							get_cninn_data(data,'email','.cliente_cn_email');
							inn_cninn_data(data,'empresa');
							get_cninn_data(data,'tipo_precio','.cliente_cn_tipo_precio');
						} else {
							showErrorToast('Lo sentimos!!! No se han encontrado resultados para los datos suministrados');
						}
					}, "html");
				}
			});
			function inn_cninn_data(id_us,field_us){
				$.post("<?php echo site_url('pedidos/get_cliente_cn_data'); ?>", {
					id: id_us,
					field: field_us
				}, function (data) {
					if(data.length > 0){
						$('#empresa2').prop('checked','checked').trigger('change');
						get_cninn_data(id_us,'nit','.cliente_cn_nit');
						get_cninn_data(id_us,'empresa','.cliente_cn_empresa');
						get_cninn_data(id_us,'direccion','.cliente_cn_direccion');
						get_cninn_data(id_us,'telefono_empresa','.cliente_cn_telefono_empresa');
					}
				}, "html");
			}
			function get_cninn_data(id_us,field_us,selr_f){
				$.post("<?php echo site_url('pedidos/get_cliente_cn_data'); ?>", {
					id: id_us,
					field: field_us
				}, function (data) {
					$(selr_f).val(data);
				}, "html");
			}
		}
		if($('.btn-finalizar-pedido').length > 0){
			$(".btn-finalizar-pedido").on('click',function(e){
				e.preventDefault();
				var id_dinn = $(this).data('idpedido');
				var forma = $('.fp_check_inp:checked').val();
				var paga = 0;
				if(forma == 'abono' || forma == 'contado'){
					var bx_selector = $('.fp_check_inp:checked').data('vshowbx');
					paga = $('.'+bx_selector).find('input').val();
				} else {
					paga = 0;
				}
				$.post("<?php echo site_url('pedidos/fn_solicitud_p'); ?>", {
					id: id_dinn,
					forma: forma,
					paga: paga
				}, function (data) {
					if(data=='ok'){
						location.href="<?php echo site_url('pedidos/fn_msj_p'); ?>";
					}
				}, "html");
			});
		}
		if($('.item-color-select').length > 0){
			$(".item-color-select").on('click',function(e){
				e.preventDefault();
				var elemento_item = $(this);
				elemento_item.toggleClass('active');
			});
		}
		if($('.fp_check_inp').length > 0){
			$(".fp_check_inp").on('click',function(e){
				var chk_item = $(this);
				$('.item-forma-pago-bx').addClass('d-none');
				var bx_selector = chk_item.data('vshowbx');
				$('.'+bx_selector).removeClass('d-none');
			});
		}
		if($('.btn-save-obs_dissg-pedido-bordado').length > 0){
			$(".btn-save-obs_dissg-pedido-bordado").on('click',function(e){
				e.preventDefault();
				var btn_item = $(this);
				var id_pedido = btn_item.data('idpedido');
				var id_bordado = btn_item.data('idpedidobordado');
				var parent_tab = btn_item.parent();
				
				var observaciones_pedido = parent_tab.find('.obs_dissg-save-bbnn-tab').val();
				$.post("<?php echo site_url('solicitudes/tab_save_inn'); ?>", {
					id: id_pedido,
					id_bordado: id_bordado,
					observaciones: observaciones_pedido
				}, function (data) {
					//Procesar, reload paso 3
					if(data != 'error'){
						showSuccessToast('En hora buena!!! Los datos han sido guardados con exito.');
					} else {
						showErrorToast('Lo sentimos!!! Se ha producido un error. Verifique que todos los parametros esten correctos');
					}
				}, "html");
			});
		}
		if($('.btn-save-ch-pedido-bordado').length > 0){
			$(".btn-save-ch-pedido-bordado").on('click',function(e){
				e.preventDefault();
				var btn_item = $(this);
				var id_pedido = btn_item.data('idpedido');
				var id_bordado = btn_item.data('idpedidobordado');
				var parent_tab = btn_item.parent().parent().parent();
				
				var is_error_fs = false;
				var text_error_fs = '';
				//colores
				var colores_arr = '';
				parent_tab.find('.colores-save-bbnn-tab .item-color-select.active').each(function(i,v){
					var valor_cid = $(this).data('idcolorselectable');
					colores_arr += i==0?valor_cid:','+valor_cid;
				});
				if(colores_arr.length == 0){
					is_error_fs=true;
					text_error_fs += '<br>Debe elejir como minimo un color.';
				}
				//console.log(colores_arr);
				//cantidad
				var cantidad_pedido = parent_tab.find('.cantidad-save-bbnn-tab').val();
				if(cantidad_pedido.length == 0){
					is_error_fs=true;
					text_error_fs += '<br>El campo cantidad no puede estar vacio.';
				}
				//unidad de medida
				var unidad_m_pedido = parent_tab.find('.unidad-save-bbnn-tab').val();
				//unidad de medida
				var m_iguales_pedido = parent_tab.find('.m_iguales-save-bbnn-tab').is(':checked')?'si':'no';
				//tipos de bordados
				var medidas_iter = 0;
				var medidas_arr = '';
				var sbds_arr = '';
				parent_tab.find('.tiposbordados-save-bbnn-tab:checked').each(function(i,v){
					var item_sid = $(this);
					var valor_sid = item_sid.val();
					sbds_arr += i==0?valor_sid:','+valor_sid;
					var parent_subtab = item_sid.parent().parent().parent().parent();
					var item_ancho = parent_subtab.find('.inp-tab-ancho-save').val();
					var item_alto = parent_subtab.find('.inp-tab-alto-save').val();
					var item_medida = item_ancho+'x'+item_alto;
					medidas_arr += medidas_iter==0?item_medida:','+item_medida;
					medidas_iter++;
				});
				if(sbds_arr.length == 0){
					is_error_fs=true;
					text_error_fs += '<br>Debe elejir al menos un tipo de bordado.';
				} else if(medidas_arr.length == 0){
					is_error_fs=true;
					text_error_fs += '<br>Los valores de las medidas no pueden estar vacios.';
				}
				//console.log(medidas_arr);
				//observaciones
				var observaciones_pedido = parent_tab.find('.observaciones-save-bbnn-tab').val();
				
				if(is_error_fs){
					showErrorToast('Lo sentimos!!!'+text_error_fs);
				} else {
					$.post("<?php echo site_url('pedidos/tab_save_inn'); ?>", {
						id: id_pedido,
						id_bordado: id_bordado,
						colores: colores_arr,
						cantidad: cantidad_pedido,
						unidad: unidad_m_pedido,
						iguales: m_iguales_pedido,
						tiposbordados: sbds_arr,
						medidas: medidas_arr,
						observaciones: observaciones_pedido
					}, function (data) {
						//Procesar, reload paso 3
						if(data != 'error'){
							showSuccessToast('En hora buena!!! Los datos han sido guardados con exito.');
						} else {
							showErrorToast('Lo sentimos!!! Se ha producido un error. Verifique que todos los parametros esten correctos');
						}
					}, "html");
				}
				
			});
		}
		if($('.btn-disn-puntadas-pedido').length > 0){
			$(".btn-disn-puntadas-pedido").on('click',function(e){
				e.preventDefault();
				var btn_item = $(this);
				var id_pedd = btn_item.data('idpedd');
				var tags_names = '';
				var tags_values = '';
				var is_error = false;
				btn_item.parent().find('input.form-control').each(function(i,v){
					var inp_puntadas = $(this);
					tags_names += i==0?inp_puntadas.attr('name'):','+inp_puntadas.attr('name');
					var valor_inp = inp_puntadas.val();
					if(valor_inp.length == 0){
						is_error = true;
					}
					tags_values += i==0?valor_inp:','+valor_inp;
				});
				if(is_error){
					showErrorToast('Lo sentimos!!! No puede dejar campos vacios en las puntadas.');
				} else {
					$.post("<?php echo site_url('solicitudes/pro_sol'); ?>", {
						id: id_pedd,
						namest: tags_names,
						valuest: tags_values
					}, function (data) {
						if(data=='ok'){
							showSuccessToast('En hora buena!!! Los datos han sido guardados con exito.');
							setInterval(function(){
								location.href="<?php echo site_url('solicitudes'); ?>";
							},3000);
						} else {
							showErrorToast(data);
						}
					}, "html");
				}
			});
		}
		if($('.delete-file-bordado-inn').length > 0){
			$(".delete-file-bordado-inn").on('click',function(e){
				e.preventDefault();
				var elemento_item = $(this);
				$.post("<?php echo site_url('pedidos/del_file_inn'); ?>", {
					id: elemento_item.data('idfileinn')
				}, function (data) {
					elemento_item.parent().remove();
				}, "html");
			});
		}
		if($('.delete-file-extra-bordado-inn').length > 0){
			$(".delete-file-extra-bordado-inn").on('click',function(e){
				e.preventDefault();
				var elemento_item = $(this);
				$.post("<?php echo site_url('pedidos/del_file_extra_inn'); ?>", {
					id: elemento_item.data('idfileinn')
				}, function (data) {
					elemento_item.parent().remove();
				}, "html");
			});
		}
		if($('.delete-file-disgg-bordado-inn').length > 0){
			$(".delete-file-disgg-bordado-inn").on('click',function(e){
				e.preventDefault();
				var elemento_item = $(this);
				$.post("<?php echo site_url('solicitudes/del_file_extra_inn'); ?>", {
					id: elemento_item.data('idfileinn')
				}, function (data) {
					elemento_item.parent().remove();
				}, "html");
			});
		}
		if($('.delete-file-reporte-bordado-inn').length > 0){
			$(".delete-file-reporte-bordado-inn").on('click',function(e){
				e.preventDefault();
				var elemento_item = $(this);
				$.post("<?php echo site_url('reportes/del_file_inn'); ?>", {
					id: elemento_item.data('idfileinn')
				}, function (data) {
					elemento_item.parent().remove();
				}, "html");
			});
		}
		if($('.btn-add-cart-fact-fss').length > 0){
			$(".btn-add-cart-fact-fss").on('click',function(e){
				e.preventDefault();
				var btn_item = $(this);
				var tt_precio = $('#cliente_base option:selected').data('tipoprecio');
				var id_pro = $('#productos_base').val();
				var name_pro = $('#productos_base option:selected').data('namepro');
				var precios_pro = $('#productos_base option:selected').data('preciopro');
				var arr_precios = precios_pro.split(',');
				tt_precio--;
				var precio_producto_cliente = arr_precios[tt_precio];
				
				var cant = parseInt($('#cantidad_base').val());
				
				if($('tr.pro'+id_pro).length > 0){
					var ax_cant = parseInt($('tr.pro'+id_pro).find('.procantfss input').val());
					cant += ax_cant;
				}
				var subtotal = cant*precio_producto_cliente;
				if($('tr.pro'+id_pro).length == 0){
					$('.box-inpts-pdts').append('<tr class="pro'+id_pro+'"><td class="pronamefss"><span>'+name_pro+'</span><input type="hidden" name="productos[]" value="'+id_pro+'"></td><td class="procantfss"><span>'+cant+'</span><input type="hidden" name="cantidades[]" value="'+cant+'"></td><td class="sbttfssinn">'+subtotal+'</td><td><i class="icon-trash delete-venta-pro"></i></td></tr>');
				} else {
					$('.box-inpts-pdts tr.pro'+id_pro).html('<td class="pronamefss"><span>'+name_pro+'</span><input type="hidden" name="productos[]" value="'+id_pro+'"></td><td class="procantfss"><span>'+cant+'</span><input type="hidden" name="cantidades[]" value="'+cant+'"></td><td class="sbttfssinn">'+subtotal+'</td><td><i class="icon-trash delete-venta-pro"></i></td>');
				}
				$('.delete-venta-pro').on('click',function(){
					$(this).parent().parent().remove();
					if($('.sbttfssinn').length > 0){
						var total_inn = 0;
						$('.sbttfssinn').each(function(i,v){
							total_inn += parseInt($(this).html());
						});
						$('.totalinnfssnn').html(total_inn);
					} else {
						$('.totalinnfssnn').html('0');
					}
				});
				if($('.sbttfssinn').length > 0){
					var total_inn = 0;
					$('.sbttfssinn').each(function(i,v){
						total_inn += parseInt($(this).html());
					});
					$('.totalinnfssnn').html(total_inn);
				} else {
					$('.totalinnfssnn').html('0');
				}
			});
		}
		if($('#cliente_base').length > 0){
			$("#cliente_base").on('change',function(e){
				e.preventDefault();
				$('.box-inpts-pdts').html('');
			});
		}
		//Operario
		if($('.realizadas-innz-btn').length > 0){
			$(".realizadas-innz-btn").on('click',function(e){
				e.preventDefault();
				var btn_item = $(this);
				var parent_inn_item = btn_item.parent().parent();
				//var parent_top_item = btn_item.parent().parent().parent();
				var valor_realizado = parent_inn_item.find('.realizadas-innz-tab').val();
				if(valor_realizado.length == 0 || valor_realizado == 0){
					showErrorToast('Lo sentimos!!! Debe introducir un valor mayor que cero en el campo correspondiente a las tareas Realizadas.');
				} else {
					$.post("<?php echo site_url('tareas/save_realizadas'); ?>", {
						id: btn_item.data('idbbaainn'),
						realizado: valor_realizado
					}, function (data) {
						if(data=='finalizada'){
							btn_item.parent().html('<div class="badge badge-outline-success badge-pill mt-4">Finalizada</div>');
							showSuccessToast('En hora buena!!! Ha finalizado las tareas en esta secci&oacute;n del pedido.');
						} else if(data=='ok') {
							showSuccessToast('En hora buena!!! Los datos han sido guardados con exito.');
						} else {
							showErrorToast(data);
						}
					}, "html");
				}
				
			});
		}
		if($('.oper-end-pedido').length > 0){
			$(".oper-end-pedido").on('click',function(e){
				e.preventDefault();
				var btn_item = $(this);
				$.post("<?php echo site_url('tareas/oper_end_pedido'); ?>", {
					id: btn_item.data('idpedinn')
				}, function (data) {
					if(data=='ok'){
						location.href="<?php echo site_url('tareas/fn_msj_p'); ?>";
					} else {
						showErrorToast(data);
					}
				}, "html");
			});
		}
		if($('.super-end-pedido').length > 0){
			$(".super-end-pedido").on('click',function(e){
				e.preventDefault();
				var btn_item = $(this);
				$.post("<?php echo site_url('reportes/super_end_pedido'); ?>", {
					id: btn_item.data('idpedinn')
				}, function (data) {
					if(data=='ok'){
						location.href="<?php echo site_url('reportes/fn_msj_p'); ?>";
					} else {
						showErrorToast(data);
					}
				}, "html");
			});
		}
		if($('.basic-dropzone').length > 0){
			$(".basic-dropzone").on('each',function(i,v){
				var selt_id = $(this).attr('id');
				$('#'+selt_id).dropzone();
			});
			$('form.basic-dropzone').find('div.dz-default.dz-message').find('span').html('Arrastra aqui los archivos para adjuntarlos');
			$('form.extra-dropzone').find('div.dz-default.dz-message').find('span').html('Arrastra aqui los bordados extras para adjuntarlos');
		}
		if($('.empresa_sis_fss').length > 0){
			function modo_acct(){
				if($('.empresa_sis_fss:checked').val()=='si'){
					$('.modo_emp_sis_fss').prop('disabled','');
				} else {
					$('.modo_emp_sis_fss').prop('disabled','disabled');
				}
			}
			$('.empresa_sis_fss').on('change',function(e){
				modo_acct();
			});
			modo_acct();
		}
		if($('.next-tab-go').length > 0){
			$('.next-tab-go').on('click',function(e){
				e.preventDefault();
				var item_go = $(this).attr('href');
				$(item_go).click();
			});
		}
		if($('.js-switch').length > 0){
			var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
			$('.js-switch').each(function() {
				new Switchery($(this)[0], $(this).data());
			});
		}
		
		if($('.modal-confirm').length > 0){
			$('.modal-confirm').on('show.bs.modal', function(e) {
				$(this).find('a.btn-ok').attr('href', $(e.relatedTarget).data('href'));
			});
		}
		if($('#delete_c_modal').length > 0){
			$('#delete_c_modal').on('show.bs.modal', function(e) {
				$(this).find('a.btn-ok').attr('href', $(e.relatedTarget).data('href'));
			});
		}
		
		if($('.btn-printer-fss').length > 0){
			$('.btn-printer-fss').on('click', function(e) {
				e.preventDefault();
				window.print();
			});
		}
		
		if($('.example-fontawesome-star').length > 0){
			$('.example-fontawesome-star').barrating({
                theme: 'fontawesome-stars',
                showSelectedRating: false
            });
		}
		
		<?php if(@$full_calendar_citas){ ?>
		if ($('#calendar-fss').length > 0) {
			function show_data_pedido(id_pedd){
				$('.loader-fss-box').fadeIn();
				$.post("<?php echo site_url('agenda/show_data_pedido'); ?>", {
					id: id_pedd
				}, function (data) {
					$('.loader-fss-box').fadeOut();
					$('#details_res_modal .modal-title').html('Agenda de Pedido');
					$('#details_res_modal .modal-body').html(data);
					$('#details_res_modal').modal('show');
				}, "html");
			}
            $('#calendar-fss').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'month,basicWeek,basicDay'
                },
				eventClick: function(calEvent, jsEvent, view) {
					if(calEvent.tipo=='pedido'){
						show_data_pedido(calEvent.id);
					} else {
						//console.log(calEvent.id);
					}
				},
				locale: 'es',
                defaultDate: '<?php echo date('Y-m-d'); ?>',
                navLinks: true, // can click day/week names to navigate views
                editable: false,
                eventLimit: true, // allow "more" link when too many events
                events: [
					<?php $key_iter=0; ?>
					<?php if($o_pedidos_all->num_rows() > 0){ ?>
					<?php foreach($o_pedidos_all->result() as $key_r => $row_r){ ?>
					<?php echo $key_r==0?'':','; ?>{
                        id: <?php echo $row_r->id_pedido; ?>,
                        tipo: 'pedido',
						title: 'Pedido - #<?php echo $row_r->codigo; ?>',
                        start: '<?php echo $row_r->fecha_entrega; ?>',
						color  : '#03a9f3'
                    }
					<?php } ?>
					<?php } ?>
                ]
            });
        }
		<?php } ?>
		
		resetToastPosition = function() {
			$('.jq-toast-wrap').removeClass('bottom-left bottom-right top-left top-right mid-center'); // to remove previous position class
			$(".jq-toast-wrap").css({"top": "", "left": "", "bottom":"", "right": ""}); //to remove previous position style
		}
		function showSuccessToast(msjToast){
			'use strict';
			resetToastPosition();
			$.toast({
				heading: 'Success',
				text: msjToast,
				showHideTransition: 'slide',
				icon: 'success',
				loaderBg: '#f96868',
				hideAfter : 10000,
				position: 'top-center'
			})
		};
		function showErrorToast(msjToast){
			'use strict';
			resetToastPosition();
			$.toast({
				heading: 'Danger',
				text: msjToast,
				showHideTransition: 'slide',
				icon: 'error',
				loaderBg: '#f2a654',
				hideAfter : 10000,
				position: 'top-center'
			})
		};
		
		<?php $msj_header_fss = $this->session->flashdata('msj_header_fss'); ?>
		<?php if(!empty($msj_header_fss)){ ?>
		showSuccessToast('<?php echo $msj_header_fss; ?>');
		<?php } ?>
		<?php $msj_header_error_fss = $this->session->flashdata('msj_header_error_fss'); ?>
		<?php if(!empty($msj_header_error_fss)){ ?>
		showErrorToast('<?php echo $msj_header_error_fss; ?>');
		<?php } ?>
		
	});
	$(window).on('load',function(){
		if($('.loader-fss-box').length > 0){
			$('.loader-fss-box').fadeOut();
		}
	});
	</script>
</body>

</html>