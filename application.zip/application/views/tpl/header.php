<?php $ormufss_user = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $this->session->ormufss_user->id_usuario)); ?>
<?php $url_redirect = $ormufss_user->rol=='cliente'?'perfil':'dashboard'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Bordados ORMU | <?php echo $active_mod; ?></title>
  <link rel="shortcut icon" href="<?php echo base_url('assets/images/icon.png'); ?>" />
  <link rel="stylesheet" href="<?php echo base_url('assets/css/materialdesignicons.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/simple-line-icons.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/flag-icon.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/font-awesome/css/font-awesome.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/perfect-scrollbar.min.css'); ?>">
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/dataTables.bootstrap4.css'); ?>"/>
  <link rel="stylesheet" href="<?php echo base_url('assets/css/dropify.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/jquery.toast.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/switchery.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/select2.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/skins/all.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/plugins/lightgallery/css/lightgallery.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/wizard.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/dropzone.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/jquery.tagsinput.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/select2-bootstrap.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap-datepicker.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/jquery-clockpicker.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/fullcalendar.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/owl.carousel.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/owl.theme.default.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/fontawesome-stars.css'); ?>">
  <!-- End plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>

<body class="sidebar-dark">
	<div class="loader-fss-box"><div class="w-100 h-100 d-flex justify-content-center align-items-center"><div class="pixel-loader"></div></div></div>
  <div class="container-scroller">
    <!-- partial:../../partials/_navbar.html -->
    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row navbar-danger d-print-none">
      <div class="text-center navbar-brand-wrapper d-flex align-items-top justify-content-center">
        <a class="navbar-brand brand-logo" href="<?php echo site_url($url_redirect); ?>"><img src="<?php echo base_url('assets/images/logo-lg.png'); ?>" alt="logo"/></a>
        <a class="navbar-brand brand-logo-mini" href="<?php echo site_url($url_redirect); ?>"><img src="<?php echo base_url('assets/images/icon.png'); ?>" alt="logo"/></a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
          <span class="icon-menu"></span>
        </button>
        <ul class="navbar-nav">
        </ul>
        <ul class="navbar-nav navbar-nav-right">
			<?php if($ormufss_user->rol == 'administrator') { ?>
			<li class="nav-item dropdown d-none d-lg-flex">
				<a class="nav-link dropdown-toggle nav-btn" id="actionDropdown" href="#" data-toggle="dropdown"><span class="btn">+ Crear nuevo</span></a>
				<div class="dropdown-menu navbar-dropdown dropdown-left" aria-labelledby="actionDropdown">
					<a class="dropdown-item" href="<?php echo site_url('usuarios/add'); ?>"><i class="icon-user-follow text-primary"></i> Usuario</a>
					<div class="dropdown-divider"></div>
					<a class="dropdown-item" href="<?php echo site_url('productos/add'); ?>"><i class="icon-grid text-primary"></i> Producto</a>
					<div class="dropdown-divider"></div>
					<a class="dropdown-item" href="<?php echo site_url('bordados/add'); ?>"><i class="icon-vector text-primary"></i> Bordado</a>
					<div class="dropdown-divider"></div>
					<a class="dropdown-item" href="<?php echo site_url('maquinas/add'); ?>"><i class="icon-energy text-primary"></i> M&aacute;quina</a>
				</div>
			</li>
			<?php } ?>
			
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="icon-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="row row-offcanvas row-offcanvas-right">
        <!-- partial -->
        <!-- partial:../../partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas d-print-none" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile mt-4">
              <a href="<?php echo site_url('perfil'); ?>">
			  <div class="nav-link">
                <div class="profile-image">
                  <img src="<?php echo !empty($ormufss_user->foto)?base_url('uploads/users/'.$ormufss_user->foto):base_url('assets/images/default_avatar.jpg'); ?>" alt="avatar"/>
                  <span class="online-status online"></span>
                </div>
                <div class="profile-name">
                  <p class="name"><?php echo $ormufss_user->nombre; ?></p>
                  <p class="designation text-capitalize"><?php echo $ormufss_user->rol=='disenador'?'Dise&ntilde;ador':$ormufss_user->rol; ?></p>
                </div>
              </div>
              </a>
            </li>
			<?php if($ormufss_user->rol == 'administrator') { ?>
            <li class="nav-item <?php if($active_mod == 'Usuarios') {echo 'active';} ?>"><a class="nav-link" href="<?php echo site_url('usuarios'); ?>"><i class="icon-people menu-icon"></i><span class="menu-title">Gesti&oacute;n de Usuarios</span><span class="badge badge-warning"></span></a></li>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('productos'); ?>"><i class="icon-grid menu-icon"></i><span class="menu-title">Productos</span><span class="badge badge-warning"></span></a></li>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('categorias_bordados'); ?>"><i class="icon-badge menu-icon"></i><span class="menu-title">Categorias de Bordados</span><span class="badge badge-warning"></span></a></li>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('bordados'); ?>"><i class="icon-vector menu-icon"></i><span class="menu-title">Tipos de Bordados</span><span class="badge badge-warning"></span></a></li>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('maquinas'); ?>"><i class="icon-energy menu-icon"></i><span class="menu-title">M&aacute;quinas</span><span class="badge badge-warning"></span></a></li>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('colores'); ?>"><i class="icon-drop menu-icon"></i><span class="menu-title">Colores</span><span class="badge badge-warning"></span></a></li>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('agenda'); ?>"><i class="icon-calendar menu-icon"></i><span class="menu-title">Agenda por M&aacute;quinas</span><span class="badge badge-warning"></span></a></li>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('solicitudes'); ?>"><i class="icon-envelope-letter menu-icon"></i><span class="menu-title">Reporte Solicitudes</span><span class="badge badge-warning"></span></a></li>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('reporte_operario'); ?>"><i class="icon-notebook menu-icon"></i><span class="menu-title">Reporte Operario</span><span class="badge badge-warning"></span></a></li>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('reportes'); ?>"><i class="icon-picture menu-icon"></i><span class="menu-title">Reporte Fotogr&aacute;fico</span><span class="badge badge-warning"></span></a></li>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('sucursales'); ?>"><i class="icon-location-pin menu-icon"></i><span class="menu-title">Sucursales</span><span class="badge badge-warning"></span></a></li>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('facturaciones'); ?>"><i class="icon-printer menu-icon"></i><span class="menu-title">Facturaci&oacute;n</span><span class="badge badge-warning"></span></a></li>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('categorias'); ?>"><i class="icon-tag menu-icon"></i><span class="menu-title">Categor&iacute;a de gastos</span><span class="badge badge-warning"></span></a></li>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('gastos'); ?>"><i class="icon-pie-chart menu-icon"></i><span class="menu-title">Gastos</span><span class="badge badge-warning"></span></a></li>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('inventario'); ?>"><i class="icon-chart menu-icon"></i><span class="menu-title">Inventario</span><span class="badge badge-warning"></span></a></li>
			<?php } else if($ormufss_user->rol == 'recepcion') { ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('pedidos'); ?>"><i class="icon-earphones-alt menu-icon"></i><span class="menu-title">Pedidos</span><span class="badge badge-warning"></span></a></li>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('abonos'); ?>"><i class="icon-wallet menu-icon"></i><span class="menu-title">Abonos</span><span class="badge badge-warning"></span></a></li>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('facturaciones'); ?>"><i class="icon-printer menu-icon"></i><span class="menu-title">Facturaci&oacute;n</span><span class="badge badge-warning"></span></a></li>
			<?php } else if($ormufss_user->rol == 'disenador') { ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('colores'); ?>"><i class="icon-drop menu-icon"></i><span class="menu-title">Colores</span><span class="badge badge-warning"></span></a></li>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('solicitudes'); ?>"><i class="icon-paper-clip menu-icon"></i><span class="menu-title">Pedidos</span><span class="badge badge-warning"></span></a></li>
			<?php } else if($ormufss_user->rol == 'operario') { ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('tareas'); ?>"><i class="icon-equalizer menu-icon"></i><span class="menu-title">Tareas</span><span class="badge badge-warning"></span></a></li>
			<?php } else if($ormufss_user->rol == 'supervisor') { ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('reportes'); ?>"><i class="icon-picture menu-icon"></i><span class="menu-title">Reporte Fotogr&aacute;fico</span><span class="badge badge-warning"></span></a></li>
			<?php } else if($ormufss_user->rol == 'sucursal') { ?>
			<?php $o_ssc_inn = $this->default_model->default_get_one_where('sucursal', array('usuario' => $ormufss_user->id_usuario)); ?>
			<?php $arrsscinn = explode(",",$o_ssc_inn->modulos); ?>
			<?php if(in_array(1,$arrsscinn)){ ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('productos'); ?>"><i class="icon-grid menu-icon"></i><span class="menu-title">Productos</span><span class="badge badge-warning"></span></a></li>
			<?php } ?>
			<?php if(in_array(2,$arrsscinn)){ ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('categorias_bordados'); ?>"><i class="icon-badge menu-icon"></i><span class="menu-title">Categorias de Bordados</span><span class="badge badge-warning"></span></a></li>
			<?php } ?>
			<?php if(in_array(3,$arrsscinn)){ ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('bordados'); ?>"><i class="icon-vector menu-icon"></i><span class="menu-title">Tipos de Bordados</span><span class="badge badge-warning"></span></a></li>
			<?php } ?>
			<?php if(in_array(4,$arrsscinn)){ ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('maquinas'); ?>"><i class="icon-energy menu-icon"></i><span class="menu-title">M&aacute;quinas</span><span class="badge badge-warning"></span></a></li>
			<?php } ?>
			<?php if(in_array(5,$arrsscinn)){ ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('colores'); ?>"><i class="icon-drop menu-icon"></i><span class="menu-title">Colores</span><span class="badge badge-warning"></span></a></li>
			<?php } ?>
			<?php if(in_array(6,$arrsscinn)){ ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('agenda'); ?>"><i class="icon-calendar menu-icon"></i><span class="menu-title">Agenda por M&aacute;quinas</span><span class="badge badge-warning"></span></a></li>
			<?php } ?>
			<?php if(in_array(7,$arrsscinn)){ ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('reportes'); ?>"><i class="icon-picture menu-icon"></i><span class="menu-title">Reporte Fotogr&aacute;fico</span><span class="badge badge-warning"></span></a></li>
			<?php } ?>
			<?php if(in_array(8,$arrsscinn)){ ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('reporte_operario'); ?>"><i class="icon-notebook menu-icon"></i><span class="menu-title">Reporte Operario</span><span class="badge badge-warning"></span></a></li>
			<?php } ?>
			<?php if(in_array(9,$arrsscinn)){ ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('facturaciones'); ?>"><i class="icon-printer menu-icon"></i><span class="menu-title">Facturaci&oacute;n</span><span class="badge badge-warning"></span></a></li>
			<?php } ?>
			<?php if(in_array(10,$arrsscinn)){ ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('categorias'); ?>"><i class="icon-tag menu-icon"></i><span class="menu-title">Categor&iacute;a de gastos</span><span class="badge badge-warning"></span></a></li>
			<?php } ?>
			<?php if(in_array(11,$arrsscinn)){ ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('gastos'); ?>"><i class="icon-pie-chart menu-icon"></i><span class="menu-title">Gastos</span><span class="badge badge-warning"></span></a></li>
			<?php } ?>
			<?php if(in_array(12,$arrsscinn)){ ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('inventario'); ?>"><i class="icon-chart menu-icon"></i><span class="menu-title">Inventario</span><span class="badge badge-warning"></span></a></li>
			<?php } ?>
			<?php } else { ?>
			
			<?php } ?>
			<li class="nav-item"><a class="nav-link" href="<?php echo site_url('login/logout'); ?>"><i class="icon-logout menu-icon"></i><span class="menu-title">Salir</span></a></li>
          </ul>
        </nav>
        <!-- partial -->
        <div class="content-wrapper">