<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pedidos extends CI_Controller {

	private $genClass = 'El';
	private $disClass = 'o';
	
	function is_logged() {
		$sr_session_role = $this->all_config_ci('session_role');
        if (!@$this->session->userdata($sr_session_role))
            redirect('login');
    }

    function is_access($role=array()) {
        $sr_session_role = $this->all_config_ci('session_role');
		$permissions = empty($role)?array('administrator'):$role;
		if (@$this->session->userdata($sr_session_role) and !in_array($this->session->$sr_session_role->rol,$permissions))
            show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
    }
	
	private function all_config_ci($a='') {
		//pedido --- id_pedido,usuario,tipo_precio,bordados,fecha_entrega,pago,costo,abonado,estado
		$out = '';
		switch ($a){
			case 'session_role': $out='ormufss_user';break;
			case 'url_views': $out='pedidos';break;
			case 'url_controller': $out='pedidos';break;
			case 'name_controller': $out='Pedidos';break;
			case 'table_name': $out ='pedido';break;
			case 'o_id': $out='id_pedido';break;
			case 'o_required': $out=array('nombre' => 'Nombre');break;
			case 'o_unique_check': $out=array('ninguno');break;
			default: $out = '';
		}
		return $out;
    }

	public function index()	{
		$this->is_logged();
		$sr_session_role = $this->all_config_ci('session_role');
		$r_idd = $this->session->$sr_session_role->rol;
		if($r_idd=='recepcion'){
			//redirect($this->all_config_ci('url_controller').'/add');
		}
		$estado = 'presolicitado';
		
		$this->is_access(array('administrator','recepcion'));
		$this->load->helper('text');
		$data = array();
		$t_name = $this->all_config_ci('table_name');
		$t_id = $this->all_config_ci('o_id');
		$c_name = $this->all_config_ci('name_controller');
		//$data['o_all'] = $this->default_model->default_get_all_where($t_name,array('estado' => 'activo'));
		//default_get_all_elements_field_in_fss(tabla, campo, condicion,ordenar_campo, orden = 'desc')
		$data['o_all'] = $this->default_model->default_get_all_elements_field_in_fss($t_name,'estado',array($estado),$t_id);
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['sr_session_role'] = $sr_session_role;
		$data['active_mod'] = $c_name;
		$data['title'] = 'Listado de '.$c_name;
		$data['title_page'] = 'Listado de '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/list', $data);
		$this->load->view('tpl/footer', $data);
	}
	
	public function add() {
		$this->is_logged();
		$this->is_access(array('recepcion'));
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$c_path = $this->all_config_ci('url_controller');
		$o_id = $this->all_config_ci('o_id');
		$o_required = $this->all_config_ci('o_required');
		$o_unique_check = $this->all_config_ci('o_unique_check');
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
		if(count($o_required) > 0){
			foreach($o_required as $key => $row){
				$rules = in_array($key,$o_unique_check)?'trim|required|callback_'.$key.'_check':'trim|required';
				$this->form_validation->set_rules($key, '<em>'.$row.'</em>', $rules);
			}
		}
        if (!empty($_POST)) {
            if ($this->form_validation->run() == TRUE) {
				$us_last = 0;
				$tipo_precio = 1;
				if(!empty($_POST['cliente_nuevo']) AND $_POST['cliente_nuevo']=='si'){
					$values = array();
					$tipo_precio = $_POST['tipo_precio'];
					if($_POST['isempresa']=='si'){
						$values = array('nombre' => $_POST['nombre'],'apellido' => $_POST['apellido'],'cedula' => $_POST['cedula'],'telefono' => $_POST['telefono'],'username' => $_POST['email'],'email' => $_POST['email'],'password' => md5('123456'),'nit' => $_POST['nit'],'empresa' => $_POST['empresa'],'direccion' => $_POST['direccion'],'telefono_empresa' => $_POST['telefono_empresa'],'tipo_precio' => $_POST['tipo_precio'],'rol' => 'cliente','estado' => 'activo');
					} else {
						$values = array('nombre' => $_POST['nombre'],'apellido' => $_POST['apellido'],'cedula' => $_POST['cedula'],'telefono' => $_POST['telefono'],'username' => $_POST['email'],'email' => $_POST['email'],'password' => md5('123456'),'tipo_precio' => $_POST['tipo_precio'],'rol' => 'cliente','estado' => 'activo');
					}
					$us_last = $this->default_model->default_insert_one_get_id('usuario', $values);
				} else {
					if(empty($_POST['cedula_nit'])){
						$this->session->set_flashdata('msj_header_error_fss', 'Lo sentimos!!! Ha elejito cliente existente pero el campo Cedula/Nit no tiene el valor referente al cliente.');
						redirect($this->all_config_ci('url_controller').'/add');
					}
					$o_us = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $_POST['cedula_nit']));
					if(!empty($o_us->id_usuario)){
						$us_last = $o_us->id_usuario;
						$tipo_precio = $o_us->tipo_precio;
					}
				}
				//pedido --- id_pedido,codigo,usuario,tipo_precio,bordados,fecha_entrega,pago,costo,abonado,estado
				$bordados = '';
				$fecha_entrega = '';
				$dias_entrega = 0;
				foreach($_POST['bordados'] as $b_key => $b_row){
					$bordados .= $b_key==0?$b_row:','.$b_row;
					$o_bdd = $this->default_model->default_get_one_where('categoria_producto', array('id_categoria_producto' => $b_row));
					$o_mkn = $this->default_model->default_get_one_where('maquina', array('id_maquina' => $o_bdd->maquina));
					$d_calendar = !empty($o_mkn->calendario)?$o_mkn->calendario:0;
					$dias_entrega += $d_calendar;
				}
				$hoy_fecha = date('Y-m-d H:i:s');
				//$fecha_entrega = $this->dat_end_solicitud($dias_entrega,$hoy_fecha);
				$fecha_entrega = date("Y-m-d H:i:s", strtotime('+'.$dias_entrega.' hours', strtotime($hoy_fecha)));
				$this->load->library('utiles');
				$codigo = $this->utiles->gcode_simple($t_name,'codigo');
				$values = array('codigo' => $codigo,'usuario' => $us_last,'tipo_precio' => $tipo_precio,'bordados' => $bordados,'fecha_entrega' => $fecha_entrega,'costo' => 0,'abonado' => 0,'estado' => 'presolicitado');
				$n_last = $this->default_model->default_insert_one_get_id($t_name, $values);
				$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! El pedido ha sido pre-solicitado correctamente. Debe seguir con el segundo paso.');
				redirect($this->all_config_ci('url_controller').'/step_two/'.$n_last);
            }
        }
		$data['select_b_all'] = $this->default_model->default_get_all_where('categoria_producto',array('estado' => 'activo'));
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = $c_name;
		$data['title'] = 'Adicionar '.$c_name;
		$data['title_page'] = 'Adicionar '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/add', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	public function step_two($id = '') {
		$this->is_logged();
		$this->is_access(array('recepcion'));
		if(empty($id)){
			redirect($this->all_config_ci('url_controller'));
		}
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$o_required = $this->all_config_ci('o_required');
		$o_id = $this->all_config_ci('o_id');
		$o = $this->default_model->default_get_one_where($t_name, array($o_id => $id));
		if(empty($o->$o_id)){
			$this->session->set_flashdata('msj_header_error_fss', 'Lo sentimos!!! '.$this->genClass.' '.$c_name.' '.$id.' no existe.');
			redirect($this->all_config_ci('url_controller'));
		} else {
			//pedido_bordado
			$ax_ex = $this->default_model->default_get_all_where('pedido_bordado',array('pedido' => $id,'estado' => 'activo'));
			$cant_bos = explode(',',$o->bordados);
			if($ax_ex->num_rows() == count($cant_bos)){
				redirect($this->all_config_ci('url_controller').'/step_finalizar/'.$id);
			}
		}
		
		$data['o'] = $o;
		$data['o_us'] = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $o->usuario));
		$data['select_b_all'] = $this->default_model->default_get_all_where('categoria_producto',array('estado' => 'activo'));
		$data['select_c_all'] = $this->default_model->default_get_all_where('color',array('estado' => 'activo'));
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = $c_name;
		$data['title'] = 'Adicionar '.$c_name;
		$data['title_page'] = 'Adicionar '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/step_two', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	public function step_finalizar($id = '') {
		$this->is_logged();
		$this->is_access(array('recepcion'));
		if(empty($id)){
			redirect($this->all_config_ci('url_controller'));
		}
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$o_required = $this->all_config_ci('o_required');
		$o_id = $this->all_config_ci('o_id');
		$o = $this->default_model->default_get_one_where($t_name, array($o_id => $id));
		if(empty($o->$o_id)){
			$this->session->set_flashdata('msj_header_error_fss', 'Lo sentimos!!! '.$this->genClass.' '.$c_name.' '.$id.' no existe.');
			redirect($this->all_config_ci('url_controller'));
		} else {
			//pedido_bordado
			$ax_ex = $this->default_model->default_get_all_where('pedido_bordado',array('pedido' => $id,'estado' => 'activo'));
			$cant_bos = explode(',',$o->bordados);
			if($ax_ex->num_rows() < count($cant_bos)){
				$this->session->set_flashdata('msj_header_error_fss', 'Lo sentimos!!! Falta informacion por completar en el segundo paso de solicitud de pedido.');
				redirect($this->all_config_ci('url_controller').'/step_two/'.$id);
			}
		}
		
		$data['o'] = $o;
		$data['o_us'] = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $o->usuario));
		$data['select_b_all'] = $this->default_model->default_get_all_where('categoria_producto',array('estado' => 'activo'));
		$data['select_c_all'] = $this->default_model->default_get_all_where('color',array('estado' => 'activo'));
		
		$are_sum_ax = 0;
		$are_tipo_precio = $o->tipo_precio;
		$bs_cat_pro_arr = explode(",",$o->bordados);//categoria_producto
		foreach($bs_cat_pro_arr as $key => $row){
			$o_bdd = $this->default_model->default_get_one_where('categoria_producto', array('id_categoria_producto' => $row));
			$o_pedido_b = $this->default_model->default_get_one_where('pedido_bordado', array('pedido' => $o->id_pedido,'bordado' => $row));
			$inn_sum_ax = 0;
			$bs_arr = explode(",",$o_bdd->bordados);//bordados
			foreach($bs_arr as $b_key => $b_row){
				$o_b_nn = $this->default_model->default_get_one_where('bordado', array('id_bordado' => $b_row));
				$tag_precio = 'precio'.$are_tipo_precio;
				$inn_sum_ax += $o_b_nn->$tag_precio;
			}
			$are_sum_ax += ($inn_sum_ax * $o_pedido_b->cantidad);
		}
		$data['inn_sum_t_costo'] = $are_sum_ax;
		
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = $c_name;
		$data['title'] = 'Adicionar '.$c_name;
		$data['title_page'] = 'Adicionar '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/step_finalizar', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	private function dat_end_solicitud($ds,$f_inicio){
		$ds=intval($ds);
		$ds_all=$ds*24;
		$duracion=$ds_all.':00:00';
		$arr_cronom = explode(":",$duracion);
		$seconds_restantes = 3600*$arr_cronom[0] + 60*$arr_cronom[1] + $arr_cronom[2];
		$nf = strtotime('+'.$arr_cronom[0].' hour',strtotime($f_inicio));
		$f_inicio = date('Y-m-d H:i:s',$nf);
		$nf = strtotime('+'.$arr_cronom[1].' minute',strtotime($f_inicio));
		$f_inicio = date('Y-m-d H:i:s',$nf);
		$nf = strtotime('+'.$arr_cronom[2].' second',strtotime($f_inicio));
		$nf = date('Y-m-d H:i:s',$nf);
		return $nf;
	}
	
	public function update($id='') {
		$this->is_logged();
		$this->is_access();
		if(empty($id)){
			redirect($this->all_config_ci('url_controller'));
		}
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$o_required = $this->all_config_ci('o_required');
		$o_id = $this->all_config_ci('o_id');
		$o = $this->default_model->default_get_one_where($t_name, array($o_id => $id));
		if(empty($o->$o_id)){
			$this->session->set_flashdata('msj_header_error_fss', 'Lo sentimos!!! '.$this->genClass.' '.$c_name.' '.$id.' no existe.');
			redirect($this->all_config_ci('url_controller'));
		}
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
		if(count($o_required) > 0){
			foreach($o_required as $key => $row){
				$this->form_validation->set_rules($key, '<em>'.$row.'</em>', 'trim|required');
			}
		}
        if (!empty($_POST)) {
            if ($this->form_validation->run() == TRUE) {
				$values = array();
				foreach($_POST as $key => $row){
					$values[$key] = $row;
				}
				$updt = $this->default_model->default_update($t_name, $o_id, $id, $values);
				$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! '.$this->genClass.' '.$c_name.' '.$o->$o_id.' ha sido actualizad'.$this->disClass.' correctamente.');
				redirect($this->all_config_ci('url_controller').'/details/'.$o->$o_id);
            }
        }
		$data['o'] = $o;
		$data['o_disabled'] = false;
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $o_id;
		$data['active_mod'] = $c_name;
		$data['title'] = 'Actualizar '.$c_name;
		$data['title_page'] = 'Actualizar '.$c_name.' - <b>'.$o->$o_id.'</b>';
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/update', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	public function details($id=''){
		$this->is_logged();
		$this->is_access();
		if(empty($id)){
			redirect($this->all_config_ci('url_controller'));
		}
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$o_required = $this->all_config_ci('o_required');
		$o_id = $this->all_config_ci('o_id');
		$o = $this->default_model->default_get_one_where($t_name, array($o_id => $id));
		if(empty($o->$o_id)){
			$this->session->set_flashdata('msj_header_error_fss', 'Lo sentimos!!! '.$this->genClass.' '.$c_name.' '.$id.' no existe.');
			redirect($this->all_config_ci('url_controller'));
		}
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
		$data['o'] = $o;
		$data['o_disabled'] = true;
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $o_id;
		$data['active_mod'] = $c_name;
		$data['title'] = 'Detalles de '.$c_name;
		$data['title_page'] = 'Detalles de '.$c_name.' - <b>'.$o->$o_id.'</b>';
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/update', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	public function cancelar($id){
		$this->is_logged();
		$this->is_access(array('recepcion'));
		$c_name = $this->all_config_ci('name_controller');
		$t_name = $this->all_config_ci('table_name');
		$o_id = $this->all_config_ci('o_id');
		$updt = $this->default_model->default_delete($t_name, array($o_id => $id));
		$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! '.$this->genClass.' '.$c_name.' '.$id.' ha sido cancelad'.$this->disClass.' correctamente.');
		redirect($this->all_config_ci('url_controller').'/add');
	}
	
	public function delete($id){
		$this->is_logged();
		$this->is_access();
		$c_name = $this->all_config_ci('name_controller');
		$t_name = $this->all_config_ci('table_name');
		$o_id = $this->all_config_ci('o_id');
		$updt = $this->default_model->default_update($t_name, $o_id, $id, array('estado' => 'inactivo'));
		$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! '.$this->genClass.' '.$c_name.' '.$id.' ha sido eliminad'.$this->disClass.' correctamente.');
		redirect($this->all_config_ci('url_controller'));
	}
	
	public function upld_file(){
		$this->is_logged();
		$id = $_POST['pedido_id'];
		$b = $_POST['bordado'];
		$file_name = '';
		if(!empty($_FILES)){
			$this->load->library('upload');
			if(!empty($_FILES['file']['name'])) {
				$config['upload_path'] = './uploads/archivos/';
				$config['allowed_types'] = '*';
				$config['max_size']	= '10240';
				$config['overwrite'] = TRUE;
				$config['file_name'] = uniqid();
				$this->upload->initialize($config);
				if (!$this->upload->do_upload('file')) {
					$data['error_foto'] = $this->upload->display_errors();
				} else {
					$data = $this->upload->data('file');
					$file_name = $this->upload->data('file_name');
					$n_last = $this->default_model->default_insert_one_get_id('pedido_archivo', array('pedido' => $id,'bordado' => $b,'archivo' => $file_name,'estado' => 'activo'));
				}
			}
		}
	}
	
	public function del_file_inn(){
		$this->is_logged();
		$id = $_POST['id'];
		$o = $this->default_model->default_get_one_where('pedido_archivo', array('id_pedido_archivo' => $id));
		if(!empty($file_name)){
			if(!empty($o->archivo)){
				$path='./uploads/archivos/'.$o->archivo;
				if(file_exists($path)){
					@unlink($path);
				}
			}
		}
		$del = $this->default_model->default_delete('pedido_archivo', array('id_pedido_archivo' => $id));
	}
	
	public function upld_file_extra(){
		$this->is_logged();
		$id = $_POST['pedido_id'];
		$b = $_POST['bordado'];
		$file_name = '';
		if(!empty($_FILES)){
			$this->load->library('upload');
			if(!empty($_FILES['file']['name'])) {
				$config['upload_path'] = './uploads/archivos/';
				$config['allowed_types'] = '*';
				$config['max_size']	= '10240';
				$config['overwrite'] = TRUE;
				$config['file_name'] = uniqid();
				$this->upload->initialize($config);
				if (!$this->upload->do_upload('file')) {
					$data['error_foto'] = $this->upload->display_errors();
				} else {
					$data = $this->upload->data('file');
					$file_name = $this->upload->data('file_name');
					$n_last = $this->default_model->default_insert_one_get_id('pedido_archivo_extra', array('pedido' => $id,'bordado' => $b,'archivo' => $file_name,'estado' => 'activo'));
				}
			}
		}
	}
	
	public function del_file_extra_inn(){
		$this->is_logged();
		$id = $_POST['id'];
		$o = $this->default_model->default_get_one_where('pedido_archivo_extra', array('id_pedido_archivo_extra' => $id));
		if(!empty($file_name)){
			if(!empty($o->archivo)){
				$path='./uploads/archivos/'.$o->archivo;
				if(file_exists($path)){
					@unlink($path);
				}
			}
		}
		$del = $this->default_model->default_delete('pedido_archivo_extra', array('id_pedido_archivo_extra' => $id));
	}
	
	public function tab_save_inn(){
		$this->is_logged();
		$id = $_POST['id'];//id_pedido
		$b = $_POST['id_bordado'];//id_bordado
		$colores = $_POST['colores'];//colores
		$cantidad = $_POST['cantidad'];//cantidad
		$unidad = $_POST['unidad'];//unidad
		$iguales = $_POST['iguales'];//iguales
		$tiposbordados = $_POST['tiposbordados'];//tiposbordados
		$medidas = $_POST['medidas'];//medidas
		$observaciones = $_POST['observaciones'];//observaciones
		//pedido_bordado --- id_pedido_bordado,pedido,bordado,colores,cantidad,unidad_medida,radio,observaciones,estado
		$o_ped_bor = $this->default_model->default_get_one_where('pedido_bordado', array('pedido' => $id,'bordado' => $b));
		if(!empty($o_ped_bor->id_pedido_bordado)){
			$arr_values = array('colores' => $colores,'cantidad' => $cantidad,'unidad_medida' => $unidad,'radio' => $iguales,'observaciones' => $observaciones);
			$updt = $this->default_model->default_update('pedido_bordado', 'id_pedido_bordado', $o_ped_bor->id_pedido_bordado, $arr_values);
		} else {
			$n_last = $this->default_model->default_insert_one_get_id('pedido_bordado', array('pedido' => $id,'bordado' => $b,'colores' => $colores,'cantidad' => $cantidad,'unidad_medida' => $unidad,'radio' => $iguales,'observaciones' => $observaciones,'estado' => 'activo'));
		}
		//pedido_tipo_bordado --- id_pedido_tipo_bordado,pedido,bordado,tipo_bordado,nombre,alto,ancho,estado
		$arr_tb = explode(',',$tiposbordados);
		$arr_medidas = explode(',',$medidas);
		foreach($arr_tb as $key => $row){
			$o = $this->default_model->default_get_one_where('categoria_producto', array('id_categoria_producto' => $row));
			$arr_ax = explode('x',$arr_medidas[$key]);
			$o_ped_tipo_bor = $this->default_model->default_get_one_where('pedido_tipo_bordado', array('pedido' => $id,'bordado' => $b,'tipo_bordado' => $row));
			if(!empty($o_ped_tipo_bor->id_pedido_tipo_bordado)){
				$arr_values = array('nombre' => $o->nombre,'alto' => $arr_ax[1],'ancho' => $arr_ax[0]);
				$updt = $this->default_model->default_update('pedido_tipo_bordado', 'id_pedido_tipo_bordado', $o_ped_tipo_bor->id_pedido_tipo_bordado, $arr_values);
			} else {
				$n_last = $this->default_model->default_insert_one_get_id('pedido_tipo_bordado', array('pedido' => $id,'bordado' => $b,'tipo_bordado' => $row,'nombre' => $o->nombre,'alto' => $arr_ax[1],'ancho' => $arr_ax[0],'estado' => 'activo'));
			}
		}
		echo 'ok';
	}
	
	public function fn_solicitud_p(){
		$this->is_logged();
		$id = $_POST['id'];//id_pedido
		$forma = $_POST['forma'];//forma de pago
		$abonado = $_POST['paga'];//paga
		$t_name = $this->all_config_ci('table_name');
		$o_id = $this->all_config_ci('o_id');
		$o = $this->default_model->default_get_one_where($t_name, array($o_id => $id));
		$are_sum_ax = 0;
		$are_tipo_precio = $o->tipo_precio;
		$bs_cat_pro_arr = explode(",",$o->bordados);//categoria_producto
		foreach($bs_cat_pro_arr as $key => $row){
			$o_bdd = $this->default_model->default_get_one_where('categoria_producto', array('id_categoria_producto' => $row));
			$o_pedido_b = $this->default_model->default_get_one_where('pedido_bordado', array('pedido' => $o->id_pedido,'bordado' => $row));
			$inn_sum_ax = 0;
			$bs_arr = explode(",",$o_bdd->bordados);//bordados
			foreach($bs_arr as $b_key => $b_row){
				$o_b_nn = $this->default_model->default_get_one_where('bordado', array('id_bordado' => $b_row));
				$tag_precio = 'precio'.$are_tipo_precio;
				$inn_sum_ax += $o_b_nn->$tag_precio;
			}
			$are_sum_ax += ($inn_sum_ax * $o_pedido_b->cantidad);
		}
		//pedido --- id_pedido,usuario,tipo_precio,bordados,fecha_entrega,pago,costo,abonado,estado
		$updt = $this->default_model->default_update($t_name, $o_id, $id, array('pago' => $forma,'costo' => $are_sum_ax,'abonado' => $abonado,'estado' => 'solicitado'));
		$values = array('pedido' => $id,'abono' => $abonado,'fecha' => date('Y-m-d'),'estado' => 'activo');
		$n_last = $this->default_model->default_insert_one_get_id('pedido_abono', $values);
		echo 'ok';
	}
	
	public function fn_msj_p(){
		$this->is_logged();
		$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! El pedido ha sido Solicitado correctamente.');
		redirect($this->all_config_ci('url_controller'));
	}
	
	public function buscar_cliente_cn(){
		$this->is_logged();
		$cn = $_POST['cedula_nit'];//cedula_nit
		$out = 'no_found';
		$o = $this->default_model->default_get_one_where('usuario', array('cedula' => $cn));
		if(!empty($o->id_usuario)){
			$out = $o->id_usuario;
		} else {
			$o = $this->default_model->default_get_one_where('usuario', array('nit' => $cn));
			if(!empty($o->id_usuario)){
				$out = $o->id_usuario;
			}
		}
		echo $out;
	}
	
	public function get_cliente_cn_data(){
		$this->is_logged();
		$cn = $_POST['id'];
		$f = $_POST['field'];
		$o = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $cn));
		$out = $o->$f;
		echo $out;
	}
}