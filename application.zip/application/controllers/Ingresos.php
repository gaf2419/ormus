<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ingresos extends CI_Controller {

	private $genClass = 'El';
	private $disClass = 'o';
	
	function is_logged() {
		$sr_session_role = $this->all_config_ci('session_role');
        if (!@$this->session->userdata($sr_session_role))
            redirect('login');
    }

    function is_access($role=array()) {
        $sr_session_role = $this->all_config_ci('session_role');
		$permissions = empty($role)?array('administrator'):$role;
		if (@$this->session->userdata($sr_session_role) and !in_array($this->session->$sr_session_role->rol,$permissions))
            show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
    }
	
	private function all_config_ci($a='') {
		//ingreso --- id_ingreso,recibo,pagado_por,pagado_a,recibido_por,recibido_user,descripcion,valor,subtotal,impuesto,total,fecha,id_objeto,linea,tipo,estado
		$out = '';
		switch ($a){
			case 'session_role': $out='ormufss_user';break;
			case 'url_views': $out='ingresos';break;
			case 'url_controller': $out='ingresos';break;
			case 'name_controller': $out='Ingresos';break;
			case 'table_name': $out ='ingreso';break;
			case 'o_id': $out='id_ingreso';break;
			case 'o_required': $out=array('nombre' => 'Nombre');break;
			case 'o_unique_check': $out=array('ninguno');break;
			default: $out = '';
		}
		return $out;
    }

	public function index()	{
		$this->is_logged();
		$this->is_access();
		$this->load->helper('text');
		$this->list_range();
        $data = array();
		$d_start = '';
		$d_end = '';
		$arr_data_range = $this->session->flashdata('fechas_rango_v_fss');
		if(!empty($arr_data_range)){
			$d_start = $arr_data_range[0];
			$d_end = $arr_data_range[1];
			$this->session->keep_flashdata('fechas_rango_v_fss');
		} else {
			$d_start = date('Y-m-d');
			$d_end = date('Y-m-d');
		}
		$data['d_start'] = $d_start;
		$data['d_end'] = $d_end;
		$sql_total="SELECT sum(total) as subtotal FROM `gasto` WHERE fecha <='".$d_end."' && fecha >='".$d_start."'";
		$subtotal = $this->default_model->default_query_execute($sql_total)->row()->subtotal;
		$data['subtotal'] = $subtotal;
		
		$sql_ingresos="SELECT sum(total) as subtotal FROM `ingreso` WHERE fecha <='".$d_end."' && fecha >='".$d_start."'";
		$subtotal_ingresos = $this->default_model->default_query_execute($sql_ingresos)->row()->subtotal;
		$data['subtotal_ingresos'] = $subtotal_ingresos;
		
		$t_name = $this->all_config_ci('table_name');
		$t_id = $this->all_config_ci('o_id');
		$c_name = $this->all_config_ci('name_controller');
		$data['o_all'] = $this->default_model->default_get_all_where_order_by($t_name,$t_id.' desc',array('fecha >=' => $d_start,'fecha <=' => $d_end,'estado' => 'activo'));
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = $c_name;
		$data['title'] = 'Listado de '.$c_name;
		$data['title_page'] = 'Listado de '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/list', $data);
		$this->load->view('tpl/footer', $data);
	}
	
	public function list_range() {
		if(!empty($_POST)){
			if($this->session->flashdata('fechas_rango_v_fss')){
				$this->session->set_flashdata('fechas_rango_v_fss', array($_POST['fecha_inicio'],$_POST['fecha_final']));
			} else {
				$this->session->mark_as_flash('fechas_rango_v_fss');
				$this->session->set_flashdata('fechas_rango_v_fss', array($_POST['fecha_inicio'],$_POST['fecha_final']));
			}
		}
    }
}