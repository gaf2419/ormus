<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Agenda extends CI_Controller {

	private $genClass = 'El';
	private $disClass = 'o';
	
	function is_logged() {
		$sr_session_role = $this->all_config_ci('session_role');
        if (!@$this->session->userdata($sr_session_role))
            redirect('login');
    }

    function is_access($role=array()) {
        $sr_session_role = $this->all_config_ci('session_role');
		$permissions = empty($role)?array('administrator','sucursal'):$role;
		if (@$this->session->userdata($sr_session_role) and !in_array($this->session->$sr_session_role->rol,$permissions)){
			show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
		}
		if($this->session->$sr_session_role->rol=='sucursal'){
			$o_ssc_inn = $this->default_model->default_get_one_where('sucursal', array('usuario' => $this->session->$sr_session_role->id_usuario));
			$arrsscinn = explode(",",$o_ssc_inn->modulos);
			if(!in_array(6,$arrsscinn)){
				show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
			}
		}
    }
	
	private function all_config_ci($a='') {
		//pedido --- id_pedido,usuario,tipo_precio,bordados,fecha_entrega,pago,costo,abonado,estado
		$out = '';
		switch ($a){
			case 'session_role': $out='ormufss_user';break;
			case 'url_views': $out='agenda';break;
			case 'url_controller': $out='agenda';break;
			case 'name_controller': $out='Agenda';break;
			case 'table_name': $out ='pedido';break;
			case 'o_id': $out='id_pedido';break;
			case 'o_required': $out=array('nombre' => 'Nombre');break;
			case 'o_unique_check': $out=array('ninguno');break;
			default: $out = '';
		}
		return $out;
    }

	public function index()	{
		$this->is_logged();
		$sr_session_role = $this->all_config_ci('session_role');
		$r_idd = $this->session->$sr_session_role->rol;
		$this->is_access();
		$this->load->helper('text');
		$data = array();
		$t_name = $this->all_config_ci('table_name');
		$t_id = $this->all_config_ci('o_id');
		$c_name = $this->all_config_ci('name_controller');
		$sql = "SELECT * FROM `pedido` WHERE estado NOT IN ('presolicitado','finalizado')";
		$data['o_pedidos_all'] = $this->default_model->default_query_execute($sql);
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['sr_session_role'] = $sr_session_role;
		$data['active_mod'] = $c_name;
		$data['title'] = 'Listado de '.$c_name;
		$data['title_page'] = 'Listado de '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$data['full_calendar_citas'] = true;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/list', $data);
		$this->load->view('tpl/footer', $data);
	}

	public function show_data_pedido(){
		$this->is_logged();
		$this->is_access();
		$out = '';
		$id = $_POST['id'];
		$o = $this->default_model->default_get_one_where('pedido', array('id_pedido' => $id));
		$out .= '<div class="row">';
		$out .= '<div class="col-sm"><h5 class="font-weight-normal"><b>Pedido</b> #'.$o->codigo.'</h5></div>';
		$o_us = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $o->usuario));
		$out .= '<div class="col-sm text-sm-right"><h5 class="font-weight-normal"><b>Cliente</b> '.$o_us->nombre.' '.$o_us->apellido.'</h5></div>';
		$out .= '</div>';
		$out .= '<div class="row mt-1">';
		$out .= '<div class="col-sm"><h5 class="font-weight-normal"><b>Costo</b> '.$this->cart->format_number($o->costo).'</h5></div>';
		$out .= '<div class="col-sm text-sm-right"><h5 class="font-weight-normal"><b>Abonado</b> '.$this->cart->format_number($o->abonado).'</h5></div>';
		$out .= '</div>';
		$out .= '<div class="row mt-1">';
		$out .= '<div class="col-sm"><h5 class="font-weight-normal"><b>Entrega</b> '.$o->fecha_entrega.'</h5></div>';
		$out .= '<div class="col-sm text-sm-right"><h5 class="font-weight-normal"><b>Estado</b> '.$o->estado.'</h5></div>';
		$out .= '</div>';
		
		//bordados
		$arr_bdos = explode(',',$o->bordados);
		if(count($arr_bdos) > 0){
			$class_sm = count($arr_bdos) > 3?'col-sm-4':'col-sm';
			$out .= '<div class="row mt-3">';
			foreach($arr_bdos as $key => $row){
				$o_bb = $this->default_model->default_get_one_where('categoria_producto', array('id_categoria_producto' => $row));
				$o_pd_bb = $this->default_model->default_get_one_where('pedido_bordado', array('pedido' => $id,'bordado' => $row));
				$o_mkn = $this->default_model->default_get_one_where('maquina', array('id_maquina' => $o_bb->maquina));
				$out .= '<div class="'.$class_sm.'">';
				$out .= '<div class="p-3 h-100">';
				$color_border = $o_pd_bb->estado=='finalizada'?'border-success':'border-danger';
				$out .= '<div class="border '.$color_border.' rounded p-2 h-100">';
				
				$out .= '<h5 class="font-weight-normal"><b>Bordado</b>: '.$o_bb->nombre.'<span class="float-right"><b>Maq</b>: '.$o_mkn->nombre.'</span></h5>';
				$out .= '<h5 class="font-weight-normal"><b>Cantidad</b>: '.$o_pd_bb->cantidad.'<span class="float-right"><b>Realizadas</b>: '.$o_pd_bb->realizadas.'</span></h5>';
				$out .= '<h5 class="font-weight-normal"><b>Puntadas</b>: '.$o_pd_bb->puntadas.'<span class="float-right"><b>u/m</b>: '.$o_pd_bb->unidad_medida.'</span></h5>';
				$out .= '<hr>';
				$tipos = $this->default_model->default_get_all_where('pedido_tipo_bordado',array('pedido' => $id,'bordado' => $row,'estado' => 'activo'));
				if($tipos->num_rows() > 0){
					foreach($tipos->result() as $tb_key => $tb_row){
						$o_tipo_pd_bb = $this->default_model->default_get_one_where('bordado', array('id_bordado' => $tb_row->tipo_bordado));
						$out .= '<div class="row">';
						$out .= '<div class="col-sm"><p class="m-0"><b></b> '.$o_tipo_pd_bb->nombre.'</p></div>';
						$out .= '<div class="col-sm"><p class="m-0"><b>Alto</b> '.$tb_row->alto.' '.$o_pd_bb->unidad_medida.'</p></div>';
						$out .= '<div class="col-sm"><p class="m-0"><b>Ancho</b> '.$tb_row->ancho.' '.$o_pd_bb->unidad_medida.'</p></div>';
						$out .= '</div>';
					}
					$out .= '<hr>';
				}
				$out .= '<p class="m-0 mt-3"><b>Observaciones:</b> '.$o_pd_bb->observaciones.'</p>';
				
				$files_pedido = $this->default_model->default_get_all_where('pedido_archivo',array('pedido' => $id,'bordado' => $row,'estado' => 'activo'));
				if($files_pedido->num_rows() > 0){
					$out .= '<hr>';
					$out .= '<h5 class="text-primary">Archivos</h5>';
					$out .= '<ul class="list-group">';
					foreach($files_pedido->result() as $file_key => $file_row){
						$out .= '<li class="list-group-item d-flex justify-content-between align-items-center"><a target="_blank" href="'.base_url('uploads/archivos/'.$file_row->archivo).'">'.$file_row->archivo.'</a><a href="'.base_url('uploads/archivos/'.$file_row->archivo).'" download><span class="badge badge-primary badge-pill"><i class="fa fa-download fa-lg m-0"></i></span></a></li>';
					}
					$out .= '</ul>';
				}
				$files_pedido = $this->default_model->default_get_all_where('pedido_archivo_extra',array('pedido' => $id,'bordado' => $row,'estado' => 'activo'));
				if($files_pedido->num_rows() > 0){
					$out .= '<hr>';
					$out .= '<h5 class="text-primary">Bordados Extras</h5>';
					$out .= '<ul class="list-group">';
					foreach($files_pedido->result() as $file_key => $file_row){
						$out .= '<li class="list-group-item d-flex justify-content-between align-items-center"><a target="_blank" href="'.base_url('uploads/archivos/'.$file_row->archivo).'">'.$file_row->archivo.'</a><a href="'.base_url('uploads/archivos/'.$file_row->archivo).'" download><span class="badge badge-primary badge-pill"><i class="fa fa-download fa-lg m-0"></i></span></a></li>';
					}
					$out .= '</ul>';
				}
				
				$out .= '</div>';
				$out .= '</div>';
				$out .= '</div>';
			}
			$out .= '</div>';
		}
		/*$out .= '<div class="row">';
		$out .= '<div class="col-sm"></div>';
		$out .= '<div class="col-sm"></div>';
		$out .= '</div>';
		
		$out .= '';
		$out .= '';
		$out .= '';*/
		
		echo $out;
	}
}