<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	function is_config_db() {
        $this->load->model('Test_default_tables', 'comienzo');
        $this->comienzo->default_tables_test();
    }
	
	function is_logged() {
		$sr_session_role = $this->all_config_ci('session_role');
        if (!@$this->session->userdata($sr_session_role))
            redirect('login');
    }

    function is_access($role=array()) {
        $sr_session_role = $this->all_config_ci('session_role');
		$permissions = empty($role)?array('administrator'):$role;
		if (@$this->session->userdata($sr_session_role) and !in_array($this->session->$sr_session_role->rol,$permissions))
            show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
    }
	
	private function all_config_ci($a='') {
		$out = '';
		switch ($a){
			case 'session_role': $out='ormufss_user';break;
			case 'url_views': $out='dashboard';break;
			case 'url_controller': $out='dashboard';break;
			case 'name_controller': $out='Dashboard';break;
			case 'table_name': $out ='reserva';break;
			case 'o_id': $out='id_reserva';break;
			case 'o_required': $out=array('nombre' => 'Nombre','proyecto' => 'Proyecto');break;
			case 'o_unique_check': $out=array('ninguno');break;
			default: $out = '';
		}
		return $out;
    }

	public function index()	{
		$this->is_config_db();
		$this->is_logged();
		//$this->is_access();
		$this->load->helper('text');
		$sr_session_role = $this->all_config_ci('session_role');
		$data = array();
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$t_id = $this->all_config_ci('o_id');
		
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active'] = $c_name;
		$data['active_mod'] = $c_name;
		$data['title'] = 'Listado de '.$c_name;
		$data['title_page'] = 'Listado de '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		//$url_dashboard = $this->session->$sr_session_role->rol == 'administrator'?$this->all_config_ci('url_views'):$this->all_config_ci('url_views').'_empleado';
		$this->load->view('inicio/'.$this->all_config_ci('url_views'), $data);
		$this->load->view('tpl/footer', $data);
	}
	
}