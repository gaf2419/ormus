<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
	
	function is_logged() {
        if (!@$this->session->userdata('ormufss_user'))
            redirect('login');
    }
	
	private function all_config_ci($a='') {
		//usuario --- id_usuario,nombre,apellido,username,email,foto,password,rol,estado
		$out = '';
		switch ($a){
			case 'session_role': $out='ormufss_user';break;
			case 'url_base_uploads': $out='users';break;
			case 'url_views': $out='register';break;
			case 'url_controller': $out='register';break;
			case 'name_controller': $out='Registrarme';break;
			case 'table_name': $out ='usuario';break;
			case 'o_id': $out='id_usuario';break;
			case 'o_required': $out=array('nombre' => 'Nombre','apellido' => 'Apellidos','email' => 'Email','password' => 'Contrase&ntilde;a');break;
			case 'o_unique_check': $out=array('email');break;
			default: $out = '';
		}
		return $out;
    }
	
	public function index() {
		if (@$this->session->userdata('ormufss_user'))
			redirect('perfil');
		$url_b_uploads = $this->all_config_ci('url_base_uploads');
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$o_required = $this->all_config_ci('o_required');
		
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
		if(count($o_required) > 0){
			foreach($o_required as $key => $row){
				$this->form_validation->set_rules($key, '<em>'.$row.'</em>', 'trim|required');
				if($key=='password'){
					$this->form_validation->set_rules('password_repeat', 'Repetir contrase&ntilde;a', 'required|matches[password]');
				}
			}
		}
        if (!empty($_POST)) {
            if ($this->form_validation->run() == TRUE) {
				$file_name = '';
				if(!empty($_FILES)){
					$this->load->library('upload');
					if(!empty($_FILES['foto']['name'])) {
						$config['upload_path'] = './uploads/'.$url_b_uploads.'/';
						$config['allowed_types'] = '*';
						$config['max_size']	= '10240';
						$config['overwrite'] = TRUE;
						$config['file_name'] = uniqid();
						$this->upload->initialize($config);
						if (!$this->upload->do_upload('foto')) {
							$data['error_foto'] = $this->upload->display_errors();
						} else {
							$data = $this->upload->data('foto');
							$file_name = $this->upload->data('file_name');
							$file_path = $this->upload->data('file_path');
							$this->resize($file_path,$file_name);
						}
					}
				}
				$values = array();
				foreach($_POST as $key => $row){
					if($key!='password_repeat'){
						if($key=='password'){
							$values[$key] = md5($row);
						} else {
							$values[$key] = $row;
						}
					}
				}
				if(!empty($file_name)){
					$values['foto'] = $file_name;
				}
				$values['username'] = $_POST['email'];
				$values['rol'] = 'cliente';
				$values['estado'] = 'activo';
				$n_last = $this->default_model->default_insert_one_get_id($t_name, $values);
				$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! Su cuenta ha sido creada correctamente.');
				$lu = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $n_last));
				$this->session->set_userdata('ormufss_user', $lu);
				redirect('perfil');
            }
        }
		$data['o_disabled'] = false;
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['url_b_uploads'] = $url_b_uploads;
		$data['active_mod'] = $c_name;
		$data['active'] = $c_name;
		$data['title'] = $c_name;
		$data['title_page'] = $c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('inicio/'.$this->all_config_ci('url_views'), $data);
    }
	
	function resize($path,$name){
		$this->load->library('image_lib');
		$config['image_library'] = 'gd2';
		$config['new_image'] = $path.'thumbs';
		$config['source_image'] = $path.$name;
		$config['maintain_ratio'] = FALSE;
		$config['width']         = 250;
		$config['height']       = 250;
		$this->image_lib->initialize($config);
		$this->image_lib->resize();
	}
	
	public function username_check($str){
		$o_field = 'username';
		$t_name = $this->all_config_ci('table_name');
		$o_id = $this->all_config_ci('o_id');
		$o = $this->default_model->default_get_one_where($t_name, array($o_field => $str));
		if(!empty($o->$o_id)){
			$this->form_validation->set_message($o_field.'_check', 'Lo sentimos, el <b>'.$o_field.'</b> seleccionado ya existe en la plataforma.');
			return false;
		}
		return true;
	}
	public function email_check($str){
		$o_field = 'email';
		$t_name = $this->all_config_ci('table_name');
		$o_id = $this->all_config_ci('o_id');
		$o = $this->default_model->default_get_one_where($t_name, array($o_field => $str));
		if(!empty($o->$o_id)){
			$this->form_validation->set_message($o_field.'_check', 'Lo sentimos, el <b>'.$o_field.'</b> seleccionado ya existe en la plataforma.');
			return false;
		}
		return true;
	}
}
