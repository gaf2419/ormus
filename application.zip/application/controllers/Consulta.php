<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Consulta extends CI_Controller {

	public function index()	{
        //pedido --- id_pedido,codigo,usuario,tipo_precio,bordados,fecha_entrega,pago,costo,abonado,estado
		$data = array();
		$data['active'] = 'Consulta';
        $data['error_credenciales'] = FALSE;
        $data['is_peddni'] = FALSE;
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
        $this->form_validation->set_rules('cdd', '<em>Codigo</em>', 'trim|required');
        if (!empty($_POST)) {
            if ($this->form_validation->run() == TRUE) {
                $pedd = $this->default_model->default_get_one_where('pedido', array('codigo' => $_POST['cdd']));
                if(!empty($pedd->id_pedido)){
					//$arr_actives = array('solicitado' => '','tarea' => '','preaprobado' => '','aprobado' => '');
					$arr_actives = array('solicitado' => '','tarea' => '','preaprobado' => '','aprobado' => '');
					$estado_title = '';
					if($pedd->estado=='solicitado'){
						$estado_title = 'Solicitado';
						$arr_actives['solicitado']='active';
					} else if($pedd->estado=='tarea'){
						$estado_title = 'Elaboraci&oacute;n';
						$arr_actives['solicitado']='active';
						$arr_actives['tarea']='active';
					} else if($pedd->estado=='preaprobado'){
						$estado_title = 'Revisi&oacute;n';
						$arr_actives['solicitado']='active';
						$arr_actives['tarea']='active';
						$arr_actives['preaprobado']='active';
					} else if($pedd->estado=='aprobado'){
						$estado_title = 'Finalizado';
						$arr_actives['solicitado']='active';
						$arr_actives['tarea']='active';
						$arr_actives['preaprobado']='active';
						$arr_actives['aprobado']='active';
					}
					$data['estado_title'] = $estado_title;
					$data['arr_actives'] = $arr_actives;
					$data['o_peddni'] = $pedd;
					$data['is_peddni'] = TRUE;
				} else {
					$data['error_credenciales'] = TRUE;
				}
            }
        }
        $this->load->view('inicio/consulta', $data);
	}
}
