<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Perfil extends CI_Controller {

	function is_logged() {
		$sr_session_role = $this->all_config_ci('session_role');
        if (!@$this->session->userdata($sr_session_role))
            redirect('login');
    }

    function is_access($role=array()) {
        $sr_session_role = $this->all_config_ci('session_role');
		$permissions = empty($role)?array('administrator'):$role;
		if (@$this->session->userdata($sr_session_role) and !in_array($this->session->$sr_session_role->rol,$permissions))
            show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
    }
	
	private function all_config_ci($a='') {
		//usuario --- id_usuario,nombre,apellido,username,email,foto,password,rol,estado
		$out = '';
		switch ($a){
			case 'session_role': $out='ormufss_user';break;
			case 'url_base_uploads': $out='users';break;
			case 'url_views': $out='perfil';break;
			case 'url_controller': $out='perfil';break;
			case 'name_controller': $out='Perfil';break;
			case 'table_name': $out ='usuario';break;
			case 'o_id': $out='id_usuario';break;
			case 'o_required': $out=array('nombre' => 'Nombre','apellido' => 'Apellidos','username' => 'Username','email' => 'Email','password' => 'Contrase&ntilde;a');break;
			case 'o_unique_check': $out=array('username','email');break;
			default: $out = '';
		}
		return $out;
    }
	
	public function username_check($str){
		$o_field = 'username';
		$t_name = $this->all_config_ci('table_name');
		$o_id = $this->all_config_ci('o_id');
		$o = $this->default_model->default_get_one_where($t_name, array($o_field => $str));
		if(!empty($o->$o_id)){
			$this->form_validation->set_message($o_field.'_check', 'Lo sentimos, el <b>'.$o_field.'</b> seleccionado ya existe en la plataforma.');
			return false;
		}
		return true;
	}
	public function email_check($str){
		$o_field = 'email';
		$t_name = $this->all_config_ci('table_name');
		$o_id = $this->all_config_ci('o_id');
		$o = $this->default_model->default_get_one_where($t_name, array($o_field => $str));
		if(!empty($o->$o_id)){
			$this->form_validation->set_message($o_field.'_check', 'Lo sentimos, el <b>'.$o_field.'</b> seleccionado ya existe en la plataforma.');
			return false;
		}
		return true;
	}
	
	public function index() {
		$this->is_logged();
		$session_role=$this->all_config_ci('session_role');
		$o_id = $this->all_config_ci('o_id');
		$id=$this->session->$session_role->$o_id;
		if(empty($id)){
			redirect($this->all_config_ci('url_controller'));
		}
		$url_b_uploads = $this->all_config_ci('url_base_uploads');
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$o_required = $this->all_config_ci('o_required');
		
		$o = $this->default_model->default_get_one_where($t_name, array($o_id => $id));
		if(empty($o->$o_id)){
			$this->session->set_flashdata('msj_header_error_fss', 'Lo sentimos!!! El '.$c_name.' '.$id.' no existe.');
			redirect($this->all_config_ci('url_controller'));
		}
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
		if(count($o_required) > 0){
			foreach($o_required as $key => $row){
				$this->form_validation->set_rules($key, '<em>'.$row.'</em>', 'trim|required');
				if($key=='password'){
					$this->form_validation->set_rules('password_repeat', 'Repetir contrase&ntilde;a', 'required|matches[password]');
				}
			}
		}
        if (!empty($_POST)) {
            if ($this->form_validation->run() == TRUE) {
				$file_name = '';
				if(!empty($_FILES)){
					$this->load->library('upload');
					if(!empty($_FILES['foto']['name'])) {
						$config['upload_path'] = './uploads/'.$url_b_uploads.'/';
						$config['allowed_types'] = '*';
						$config['max_size']	= '10240';
						$config['overwrite'] = TRUE;
						$config['file_name'] = uniqid();
						$this->upload->initialize($config);
						if (!$this->upload->do_upload('foto')) {
							$data['error_foto'] = $this->upload->display_errors();
						} else {
							$data = $this->upload->data('foto');
							$file_name = $this->upload->data('file_name');
							$file_path = $this->upload->data('file_path');
							$this->resize($file_path,$file_name);
						}
					}
				}
				$values = array();
				foreach($_POST as $key => $row){
					if($key!='password_repeat'){
						if($key=='password'){
							$values[$key] = md5($row);
						} else {
							$values[$key] = $row;
						}
					}
				}
				if(!empty($file_name)){
					$values['foto'] = $file_name;
					if(!empty($o->foto)){
						$path='./uploads/'.$url_b_uploads.'/'.$o->foto;
						if(file_exists($path)){
							@unlink($path);
						}
						$path_thumbs='./uploads/'.$url_b_uploads.'/thumbs/'.$o->foto;
						if(file_exists($path_thumbs)){
							@unlink($path_thumbs);
						}
					}
				}
				$updt = $this->default_model->default_update($t_name, $o_id, $id, $values);
				$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! Sus datos de perfil han sido actualizados correctamente.');
				redirect($this->all_config_ci('url_controller'));
            }
        }
		$data['o'] = $o;
		$data['select_c_all'] = $this->default_model->default_get_all_where('categoria',array('estado' => 'activo'));
		$data['o_disabled'] = false;
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $o_id;
		$data['url_b_uploads'] = $url_b_uploads;
		$data['active_mod'] = $c_name;
		$data['title'] = 'Actualizar '.$c_name;
		$data['title_page'] = 'Actualizar '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/update', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	function resize($path,$name){
		$this->load->library('image_lib');
		$config['image_library'] = 'gd2';
		$config['new_image'] = $path.'thumbs';
		$config['source_image'] = $path.$name;
		$config['maintain_ratio'] = FALSE;
		$config['width']         = 250;
		$config['height']       = 250;
		$this->image_lib->initialize($config);
		$this->image_lib->resize();
	}
}