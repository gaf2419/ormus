<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		if(!is_https()){
			redirect('login');
		}
	}
	
	function is_config_db() {
        $this->load->model('Test_default_tables', 'comienzo');
        $this->comienzo->default_tables_test();
    }
	
	function is_logged() {
        if (!@$this->session->userdata('ormufss_user'))
            redirect('login');
    }
	
	public function index()	{
		$this->is_config_db();
		if (@$this->session->userdata('ormufss_user'))
			$this->redirect_is_log();
        $data = array();
		$data['active'] = 'Login';
        $data['error_credenciales'] = FALSE;		
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
        $this->form_validation->set_rules('username', '<em>Usuario</em>', 'trim|required');
        $this->form_validation->set_rules('password', '<em>Contrase&ntilde;a</em>', 'trim|required');
        if (!empty($_POST)) {
            if ($this->form_validation->run() == TRUE) {
                if (strpos($_POST['username'], '@') === false) {
                    $lu = $this->default_model->default_get_one_where('usuario', array('username' => $_POST['username'], 'password' => md5($_POST['password'])));
                    if (!empty($lu->email)) {
                        $this->dng_access($lu->estado);
						$this->session->set_userdata('ormufss_user', $lu);
						$this->redirect_is_log();
                    }
                } else {
                    $lu = $this->default_model->default_get_one_where('usuario', array('email' => $_POST['username'], 'password' => md5($_POST['password'])));
                    if (!empty($lu->email)) {
                        $this->dng_access($lu->estado);
						$this->session->set_userdata('ormufss_user', $lu);
						$this->redirect_is_log();
                    }
                }
                //error
                $data['error_credenciales'] = TRUE;
            }
        }
        $this->load->view('inicio/login_view', $data);
	}
	
	private function dng_access($stt) {
		if($stt=='denegado' OR $stt=='inactivo'){
			redirect('bloqueado');
		}
    }
	
	private function redirect_is_log() {
		if (@$this->session->userdata('ormufss_user')){
			$url_redirect = $this->session->ormufss_user->rol=='cliente'?'perfil':'dashboard';
			redirect($url_redirect);
		}
    }
	
	public function logout() {
		$this->is_logged();
        $this->session->unset_userdata('ormufss_user');
        redirect('login');
    }
}
