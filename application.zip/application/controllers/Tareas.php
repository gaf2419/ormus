<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tareas extends CI_Controller {

	private $genClass = 'El';
	private $disClass = 'o';
	
	function is_logged() {
		$sr_session_role = $this->all_config_ci('session_role');
        if (!@$this->session->userdata($sr_session_role))
            redirect('login');
    }

    function is_access($role=array()) {
        $sr_session_role = $this->all_config_ci('session_role');
		$permissions = empty($role)?array('administrator','operario'):$role;
		if (@$this->session->userdata($sr_session_role) and !in_array($this->session->$sr_session_role->rol,$permissions))
            show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
    }
	
	private function all_config_ci($a='') {
		//pedido --- id_pedido,usuario,tipo_precio,bordados,fecha_entrega,pago,costo,abonado,estado
		$out = '';
		switch ($a){
			case 'session_role': $out='ormufss_user';break;
			case 'url_views': $out='tareas';break;
			case 'url_controller': $out='tareas';break;
			case 'name_controller': $out='Tareas';break;
			case 'table_name': $out ='pedido';break;
			case 'o_id': $out='id_pedido';break;
			case 'o_required': $out=array('nombre' => 'Nombre');break;
			case 'o_unique_check': $out=array('ninguno');break;
			default: $out = '';
		}
		return $out;
    }

	public function index()	{
		$this->is_logged();
		$sr_session_role = $this->all_config_ci('session_role');
		$r_idd = $this->session->$sr_session_role->rol;
		$this->is_access();
		$this->load->helper('text');
		$data = array();
		$t_name = $this->all_config_ci('table_name');
		$t_id = $this->all_config_ci('o_id');
		$c_name = $this->all_config_ci('name_controller');
		$data['o_all'] = $this->default_model->default_get_all_elements_field_in_fss($t_name,'estado',array('tarea'),$t_id);
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['sr_session_role'] = $sr_session_role;
		$data['active_mod'] = $c_name;
		$data['title'] = 'Listado de '.$c_name;
		$data['title_page'] = 'Listado de '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/list', $data);
		$this->load->view('tpl/footer', $data);
	}
	
	public function details($id = '') {
		$this->is_logged();
		$this->is_access();
		if(empty($id)){
			redirect($this->all_config_ci('url_controller'));
		}
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$o_id = $this->all_config_ci('o_id');
		$sr_session_role = $this->all_config_ci('session_role');
		$r_idd = $this->session->$sr_session_role->rol;
		$o = $this->default_model->default_get_one_where($t_name, array($o_id => $id));
		if(empty($o->$o_id)){
			$this->session->set_flashdata('msj_header_error_fss', 'Lo sentimos!!! '.$this->genClass.' '.$c_name.' '.$id.' no existe.');
			redirect($this->all_config_ci('url_controller'));
		} else {
			if($o->estado != 'tarea'){
				redirect($this->all_config_ci('url_controller'));
			}
		}
		
		$data['o'] = $o;
		$data['o_us'] = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $o->usuario));
		$data['select_b_all'] = $this->default_model->default_get_all_where('categoria_producto',array('estado' => 'activo'));
		
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = $c_name;
		$data['title'] = 'Adicionar '.$c_name;
		$data['title_page'] = 'Adicionar '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/details', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	public function save_realizadas(){
		$this->is_logged();
		$id = $_POST['id'];//pedido_bordado
		$rr = $_POST['realizado'];
		$o = $this->default_model->default_get_one_where('pedido_bordado', array('id_pedido_bordado' => $id));
		if($o->cantidad == $o->realizadas){
			echo 'Lo sentimos!!! Ya esta tarea habia sido finalizada.';
		} else if($o->cantidad < $rr){
			echo 'Lo sentimos!!! El valor suministrado es superior a la cantidad de bordados de esta seccion.';
		} else {
			if($o->cantidad == $rr){
				$updt = $this->default_model->default_update('pedido_bordado','id_pedido_bordado', $id, array('realizadas' => $rr,'estado' => 'finalizada'));
				echo 'finalizada';
			} else {
				$updt = $this->default_model->default_update('pedido_bordado','id_pedido_bordado', $id, array('realizadas' => $rr));
				echo 'ok';
			}
		}
	}
	
	public function oper_end_pedido(){
		$this->is_logged();
		$id = $_POST['id'];//pedido_bordado
		//Todos
		$sql = "SELECT count(*) as total FROM `pedido_bordado` WHERE pedido=".$id;
		$o_all = $this->default_model->default_query_execute($sql)->row()->total;
		//Todos
		$sql_finalizada = "SELECT count(*) as total FROM `pedido_bordado` WHERE estado='finalizada' && pedido=".$id;
		$o_finalizada_all = $this->default_model->default_query_execute($sql_finalizada)->row()->total;
		
		if($o_all == $o_finalizada_all){
			$updt = $this->default_model->default_update('pedido','id_pedido', $id, array('estado' => 'preaprobado'));
			echo 'ok';
		} else {
			echo 'Lo sentimos!!! Faltan tareas por cumplir en este pedido.';
		}
	}
	
	public function fn_msj_p(){
		$this->is_logged();
		$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! Ha finalizado correctamente las tareas del pedido seleccionado.');
		redirect($this->all_config_ci('url_controller'));
	}
}