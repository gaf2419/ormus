<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuarios extends CI_Controller {

	function is_logged() {
		$sr_session_role = $this->all_config_ci('session_role');
        if (!@$this->session->userdata($sr_session_role))
            redirect('login');
    }

    function is_access($role=array()) {
        $sr_session_role = $this->all_config_ci('session_role');
		$permissions = empty($role)?array('administrator'):$role;
		if (@$this->session->userdata($sr_session_role) and !in_array($this->session->$sr_session_role->rol,$permissions))
            show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
    }
	
	private function all_config_ci($a='') {
		//usuario --- id_usuario,nombre,apellido,username,email,foto,password,rol,estado,sexo,direccion,cedula,telefono,no_empresa,nit,representante
		$out = '';
		switch ($a){
			case 'session_role': $out='ormufss_user';break;
			case 'url_base_uploads': $out='users';break;
			case 'url_views': $out='usuarios';break;
			case 'url_controller': $out='usuarios';break;
			case 'name_controller': $out='Usuarios';break;
			case 'table_name': $out ='usuario';break;
			case 'o_id': $out='id_usuario';break;
			case 'o_required': $out=array('nombre' => 'Nombre','apellido' => 'Apellidos','username' => 'Username','email' => 'Email','password' => 'Contrase&ntilde;a');break;
			case 'o_unique_check': $out=array('username','email');break;
			default: $out = '';
		}
		return $out;
    }

	public function index()	{
		$this->is_logged();
		$this->is_access();
		$data = array();
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$data['o_all'] = $this->default_model->default_get_all_where($t_name,array('id_usuario >' => 0));
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = $c_name;
		$data['title'] = 'Listado de '.$c_name;
		$data['title_page'] = 'Listado de '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/list', $data);
		$this->load->view('tpl/footer', $data);
	}
	
	public function add() {
		$this->is_logged();
		$this->is_access();
		$url_b_uploads = $this->all_config_ci('url_base_uploads');
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$o_required = $this->all_config_ci('o_required');
		$o_unique_check = $this->all_config_ci('o_unique_check');
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
		if(count($o_required) > 0){
			foreach($o_required as $key => $row){
				$rules = in_array($key,$o_unique_check)?'trim|required|callback_'.$key.'_check':'trim|required';
				$this->form_validation->set_rules($key, '<em>'.$row.'</em>', $rules);
				if($key=='password'){
					$this->form_validation->set_rules('password_repeat', 'Repetir contrase&ntilde;a', 'required|matches[password]');
				}
			}
		}
        if (!empty($_POST)) {
            if ($this->form_validation->run() == TRUE) {
				$file_name = '';
				if(!empty($_FILES)){
					$this->load->library('upload');
					if(!empty($_FILES['foto']['name'])) {
						$config['upload_path'] = './uploads/'.$url_b_uploads.'/';
						$config['allowed_types'] = '*';
						$config['max_size']	= '10240';
						$config['overwrite'] = TRUE;
						$config['file_name'] = uniqid();
						$this->upload->initialize($config);
						if (!$this->upload->do_upload('foto')) {
							$data['error_foto'] = $this->upload->display_errors();
						} else {
							$data = $this->upload->data('foto');
							$file_name = $this->upload->data('file_name');
							$file_path = $this->upload->data('file_path');
							$this->resize($file_path,$file_name);
						}
					}
				}
				$values = array();
				foreach($_POST as $key => $row){
					if($key!='password_repeat'){
						if($key=='password'){
							$values[$key] = md5($row);
						} else {
							$values[$key] = $row;
						}
					}
				}
				if(!empty($file_name)){
					$values['foto'] = $file_name;
				}
				$n_last = $this->default_model->default_insert_one_get_id($t_name, $values);
				//$msj = '<!DOCTYPE html><html lang="en"><head><title></title></head><body><div style="border-radius: 16px;background-color: #313131;color: #fff;padding: 15px;">En hora buena '.$_POST['nombre'].' !!!, Su cuenta de usuario ha sido creada correctamente. Para acceder a nuestra plataforma debes ir al siguiente enlace <a style="text-decoration: none;color: #03a9f3;" target="_blank" href="'.site_url().'">Subversion FullStack<span style="color: #00c292;">Team</span></a>.<br>Te esperamos,<br>atentamente,<br>FullStackTeam.</div></body></html>';
				//$this->fss->mail_fss($_POST['email'],$_POST['email'],'Cuenta de usuario Creada',$msj);
				$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! El '.$c_name.' '.$n_last.' ha sido creado correctamente.');
				redirect($this->all_config_ci('url_controller').'/details/'.$n_last);
            }
        }
		$data['select_c_all'] = $this->default_model->default_get_all_where('categoria',array('estado' => 'activo'));
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = $c_name;
		$data['title'] = 'Adicionar '.$c_name;
		$data['title_page'] = 'Adicionar '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/add', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	public function username_check($str){
		$o_field = 'username';
		$t_name = $this->all_config_ci('table_name');
		$o_id = $this->all_config_ci('o_id');
		$o = $this->default_model->default_get_one_where($t_name, array($o_field => $str));
		if(!empty($o->$o_id)){
			$this->form_validation->set_message($o_field.'_check', 'Lo sentimos, el <b>'.$o_field.'</b> seleccionado ya existe en la plataforma.');
			return false;
		}
		return true;
	}
	public function email_check($str){
		$o_field = 'email';
		$t_name = $this->all_config_ci('table_name');
		$o_id = $this->all_config_ci('o_id');
		$o = $this->default_model->default_get_one_where($t_name, array($o_field => $str));
		if(!empty($o->$o_id)){
			$this->form_validation->set_message($o_field.'_check', 'Lo sentimos, el <b>'.$o_field.'</b> seleccionado ya existe en la plataforma.');
			return false;
		}
		return true;
	}
	public function cedula_check($str){
		$o_field = 'cedula';
		$t_name = $this->all_config_ci('table_name');
		$o_id = $this->all_config_ci('o_id');
		$o = $this->default_model->default_get_one_where($t_name, array($o_field => $str));
		if(!empty($o->$o_id)){
			$this->form_validation->set_message($o_field.'_check', 'Lo sentimos, la <b>'.$o_field.'</b> seleccionado ya existe en la plataforma.');
			return false;
		}
		return true;
	}
	public function telefono_check($str){
		$o_field = 'telefono';
		$t_name = $this->all_config_ci('table_name');
		$o_id = $this->all_config_ci('o_id');
		$o = $this->default_model->default_get_one_where($t_name, array($o_field => $str));
		if(!empty($o->$o_id)){
			$this->form_validation->set_message($o_field.'_check', 'Lo sentimos, el <b>'.$o_field.'</b> seleccionado ya existe en la plataforma.');
			return false;
		}
		return true;
	}
	
	public function update($id='') {
		$this->is_logged();
		$this->is_access();
		if(empty($id)){
			redirect($this->all_config_ci('url_controller'));
		}
		$url_b_uploads = $this->all_config_ci('url_base_uploads');
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$o_required = $this->all_config_ci('o_required');
		$o_id = $this->all_config_ci('o_id');
		$o = $this->default_model->default_get_one_where($t_name, array($o_id => $id));
		if(empty($o->$o_id)){
			$this->session->set_flashdata('msj_header_error_fss', 'Lo sentimos!!! El '.$c_name.' '.$id.' no existe.');
			redirect($this->all_config_ci('url_controller'));
		}
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
		if(count($o_required) > 0){
			foreach($o_required as $key => $row){
				$this->form_validation->set_rules($key, '<em>'.$row.'</em>', 'trim|required');
				if($key=='password'){
					$this->form_validation->set_rules('password_repeat', 'Repetir contrase&ntilde;a', 'required|matches[password]');
				}
			}
		}
        if (!empty($_POST)) {
            if ($this->form_validation->run() == TRUE) {
				$file_name = '';
				if(!empty($_FILES)){
					$this->load->library('upload');
					if(!empty($_FILES['foto']['name'])) {
						$config['upload_path'] = './uploads/'.$url_b_uploads.'/';
						$config['allowed_types'] = '*';
						$config['max_size']	= '10240';
						$config['overwrite'] = TRUE;
						$config['file_name'] = uniqid();
						$this->upload->initialize($config);
						if (!$this->upload->do_upload('foto')) {
							$data['error_foto'] = $this->upload->display_errors();
						} else {
							$data = $this->upload->data('foto');
							$file_name = $this->upload->data('file_name');
							$file_path = $this->upload->data('file_path');
							$this->resize($file_path,$file_name);
						}
					}
				}
				$values = array();
				foreach($_POST as $key => $row){
					if($key!='password_repeat'){
						if($key=='password'){
							$values[$key] = md5($row);
						} else {
							$values[$key] = $row;
						}
					}
				}
				if(!empty($file_name)){
					$values['foto'] = $file_name;
				}
				$updt = $this->default_model->default_update($t_name, $o_id, $id, $values);
				$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! El '.$c_name.' '.$o->$o_id.' ha sido actualizado correctamente.');
				redirect($this->all_config_ci('url_controller').'/details/'.$o->$o_id);
            }
        }
		$data['o'] = $o;
		$data['select_c_all'] = $this->default_model->default_get_all_where('categoria',array('estado' => 'activo'));
		$data['o_disabled'] = false;
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $o_id;
		$data['url_b_uploads'] = $url_b_uploads;
		$data['active_mod'] = $c_name;
		$data['title'] = 'Actualizar '.$c_name;
		$data['title_page'] = 'Actualizar '.$c_name.' - <b>'.$o->$o_id.'</b>';
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/update', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	public function details($id='') {
		$this->is_logged();
		$this->is_access();
		if(empty($id)){
			redirect($this->all_config_ci('url_controller'));
		}
		$url_b_uploads = $this->all_config_ci('url_base_uploads');
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$o_required = $this->all_config_ci('o_required');
		$o_id = $this->all_config_ci('o_id');
		$o = $this->default_model->default_get_one_where($t_name, array($o_id => $id));
		if(empty($o->$o_id)){
			$this->session->set_flashdata('msj_header_error_fss', 'Lo sentimos!!! El '.$c_name.' '.$id.' no existe.');
			redirect($this->all_config_ci('url_controller'));
		}
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
		$data['o'] = $o;
		$data['select_c_all'] = $this->default_model->default_get_all_where('categoria',array('estado' => 'activo'));
		$data['o_disabled'] = true;
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $o_id;
		$data['url_b_uploads'] = $url_b_uploads;
		$data['active_mod'] = $c_name;
		$data['title'] = 'Detalles de '.$c_name;
		$data['title_page'] = 'Detalles de '.$c_name.' - <b>'.$o->$o_id.'</b>';
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/update', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	public function delete($id) {
		$this->is_logged();
		$this->is_access();
		$c_name = $this->all_config_ci('name_controller');
		$t_name = $this->all_config_ci('table_name');
		$o_id = $this->all_config_ci('o_id');
		$updt = $this->default_model->default_update($t_name, $o_id, $id, array('estado' => 'inactivo'));
		$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! El '.$c_name.' '.$id.' ha sido eliminado correctamente.');
		redirect($this->all_config_ci('url_controller'));
	}
	
	function resize($path,$name){
		$this->load->library('image_lib');
		$config['image_library'] = 'gd2';
		$config['new_image'] = $path.'thumbs';
		$config['source_image'] = $path.$name;
		$config['maintain_ratio'] = FALSE;
		$config['width']         = 250;
		$config['height']       = 250;
		$this->image_lib->initialize($config);
		$this->image_lib->resize();
	}
	
}