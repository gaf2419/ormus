<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sucursales extends CI_Controller {

	private $genClass = 'El';
	private $disClass = 'o';
	
	function is_logged() {
		$sr_session_role = $this->all_config_ci('session_role');
        if (!@$this->session->userdata($sr_session_role))
            redirect('login');
    }

    function is_access($role=array()) {
        $sr_session_role = $this->all_config_ci('session_role');
		$permissions = empty($role)?array('administrator'):$role;
		if (@$this->session->userdata($sr_session_role) and !in_array($this->session->$sr_session_role->rol,$permissions))
            show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
    }
	
	private function all_config_ci($a='') {
		//sucursal --- id_sucursal,nombre,direccion,usuario,modulos,estado
		$out = '';
		switch ($a){
			case 'session_role': $out='ormufss_user';break;
			case 'url_views': $out='sucursales';break;
			case 'url_controller': $out='sucursales';break;
			case 'name_controller': $out='Sucursales';break;
			case 'table_name': $out ='sucursal';break;
			case 'o_id': $out='id_sucursal';break;
			case 'o_required': $out=array('nombre' => 'Nombre');break;
			case 'o_unique_check': $out=array('ninguno');break;
			default: $out = '';
		}
		return $out;
    }

	public function index()	{
		$this->is_logged();
		$this->is_access();
		$this->load->helper('text');
		$data = array();
		$t_name = $this->all_config_ci('table_name');
		$t_id = $this->all_config_ci('o_id');
		$c_name = $this->all_config_ci('name_controller');
		$data['o_all'] = $this->default_model->default_get_all_elements_field_in_fss($t_name,'estado',array('activo'),$t_id);
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = $c_name;
		$data['title'] = 'Listado de '.$c_name;
		$data['title_page'] = 'Listado de '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/list', $data);
		$this->load->view('tpl/footer', $data);
	}
	
	public function add() {
		$this->is_logged();
		$this->is_access();
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$c_path = $this->all_config_ci('url_controller');
		$o_required = $this->all_config_ci('o_required');
		$o_unique_check = $this->all_config_ci('o_unique_check');
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
		if(count($o_required) > 0){
			foreach($o_required as $key => $row){
				$rules = in_array($key,$o_unique_check)?'trim|required|callback_'.$key.'_check':'trim|required';
				$this->form_validation->set_rules($key, '<em>'.$row.'</em>', $rules);
			}
		}
        if (!empty($_POST)) {
            if ($this->form_validation->run() == TRUE) {
				$values = array();
				$modulos = '';
				foreach($_POST as $key => $row){
					if($key=='modulos'){
						foreach($_POST['modulos'] as $b_key => $b_row){
							$modulos .= $b_key==0?$b_row:','.$b_row;
						}
						$values[$key] = $modulos;
					} else {
						$values[$key] = $row;
					}
				}
				$values['estado'] = 'activo';
				$n_last = $this->default_model->default_insert_one_get_id($t_name, $values);
				$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! '.$this->genClass.' '.$c_name.' '.$n_last.' ha sido cread'.$this->disClass.' correctamente.');
				redirect($this->all_config_ci('url_controller').'/details/'.$n_last);
            }
        }
		$data['select_us_all'] = $this->default_model->default_get_all_where('usuario',array('rol' => 'sucursal','estado' => 'activo'));
		$data['select_m_all'] = array(1 => 'Productos',2 => 'Categoria de Bordados',3 => 'Tipos de Bordados',4 => 'Maquinas',5 => 'Colores',6 => 'Agenda',7 => 'Rep Fotografico',8 => 'Rep Operario',9 => 'Facturacion',10 => 'Cat Gastos',11 => 'Gastos',12 => 'Inventario');
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = $c_name;
		$data['title'] = 'Adicionar '.$c_name;
		$data['title_page'] = 'Adicionar '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/add', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	public function update($id='') {
		$this->is_logged();
		$this->is_access();
		if(empty($id)){
			redirect($this->all_config_ci('url_controller'));
		}
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$o_required = $this->all_config_ci('o_required');
		$o_id = $this->all_config_ci('o_id');
		$o = $this->default_model->default_get_one_where($t_name, array($o_id => $id));
		if(empty($o->$o_id)){
			$this->session->set_flashdata('msj_header_error_fss', 'Lo sentimos!!! '.$this->genClass.' '.$c_name.' '.$id.' no existe.');
			redirect($this->all_config_ci('url_controller'));
		}
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
		if(count($o_required) > 0){
			foreach($o_required as $key => $row){
				$this->form_validation->set_rules($key, '<em>'.$row.'</em>', 'trim|required');
			}
		}
        if (!empty($_POST)) {
            if ($this->form_validation->run() == TRUE) {
				$values = array();
				$modulos = '';
				foreach($_POST as $key => $row){
					if($key=='modulos'){
						foreach($_POST['modulos'] as $b_key => $b_row){
							$modulos .= $b_key==0?$b_row:','.$b_row;
						}
						$values[$key] = $modulos;
					} else {
						$values[$key] = $row;
					}
				}
				$updt = $this->default_model->default_update($t_name, $o_id, $id, $values);
				$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! '.$this->genClass.' '.$c_name.' '.$o->$o_id.' ha sido actualizad'.$this->disClass.' correctamente.');
				redirect($this->all_config_ci('url_controller').'/details/'.$o->$o_id);
            }
        }
		$data['select_us_all'] = $this->default_model->default_get_all_where('usuario',array('rol' => 'sucursal','estado' => 'activo'));
		$data['select_m_all'] = array(1 => 'Productos',2 => 'Categoria de Bordados',3 => 'Tipos de Bordados',4 => 'Maquinas',5 => 'Colores',6 => 'Agenda',7 => 'Rep Fotografico',8 => 'Rep Operario',9 => 'Facturacion',10 => 'Cat Gastos',11 => 'Gastos',12 => 'Inventario');
		$data['o'] = $o;
		$data['o_disabled'] = false;
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $o_id;
		$data['active_mod'] = $c_name;
		$data['title'] = 'Actualizar '.$c_name;
		$data['title_page'] = 'Actualizar '.$c_name.' - <b>'.$o->$o_id.'</b>';
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/update', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	public function details($id='') {
		$this->is_logged();
		$this->is_access();
		if(empty($id)){
			redirect($this->all_config_ci('url_controller'));
		}
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$o_required = $this->all_config_ci('o_required');
		$o_id = $this->all_config_ci('o_id');
		$o = $this->default_model->default_get_one_where($t_name, array($o_id => $id));
		if(empty($o->$o_id)){
			$this->session->set_flashdata('msj_header_error_fss', 'Lo sentimos!!! '.$this->genClass.' '.$c_name.' '.$id.' no existe.');
			redirect($this->all_config_ci('url_controller'));
		}
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
		$data['select_us_all'] = $this->default_model->default_get_all_where('usuario',array('rol' => 'sucursal','estado' => 'activo'));
		$data['select_m_all'] = array(1 => 'Productos',2 => 'Categoria de Bordados',3 => 'Tipos de Bordados',4 => 'Maquinas',5 => 'Colores',6 => 'Agenda',7 => 'Rep Fotografico',8 => 'Rep Operario',9 => 'Facturacion',10 => 'Cat Gastos',11 => 'Gastos',12 => 'Inventario');
		$data['o'] = $o;
		$data['o_disabled'] = true;
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $o_id;
		$data['active_mod'] = $c_name;
		$data['title'] = 'Detalles de '.$c_name;
		$data['title_page'] = 'Detalles de '.$c_name.' - <b>'.$o->$o_id.'</b>';
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/update', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	public function delete($id) {
		$this->is_logged();
		$this->is_access();
		$c_name = $this->all_config_ci('name_controller');
		$t_name = $this->all_config_ci('table_name');
		$o_id = $this->all_config_ci('o_id');
		$updt = $this->default_model->default_update($t_name, $o_id, $id, array('estado' => 'inactivo'));
		$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! '.$this->genClass.' '.$c_name.' '.$id.' ha sido eliminad'.$this->disClass.' correctamente.');
		redirect($this->all_config_ci('url_controller'));
	}
}