<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inventario extends CI_Controller {

	private $genClass = 'El';
	private $disClass = 'o';
	
	function is_logged() {
		$sr_session_role = $this->all_config_ci('session_role');
        if (!@$this->session->userdata($sr_session_role))
            redirect('login');
    }

    function is_access($role=array()) {
        $sr_session_role = $this->all_config_ci('session_role');
		$permissions = empty($role)?array('administrator','sucursal'):$role;
		if (@$this->session->userdata($sr_session_role) and !in_array($this->session->$sr_session_role->rol,$permissions)){
			show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
		}
		if($this->session->$sr_session_role->rol=='sucursal'){
			$o_ssc_inn = $this->default_model->default_get_one_where('sucursal', array('usuario' => $this->session->$sr_session_role->id_usuario));
			$arrsscinn = explode(",",$o_ssc_inn->modulos);
			if(!in_array(12,$arrsscinn)){
				show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
			}
		}
    }
	
	private function all_config_ci($a='') {
		//gasto --- id_gasto,nombre,descripcion,categoria,fecha,total,estado
		$out = '';
		switch ($a){
			case 'session_role': $out='ormufss_user';break;
			case 'url_views': $out='inventario';break;
			case 'url_controller': $out='inventario';break;
			case 'name_controller': $out='Inventario';break;
			case 'table_name': $out ='producto';break;
			case 'o_id': $out='id_producto';break;
			case 'o_required': $out=array('producto' => 'producto');break;
			case 'o_unique_check': $out=array('ninguno');break;
			default: $out = '';
		}
		return $out;
    }

	public function index()	{
		$this->is_logged();
		$this->is_access();
		$this->load->helper('text');
        $data = array();
		$t_name = $this->all_config_ci('table_name');
		$t_id = $this->all_config_ci('o_id');
		$c_name = $this->all_config_ci('name_controller');
		$data['o_all'] = $this->default_model->default_get_all_where_order_by($t_name,$t_id.' desc',array('cantidad' => 0,'estado' => 'activo'));
		$data['o_ing_all'] = $this->default_model->default_get_all_where_order_by('ingreso','id_ingreso desc',array('estado' => 'activo'));
		$data['o_ajuste_all'] = $this->default_model->default_get_all_where_order_by('ajuste','id_ajuste desc',array('estado' => 'activo'));
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = $c_name;
		$data['title'] = 'Listado de '.$c_name;
		$data['title_page'] = 'Listado de '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/list', $data);
		$this->load->view('tpl/footer', $data);
	}
	
	public function add() {
		$this->is_logged();
		$this->is_access();
		$t_name = $this->all_config_ci('table_name');
		$c_name = 'Ingreso';
		$c_path = $this->all_config_ci('url_controller');
		$o_required = $this->all_config_ci('o_required');
		$o_unique_check = $this->all_config_ci('o_unique_check');
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
		if(count($o_required) > 0){
			foreach($o_required as $key => $row){
				$this->form_validation->set_rules($key, '<em>'.$row.'</em>', 'trim|required');
			}
		}
        if (!empty($_POST)) {
            if ($this->form_validation->run() == TRUE) {
				//ingreso --- id_ingreso,nombre,producto,descripcion,cantidad,factura,total,fecha,estado
				$values = array();
				$o = $this->default_model->default_get_one_where('producto', array('id_producto' => $_POST['producto']));
				foreach($_POST as $key => $row){
					if($key == 'producto'){
						$values['nombre'] = $o->nombre;
						$values[$key] = $row;
					} else {
						$values[$key] = $row;
					}
					
				}
				$values['total'] = $_POST['cantidad'] * $o->costo;
				$values['fecha'] = date('Y-m-d');
				$values['estado'] = 'activo';
				$cant_old = !empty($o->cantidad)?$o->cantidad:0;
				$ct_new = $cant_old + $_POST['cantidad'];
				$updt = $this->default_model->default_update('producto', 'id_producto', $_POST['producto'], array('cantidad' => $ct_new));
				$n_last = $this->default_model->default_insert_one_get_id('ingreso', $values);
				$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! '.$this->genClass.' '.$c_name.' '.$n_last.' ha sido cread'.$this->disClass.' correctamente.');
				redirect($this->all_config_ci('url_controller'));
            }
        }
		$data['select_p_all'] = $this->default_model->default_get_all_where('producto',array('estado' => 'activo'));
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = $c_name;
		$data['title'] = 'Adicionar '.$c_name;
		$data['title_page'] = 'Adicionar '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/add', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	public function ajuste() {
		$this->is_logged();
		$this->is_access();
		$t_name = $this->all_config_ci('table_name');
		$c_name = 'Ajuste';
		$c_path = $this->all_config_ci('url_controller');
		$o_required = $this->all_config_ci('o_required');
		$o_unique_check = $this->all_config_ci('o_unique_check');
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
		if(count($o_required) > 0){
			foreach($o_required as $key => $row){
				$this->form_validation->set_rules($key, '<em>'.$row.'</em>', 'trim|required');
			}
		}
        if (!empty($_POST)) {
            if ($this->form_validation->run() == TRUE) {
				//ajuste --- id_ajuste,codigo,nombre,producto,cantidad,total,fecha,estado
				$values = array();
				$o = $this->default_model->default_get_one_where('producto', array('id_producto' => $_POST['producto']));
				foreach($_POST as $key => $row){
					if($key == 'producto'){
						$values['codigo'] = $o->codigo;
						$values['nombre'] = $o->nombre;
						$values[$key] = $row;
					} else {
						$values[$key] = $row;
					}
					
				}
				$values['total'] = $_POST['cantidad'] * $o->costo;
				$values['fecha'] = date('Y-m-d');
				$values['estado'] = 'activo';
				$cant_old = !empty($o->cantidad)?$o->cantidad:0;
				$ct_new = $cant_old - $_POST['cantidad'];
				$updt = $this->default_model->default_update('producto', 'id_producto', $_POST['producto'], array('cantidad' => $ct_new));
				$n_last = $this->default_model->default_insert_one_get_id('ajuste', $values);
				$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! '.$this->genClass.' '.$c_name.' '.$n_last.' ha sido cread'.$this->disClass.' correctamente.');
				redirect($this->all_config_ci('url_controller'));
            }
        }
		$data['select_p_all'] = $this->default_model->default_get_all_where('producto',array('estado' => 'activo'));
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = $c_name;
		$data['title'] = 'Adicionar '.$c_name;
		$data['title_page'] = 'Adicionar '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/ajuste', $data);
		$this->load->view('tpl/footer', $data);
    }
}