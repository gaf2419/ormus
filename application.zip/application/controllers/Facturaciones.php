<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Facturaciones extends CI_Controller {

	private $genClass = 'El';
	private $disClass = 'o';

	function is_logged() {
		$sr_session_role = $this->all_config_ci('session_role');
        if (!@$this->session->userdata($sr_session_role))
            redirect('login');
    }

    function is_access($role=array()) {
        $sr_session_role = $this->all_config_ci('session_role');
		$permissions = empty($role)?array('administrator','recepcion','sucursal'):$role;
		if (@$this->session->userdata($sr_session_role) and !in_array($this->session->$sr_session_role->rol,$permissions)){
			show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
		}
		if($this->session->$sr_session_role->rol=='sucursal'){
			$o_ssc_inn = $this->default_model->default_get_one_where('sucursal', array('usuario' => $this->session->$sr_session_role->id_usuario));
			$arrsscinn = explode(",",$o_ssc_inn->modulos);
			if(!in_array(9,$arrsscinn)){
				show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
			}
		}
    }

	private function all_config_ci($a='') {
		//venta --- id_venta,factura,productos,cliente,vendedor,total,fecha,estado
		$out = '';
		switch ($a){
			case 'session_role': $out='ormufss_user';break;
			case 'url_views': $out='facturaciones';break;
			case 'url_controller': $out='facturaciones';break;
			case 'name_controller': $out='Facturaciones';break;
			case 'table_name': $out ='pedido';break;
			case 'o_id': $out='id_pedido';break;
			case 'o_required': $out=array('cliente' => 'cliente');break;
			case 'o_unique_check': $out=array('ninguno');break;
			default: $out = '';
		}
		return $out;
    }

	public function index()	{
		$this->is_logged();
		$this->is_access();
		$this->load->helper('text');
        $data = array();
		$t_name = $this->all_config_ci('table_name');
		$t_id = $this->all_config_ci('o_id');
		$c_name = $this->all_config_ci('name_controller');
		$data['o_all'] = $this->default_model->default_get_all_elements_field_not_in_nn_fss($t_name,'estado',array('presolicitado'),$t_id);
		//venta --- id_venta,factura,productos,cliente,vendedor,total,fecha,estado
		$data['o_v_all'] = $this->default_model->default_get_all_elements_field_in_fss('venta','estado',array('activo'),'id_venta');
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = $c_name;
		$data['title'] = 'Listado de '.$c_name;
		$data['title_page'] = 'Listado de '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/list', $data);
		$this->load->view('tpl/footer', $data);
	}
	
	public function facturas($id=''){
		//pedido_abono --- id_pedido_abono,pedido,abono,fecha,estado
		$this->is_logged();
		$sr_session_role = $this->all_config_ci('session_role');
		$r_idd = $this->session->$sr_session_role->rol;
		$this->is_access();
		if(empty($id)){
			redirect($this->all_config_ci('url_controller'));
		}
		$this->load->helper('text');
		$data = array();
		$t_name = $this->all_config_ci('table_name');
		$t_id = $this->all_config_ci('o_id');
		$c_name = $this->all_config_ci('name_controller');
		$data['o_all'] = $this->default_model->default_get_all_where('pedido_abono',array('pedido' => $id,'estado' => 'activo'));
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['sr_session_role'] = $sr_session_role;
		$data['active_mod'] = $c_name;
		$data['title'] = 'Listado de '.$c_name;
		$data['title_page'] = 'Listado de '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$data['o_id_pedido'] = $id;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/facturas', $data);
		$this->load->view('tpl/footer', $data);
	}
	
	public function details($id='') {
		$this->is_logged();
		$this->is_access();
		$this->load->helper('text');
		if(empty($id)){
			redirect($this->all_config_ci('url_controller'));
		}
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$o_required = $this->all_config_ci('o_required');
		$o_id = $this->all_config_ci('o_id');
		//pedido_abono --- id_pedido_abono,pedido,abono,fecha,estado
		$o_factura = $this->default_model->default_get_one_where('pedido_abono', array('id_pedido_abono' => $id));
		$o = $this->default_model->default_get_one_where($t_name, array($o_id => $o_factura->pedido));
		if(empty($o->$o_id)){
			$this->session->set_flashdata('msj_header_error_fss', 'Lo sentimos!!! '.$this->genClass.' '.$c_name.' '.$id.' no existe.');
			redirect($this->all_config_ci('url_controller'));
		}
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
		$data['o_factura'] = $o_factura;
		$data['o'] = $o;
		$data['o_us'] = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $o->usuario));
		$data['o_disabled'] = true;
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $o_id;
		$data['active_mod'] = $c_name;
		$data['title'] = 'Detalles de '.$c_name;
		$data['title_page'] = 'Detalles de '.$c_name.' - <b>'.$o->$o_id.'</b>';
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/detalles', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	public function add() {
		$this->is_logged();
		$this->is_access();
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$c_path = $this->all_config_ci('url_controller');
		$o_required = $this->all_config_ci('o_required');
		$o_unique_check = $this->all_config_ci('o_unique_check');
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
		if(count($o_required) > 0){
			foreach($o_required as $key => $row){
				$rules = in_array($key,$o_unique_check)?'trim|required|callback_'.$key.'_check':'trim|required';
				$this->form_validation->set_rules($key, '<em>'.$row.'</em>', $rules);
			}
		}
        if (!empty($_POST)) {
            if ($this->form_validation->run() == TRUE) {
				//echo var_dump($_POST);exit();
				//venta --- id_venta,factura,productos,cantidades,cliente,vendedor,total,fecha,estado
				$o_us = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $_POST['cliente']));
				$num_precio = $o_us->tipo_precio;
				$tag_precio = 'precio'.$num_precio;
				$values = array();
				$this->load->library('utiles');
				$factura = $this->utiles->gcode_simple('venta','factura');
				$values['factura'] = $factura;
				$total = 0;
				foreach($_POST as $key => $row){
					if($key=='productos'){
						$str_productos = '';
						$str_cants = '';
						foreach($_POST['productos'] as $p_key => $p_row){
							$o_p = $this->default_model->default_get_one_where('producto', array('id_producto' => $p_row));
							$total += $o_p->$tag_precio * $_POST['cantidades'][$p_key];
							$str_productos .= $p_key==0?$p_row:','.$p_row;
							$str_cants .= $p_key==0?$_POST['cantidades'][$p_key]:','.$_POST['cantidades'][$p_key];
						}
						$values['productos'] = $str_productos;
						$values['cantidades'] = $str_cants;
					} else if($key=='cantidades') {
						
					} else {
						$values[$key] = $row;
					}
					
				}
				$sr_session_role = $this->all_config_ci('session_role');
				$vendedor = $this->session->$sr_session_role->id_usuario;
				$values['vendedor'] = $vendedor;
				$values['total'] = $total;
				$values['fecha'] = date('Y-m-d');
				$values['estado'] = 'activo';
				$n_last = $this->default_model->default_insert_one_get_id('venta', $values);
				$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! La venta ha sido creada correctamente.');
				redirect($this->all_config_ci('url_controller').'/venta/'.$n_last);
            }
        }
		$data['select_p_all'] = $this->default_model->default_get_all_where('producto',array('estado' => 'activo'));
		$data['select_c_all'] = $this->default_model->default_get_all_where('usuario',array('rol' => 'cliente'));
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = $c_name;
		$data['title'] = 'Adicionar '.$c_name;
		$data['title_page'] = 'Adicionar '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/add', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	public function venta($id='') {
		$this->is_logged();
		$this->is_access();
		$this->load->helper('text');
		if(empty($id)){
			redirect($this->all_config_ci('url_controller'));
		}
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$o_required = $this->all_config_ci('o_required');
		$o_id = 'id_venta';
		$o = $this->default_model->default_get_one_where('venta', array('id_venta' => $id));
		if(empty($o->id_venta)){
			$this->session->set_flashdata('msj_header_error_fss', 'Lo sentimos!!! '.$this->genClass.' '.$c_name.' '.$id.' no existe.');
			redirect($this->all_config_ci('url_controller'));
		}
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
		$data['o'] = $o;
		$data['o_us'] = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $o->cliente));
		$data['o_disabled'] = true;
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $o_id;
		$data['active_mod'] = $c_name;
		$data['title'] = 'Detalles de '.$c_name;
		$data['title_page'] = 'Detalles de '.$c_name.' - <b>'.$o->$o_id.'</b>';
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/venta', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	public function load_date() {
		if(!empty($_POST)){
			if($this->session->flashdata('fechas_nn_fss')){
				$this->session->set_flashdata('fechas_nn_fss', array($_POST['d_date']));
			} else {
				$this->session->mark_as_flash('fechas_nn_fss');
				$this->session->set_flashdata('fechas_nn_fss', array($_POST['d_date']));
			}
		}
    }
	
	public function caja()	{
		//box_xax   ---  id_box_xax,usuario,cincuenta,cien,doscientos,quinientos,mil,dosmil,cincomil,diezmil,veintemil,cincuentamil,cienmil,
		//entrada,salida,vendido,descuadre,fecha,inicio,cierre,estado_caja,estado
		$this->is_logged();
		$this->is_access();
		$this->load_date();
		$this->load->helper('text');
		$sr_session_role = $this->all_config_ci('session_role');
        $data = array();
		$d_date = '';
		$d_start = '';
		$d_end = '';
		$arr_data_range = $this->session->flashdata('fechas_nn_fss');
		if(!empty($arr_data_range)){
			$d_date = $arr_data_range[0];
			$this->session->keep_flashdata('fechas_nn_fss');
		} else {
			$d_date = date('Y-m');
		}
		$arr_date = explode("-",$d_date);
		$yy = $arr_date[0];
		$mm = $arr_date[1];
		if(substr($mm,0) == '0'){
			$mm = substr($mm,1);
		}
		$max_days = date('t', mktime(0, 0, 0, $mm, 1, $yy));
		$d_start = $yy.'-'.$mm.'-01';
		$d_end = $yy.'-'.$mm.'-'.$max_days;
		$data['d_date'] = $d_date;
		$values_w = array('fecha >=' => $d_start,'fecha <=' => $d_end,'estado' => 'activo');
		if($this->session->$sr_session_role->rol != 'administrator') {
			$values_w = array('usuario' => $this->session->$sr_session_role->id_usuario,'fecha >=' => $d_start,'fecha <=' => $d_end,'estado' => 'activo');
		}
		$data['o_all'] = $this->default_model->default_get_all_where_order_by('box_xax','id_box_xax asc',$values_w);
		
		
		$t_name = $this->all_config_ci('table_name');
		$t_id = $this->all_config_ci('o_id');
		$c_name = $this->all_config_ci('name_controller');
		
		$o_cj_ini = $this->default_model->default_get_one_where('box_xax', array('usuario' => $this->session->$sr_session_role->id_usuario,'estado_caja' => 'iniciado','estado' => 'activo'));
		$data['o_inicio_caja'] = empty($o_cj_ini);
		$data['o_cierre_caja'] = !empty($o_cj_ini);
		
		$data['session_role'] = $sr_session_role;
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = $c_name;
		$data['title'] = 'Listado de '.$c_name;
		$data['title_page'] = 'Listado de '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/caja', $data);
		$this->load->view('tpl/footer', $data);
	}
	
	public function ad_inicio_caja() {
		//recibo_caja   ---  id_recibo_caja,usuario,cincuenta,cien,doscientos,quinientos,mil,dosmil,cincomil,diezmil,veintemil,cincuentamil,cienmil,total,categoria,fecha,estado
		$sr_session_role = $this->all_config_ci('session_role');
		$values = array('usuario' => $this->session->$sr_session_role->id_usuario,'entrada' => $_POST['valor'],'descuadre' => 0,'fecha' => date('Y-m-d'),'inicio' => date('Y-m-d H:i:s'),'estado_caja' => 'iniciado','estado' => 'activo');
		$n_last = $this->default_model->default_insert_one_get_id('box_xax', $values);
		echo 'ok';
    }
	
	public function ad_cierre_caja() {
		//recibo_caja   ---  id_recibo_caja,usuario,cincuenta,cien,doscientos,quinientos,mil,dosmil,cincomil,diezmil,veintemil,cincuentamil,cienmil,total,categoria,fecha,estado
		$sr_session_role = $this->all_config_ci('session_role');
		$o = $this->default_model->default_get_one_where('box_xax', array('usuario' => $this->session->$sr_session_role->id_usuario,'estado_caja' => 'iniciado'));
		$t=0;
		$cincuenta = !empty($_POST['cincuenta'])?$_POST['cincuenta']:0;
		$t += $cincuenta * 50;
		$cien = !empty($_POST['cien'])?$_POST['cien']:0;
		$t += $cien * 100;
		$doscientos = !empty($_POST['doscientos'])?$_POST['doscientos']:0;
		$t += $doscientos * 200;
		$quinientos = !empty($_POST['quinientos'])?$_POST['quinientos']:0;
		$t += $quinientos * 500;
		$mil = !empty($_POST['mil'])?$_POST['mil']:0;
		$t += $mil * 1000;
		$dosmil = !empty($_POST['dosmil'])?$_POST['dosmil']:0;
		$t += $dosmil * 2000;
		$cincomil = !empty($_POST['cincomil'])?$_POST['cincomil']:0;
		$t += $cincomil * 5000;
		$diezmil = !empty($_POST['diezmil'])?$_POST['diezmil']:0;
		$t += $diezmil * 10000;
		$veintemil = !empty($_POST['veintemil'])?$_POST['veintemil']:0;
		$t += $veintemil * 20000;
		$cincuentamil = !empty($_POST['cincuentamil'])?$_POST['cincuentamil']:0;
		$t += $cincuentamil * 50000;
		$cienmil = !empty($_POST['cienmil'])?$_POST['cienmil']:0;
		$t += $cienmil * 100000;
		$vendido = $this->get_vendido_caja($o->fecha);
		$aux_caja = $vendido + $o->entrada;
		$descuadre = $aux_caja < $t?$t-$aux_caja:$aux_caja-$t;
		$values = array('usuario' => $this->session->$sr_session_role->id_usuario,'cincuenta' => $cincuenta,'cien' => $cien,'doscientos' => $doscientos,'quinientos' => $quinientos,'mil' => $mil,'dosmil' => $dosmil,'cincomil' => $cincomil,'diezmil' => $diezmil,'veintemil' => $veintemil,'cincuentamil' => $cincuentamil,'cienmil' => $cienmil,'salida' => $t,'vendido' => $vendido,'descuadre' => $descuadre,'cierre' => date('Y-m-d H:i:s'),'estado_caja' => 'cerrado');
		$updt = $this->default_model->default_update('box_xax', 'id_box_xax', $o->id_box_xax, $values);
		echo 'ok';
    }
	
	public function get_vendido_caja($date='') {
		if(empty($date)){
			$date = date('Y-m-d');
		}
		$sr_session_role = $this->all_config_ci('session_role');
		$sql_total="SELECT sum(total) as subtotal FROM `venta` WHERE fecha ='".$date."' && vendedor=".$this->session->$sr_session_role->id_usuario;
		$t = $this->default_model->default_query_execute($sql_total)->row()->subtotal;
		return $t;
    }
	
	public function historial($id = '') {
		$this->is_logged();
		$this->is_access();
		if(empty($id)){
			redirect($this->all_config_ci('url_controller'));
		}
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$o_id = $this->all_config_ci('o_id');
		$sr_session_role = $this->all_config_ci('session_role');
		$r_idd = $this->session->$sr_session_role->rol;
		$o = $this->default_model->default_get_one_where($t_name, array($o_id => $id));
		if(empty($o->$o_id)){
			$this->session->set_flashdata('msj_header_error_fss', 'Lo sentimos!!! '.$this->genClass.' '.$c_name.' '.$id.' no existe.');
			redirect($this->all_config_ci('url_controller'));
		} else {
		}
		$data['o'] = $o;
		$data['o_us'] = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $o->usuario));
		$data['select_b_all'] = $this->default_model->default_get_all_where('categoria_producto',array('estado' => 'activo'));
		
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = $c_name;
		$data['title'] = 'Adicionar '.$c_name;
		$data['title_page'] = 'Adicionar '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/historial', $data);
		$this->load->view('tpl/footer', $data);
    }
	
}