<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reporte_operario extends CI_Controller {

	private $genClass = 'El';
	private $disClass = 'o';
	
	function is_logged() {
		$sr_session_role = $this->all_config_ci('session_role');
        if (!@$this->session->userdata($sr_session_role))
            redirect('login');
    }

	function is_access($role=array()) {
        $sr_session_role = $this->all_config_ci('session_role');
		$permissions = empty($role)?array('administrator','supervisor','sucursal'):$role;
		if (@$this->session->userdata($sr_session_role) and !in_array($this->session->$sr_session_role->rol,$permissions)){
			show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
		}
		if($this->session->$sr_session_role->rol=='sucursal'){
			$o_ssc_inn = $this->default_model->default_get_one_where('sucursal', array('usuario' => $this->session->$sr_session_role->id_usuario));
			$arrsscinn = explode(",",$o_ssc_inn->modulos);
			if(!in_array(8,$arrsscinn)){
				show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
			}
		}
    }
	
	private function all_config_ci($a='') {
		//pedido --- id_pedido,usuario,tipo_precio,bordados,fecha_entrega,pago,costo,abonado,estado
		$out = '';
		switch ($a){
			case 'session_role': $out='ormufss_user';break;
			case 'url_views': $out='reporte_operario';break;
			case 'url_controller': $out='reporte_operario';break;
			case 'name_controller': $out='Reportes de Operarios';break;
			case 'table_name': $out ='pedido';break;
			case 'o_id': $out='id_pedido';break;
			case 'o_required': $out=array('nombre' => 'Nombre');break;
			case 'o_unique_check': $out=array('ninguno');break;
			default: $out = '';
		}
		return $out;
    }

	public function index()	{
		$this->is_logged();
		$sr_session_role = $this->all_config_ci('session_role');
		$r_idd = $this->session->$sr_session_role->rol;
		$this->is_access();
		$this->load->helper('text');
		$data = array();
		$t_name = $this->all_config_ci('table_name');
		$t_id = $this->all_config_ci('o_id');
		$c_name = $this->all_config_ci('name_controller');
		$data['o_all'] = $this->default_model->default_get_all_elements_field_in_fss($t_name,'estado',array('tarea'),$t_id);
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['sr_session_role'] = $sr_session_role;
		$data['active_mod'] = $c_name;
		$data['title'] = 'Listado de '.$c_name;
		$data['title_page'] = 'Listado de '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/list', $data);
		$this->load->view('tpl/footer', $data);
	}
	
	public function details($id = '') {
		$this->is_logged();
		$this->is_access();
		if(empty($id)){
			redirect($this->all_config_ci('url_controller'));
		}
		$t_name = $this->all_config_ci('table_name');
		$c_name = $this->all_config_ci('name_controller');
		$o_id = $this->all_config_ci('o_id');
		$sr_session_role = $this->all_config_ci('session_role');
		$r_idd = $this->session->$sr_session_role->rol;
		$o = $this->default_model->default_get_one_where($t_name, array($o_id => $id));
		if(empty($o->$o_id)){
			$this->session->set_flashdata('msj_header_error_fss', 'Lo sentimos!!! '.$this->genClass.' '.$c_name.' '.$id.' no existe.');
			redirect($this->all_config_ci('url_controller'));
		} else {
			if($o->estado != 'tarea'){
				redirect($this->all_config_ci('url_controller'));
			}
		}
		$data['o'] = $o;
		$data['o_us'] = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $o->usuario));
		$data['select_b_all'] = $this->default_model->default_get_all_where('categoria_producto',array('estado' => 'activo'));
		
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = $c_name;
		$data['title'] = 'Adicionar '.$c_name;
		$data['title_page'] = 'Adicionar '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/details', $data);
		$this->load->view('tpl/footer', $data);
    }
}