<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Caja extends CI_Controller {
	
	private function all_config_ci($a='') {
		//recibo_caja   ---  id_recibo_caja,usuario,cincuenta,cien,doscientos,quinientos,mil,dosmil,cincomil,diezmil,veintemil,cincuentamil,cienmil,total,categoria,fecha,estado
		$out = '';
		switch ($a){
			case 'session_role': $out='ormufss_user';break;
			case 'url_views': $out='caja';break;
			case 'url_controller': $out='caja';break;
			case 'name_controller': $out='Recibos de Caja';break;
			case 'table_name': $out ='recibo_caja';break;
			case 'o_id': $out='id_recibo_caja';break;
			case 'o_date_current': $out=date('Y-m-d');break;
			case 'o_list': $out=array('codigo' => 'C&oacute;digo','nombre' => 'Nombre','cantidad' => 'Cantidad','costo' => 'Costo','precio' => 'Precio','iva' => 'IVA','proveedor' => 'Proveedor','estado' => 'Estado');break;
			case 'o_required': $out=array('nombre' => 'Nombre','costo' => 'Costo','precio' => 'Precio');break;
			default: $out = '';
		}
		return $out;
    }
	
	function is_logged() {
		$sr_session_role = $this->all_config_ci('session_role');
        if (!@$this->session->userdata($sr_session_role))
            redirect('login');
    }

    function is_access($role=array()) {
        $sr_session_role = $this->all_config_ci('session_role');
		$permissions = empty($role)?array('administrator','empleado'):$role;
		if (@$this->session->userdata($sr_session_role) and !in_array($this->session->$sr_session_role->rol,$permissions))
            show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
    }

	public function index() {
		$this->is_logged();
		$this->is_access();
		$this->load_date();
		$sr_session_role = $this->all_config_ci('session_role');
        $data = array();
		
		$d_date = '';
		$d_start = '';
		$d_end = '';
		$arr_data_range = $this->session->flashdata('fechas_nn_fss');
		if(!empty($arr_data_range)){
			$d_date = $arr_data_range[0];
			$this->session->keep_flashdata('fechas_nn_fss');
		} else {
			$d_date = date('Y-m');
		}
		$arr_date = explode("-",$d_date);
		$yy = $arr_date[0];
		$mm = $arr_date[1];
		if(substr($mm,0) == '0'){
			$mm = substr($mm,1);
		}
		$max_days = date('t', mktime(0, 0, 0, $mm, 1, $yy));
		$d_start = $yy.'-'.$mm.'-01';
		$d_end = $yy.'-'.$mm.'-'.$max_days;
		$data['d_date'] = $d_date;
		$values_w = array('fecha >=' => $d_start,'fecha <=' => $d_end,'estado' => 'activo');
		if($this->session->$sr_session_role->rol == 'empleado') {
			$values_w = array('usuario' => $this->session->$sr_session_role->id_usuario,'fecha >=' => $d_start,'fecha <=' => $d_end,'estado' => 'activo');
		}
		$data['o_all'] = $this->default_model->default_get_all_where_order_by($this->all_config_ci('table_name'),'id_recibo_caja asc',$values_w);
        
		$data['session_role'] = $sr_session_role;
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $this->all_config_ci('o_id');
		$data['active_mod'] = 'Caja';
		$data['title'] = 'Reportes de Caja';
		$data['title_page'] = 'Reportes de Caja';
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = 'Caja';
		$values_inicio = array('usuario' => $this->session->$sr_session_role->id_usuario,'categoria' => 'inicio','fecha' => date('Y-m-d'),'estado' => 'activo');
		$o_is_inicio_caja = $this->default_model->default_get_one_where('recibo_caja', $values_inicio);
		$data['o_inicio_caja'] = empty($o_is_inicio_caja->id_recibo_caja);
		$values_cierre = array('usuario' => $this->session->$sr_session_role->id_usuario,'categoria' => 'cierre','fecha' => date('Y-m-d'),'estado' => 'activo');
		$o_is_cierre_caja = $this->default_model->default_get_one_where('recibo_caja', $values_cierre);
		$data['o_cierre_caja'] = (!empty($o_is_inicio_caja->id_recibo_caja) AND empty($o_is_cierre_caja->id_recibo_caja));
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/list', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	public function load_date() {
		if(!empty($_POST)){
			if($this->session->flashdata('fechas_nn_fss')){
				$this->session->set_flashdata('fechas_nn_fss', array($_POST['d_date']));
			} else {
				$this->session->mark_as_flash('fechas_nn_fss');
				$this->session->set_flashdata('fechas_nn_fss', array($_POST['d_date']));
			}
		}
    }
	
	//Procesos de Caja
	public function ad_inicio_caja() {
		//recibo_caja   ---  id_recibo_caja,usuario,cincuenta,cien,doscientos,quinientos,mil,dosmil,cincomil,diezmil,veintemil,cincuentamil,cienmil,total,categoria,fecha,estado
		$sr_session_role = $this->all_config_ci('session_role');
		$values = array('usuario' => $this->session->$sr_session_role->id_usuario,'total' => $_POST['valor'],'categoria' => 'inicio','fecha' => date('Y-m-d'),'estado' => 'activo');
		$new = $this->default_model->default_insert_one('recibo_caja', $values);
		echo 'ok';
    }
	
	public function ad_cierre_caja() {
		//recibo_caja   ---  id_recibo_caja,usuario,cincuenta,cien,doscientos,quinientos,mil,dosmil,cincomil,diezmil,veintemil,cincuentamil,cienmil,total,categoria,fecha,estado
		$sr_session_role = $this->all_config_ci('session_role');
		$t=0;
		$cincuenta = !empty($_POST['cincuenta'])?$_POST['cincuenta']:0;
		$t += $cincuenta * 50;
		$cien = !empty($_POST['cien'])?$_POST['cien']:0;
		$t += $cien * 100;
		$doscientos = !empty($_POST['doscientos'])?$_POST['doscientos']:0;
		$t += $doscientos * 200;
		$quinientos = !empty($_POST['quinientos'])?$_POST['quinientos']:0;
		$t += $quinientos * 500;
		$mil = !empty($_POST['mil'])?$_POST['mil']:0;
		$t += $mil * 1000;
		$dosmil = !empty($_POST['dosmil'])?$_POST['dosmil']:0;
		$t += $dosmil * 2000;
		$cincomil = !empty($_POST['cincomil'])?$_POST['cincomil']:0;
		$t += $cincomil * 5000;
		$diezmil = !empty($_POST['diezmil'])?$_POST['diezmil']:0;
		$t += $diezmil * 10000;
		$veintemil = !empty($_POST['veintemil'])?$_POST['veintemil']:0;
		$t += $veintemil * 20000;
		$cincuentamil = !empty($_POST['cincuentamil'])?$_POST['cincuentamil']:0;
		$t += $cincuentamil * 50000;
		$cienmil = !empty($_POST['cienmil'])?$_POST['cienmil']:0;
		$t += $cienmil * 100000;
		
		$values = array('usuario' => $this->session->$sr_session_role->id_usuario,'cincuenta' => $cincuenta,'cien' => $cien,'doscientos' => $doscientos,'quinientos' => $quinientos,'mil' => $mil,'dosmil' => $dosmil,'cincomil' => $cincomil,'diezmil' => $diezmil,'veintemil' => $veintemil,'cincuentamil' => $cincuentamil,'cienmil' => $cienmil,'total' => $t,'categoria' => 'cierre','fecha' => date('Y-m-d'),'estado' => 'activo');
		$new = $this->default_model->default_insert_one('recibo_caja', $values);
		echo $this->cart->format_number($t);
    }
	
	public function get_inicio_caja() {
		$sr_session_role = $this->all_config_ci('session_role');
		$values_inicio = array('usuario' => $this->session->$sr_session_role->id_usuario,'categoria' => 'inicio','fecha' => date('Y-m-d'),'estado' => 'activo');
		$o_is_inicio_caja = $this->default_model->default_get_one_where('recibo_caja', $values_inicio);
		echo $this->cart->format_number($o_is_inicio_caja->total);
    }
	
	public function get_vendido_caja() {
		$sr_session_role = $this->all_config_ci('session_role');
		$sql_total="SELECT sum(total) as subtotal FROM `ingreso` WHERE fecha ='".date('Y-m-d')."' && tipo='efectivo' && recibido_user=".$this->session->$sr_session_role->id_usuario;
		$t = $this->default_model->default_query_execute($sql_total)->row()->subtotal;
		echo $this->cart->format_number($t);
    }
}