<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Epayco extends CI_Controller {

	private $genClass = 'La';
	private $disClass = 'a';
	
	function is_logged() {
		$sr_session_role = $this->all_config_ci('session_role');
        if (!@$this->session->userdata($sr_session_role))
            redirect('login');
    }

    function is_access($role=array()) {
        $sr_session_role = $this->all_config_ci('session_role');
		$permissions = empty($role)?array('administrator'):$role;
		if (@$this->session->userdata($sr_session_role) and !in_array($this->session->$sr_session_role->rol,$permissions))
            show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
    }
	
	private function all_config_ci($a='') {
		//epayco_fss --- id_epayco_fss,public_key,p_key,p_cust_id_cliente,moneda,test
		$out = '';
		switch ($a){
			case 'session_role': $out='bnbn_user';break;
			case 'url_views': $out='epayco';break;
			case 'url_controller': $out='epayco';break;
			case 'name_controller': $out='Epayco';break;
			case 'table_name': $out ='epayco_fss';break;
			case 'o_id': $out='id_epayco_fss';break;
			case 'o_required': $out=array('public_key' => 'public_key','p_key' => 'p_key','p_cust_id_cliente' => 'p_cust_id_cliente','test' => 'Modo');break;
			case 'o_unique_check': $out=array('ninguno');break;
			default: $out = '';
		}
		return $out;
    }

	public function index()	{
		show_error('You have not assigned the appropriate permissions to access this url.', 400, 'Access denied!');
	}

	public function response(){
		$this->load->view($this->all_config_ci('url_views').'/response_view');
	}

	public function success(){
		$this->load->view($this->all_config_ci('url_views').'/success');
	}
	
	public function update() {
		$this->is_logged();
		$this->is_access();
		$id=1;
		if(empty($id)){
			redirect($this->all_config_ci('url_controller'));
		}
		$t_name = $this->all_config_ci('table_name');
		$o_id = $this->all_config_ci('o_id');
		$c_name = $this->all_config_ci('name_controller');
		$o_required = $this->all_config_ci('o_required');
		$o = $this->default_model->default_get_one_where($t_name, array($o_id => $id));
		if(empty($o->$o_id)){
			$this->session->set_flashdata('msj_header_error_fss', 'Lo sentimos!!! '.$this->genClass.' '.$c_name.' '.$id.' no existe.');
			redirect($this->all_config_ci('url_controller'));
		}
		$this->load->helper(array('form'));
		$this->load->library('form_validation');
		if(count($o_required) > 0){
			foreach($o_required as $key => $row){
				$this->form_validation->set_rules($key, '<em>'.$row.'</em>', 'trim|required');
			}
		}
        if (!empty($_POST)) {
            if ($this->form_validation->run() == TRUE) {
				$values = array();
				foreach($_POST as $key => $row){
					$values[$key] = $row;
				}
				$updt = $this->default_model->default_update($t_name, $o_id, $id, $values);
				$this->session->set_flashdata('msj_header_fss', 'En hora buena!!! Las configuraciones de Epayco han sido guardadas correctamente.');
				redirect($this->all_config_ci('url_controller').'/update');
            }
        }
		$data['o'] = $o;
		$data['o_disabled'] = false;
		$data['controller'] = $this->all_config_ci('url_controller');
		$data['id_o'] = $o_id;
		$data['active_mod'] = $c_name;
		$data['title'] = 'Actualizar '.$c_name;
		$data['title_page'] = 'Actualizar '.$c_name;
		$data['title_breadcrumb'] = 'Inicio';
		$data['title_breadcrumb_active'] = $c_name;
		$this->load->view('tpl/header', $data);
		$this->load->view($this->all_config_ci('url_views').'/update', $data);
		$this->load->view('tpl/footer', $data);
    }
	
	public function start_mod_fss(){
		if (!($this->db->table_exists('epayco_fss'))) {
			//epayco_fss --- id_epayco_fss,public_key,p_key,p_cust_id_cliente,moneda,test
            $sql = "CREATE TABLE IF NOT EXISTS `epayco_fss` (`id_epayco_fss` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`public_key` varchar(300),`p_key` varchar(300),`p_cust_id_cliente` varchar(300),`moneda` varchar(50),`test` varchar(50),UNIQUE KEY `id_epayco_fss` (`id_epayco_fss`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
			$values = array('public_key' => '382c096da3f1534fc1af6f0d62361710','p_key' => '1897ccc8f9ac215a76007312c996d7ab96334088','p_cust_id_cliente' => '19473','moneda' => 'cop','test' => 'true');
			$this->default_model->default_insert_one("epayco_fss", $values);
        }
	}

	public function start_tranx_fss($arr=array()){
		if (!($this->db->table_exists('test_payco'))) {
			$sql = "CREATE TABLE IF NOT EXISTS `test_payco` (`id_test_payco` bigint(20) unsigned NOT NULL AUTO_INCREMENT,`x_ref_payco` varchar(280),`estado` varchar(80),`c_fss` varchar(80),UNIQUE KEY `id_test_payco` (`id_test_payco`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
            $this->db->query($sql);
			$fields_x = $this->db->list_fields('test_payco');
			foreach($arr as $cp){
				if(!in_array($cp,$fields_x)){
					$this->default_model->add_column('test_payco',$cp,'text');
				}
			}
		}
	}
	
	public function confirmation(){
		$this->start_mod_fss();
		$t_name = $this->all_config_ci('table_name');
		$o_id = $this->all_config_ci('o_id');
		$epayco_fss = $this->default_model->default_get_one_where($t_name, array($o_id => 1));
		$p_cust_id_cliente = $epayco_fss->p_cust_id_cliente;
		$p_key             = $epayco_fss->p_key;
		$x_ref_payco      = $_REQUEST['x_ref_payco'];
		$x_transaction_id = $_REQUEST['x_transaction_id'];
		$x_amount         = $_REQUEST['x_amount'];
		$x_currency_code  = $_REQUEST['x_currency_code'];
		$x_signature      = $_REQUEST['x_signature'];
		$signature = hash('sha256', $p_cust_id_cliente . '^' . $p_key . '^' . $x_ref_payco . '^' . $x_transaction_id . '^' . $x_amount . '^' . $x_currency_code);
		$x_response     = $_REQUEST['x_response'];
		$x_motivo       = $_REQUEST['x_response_reason_text'];
		$x_id_invoice   = $_REQUEST['x_id_invoice'];
		$x_autorizacion = $_REQUEST['x_approval_code'];
		$this->start_tranx_fss($_REQUEST);
		//Validamos la firma
		if ($x_signature == $signature) {
			$x_cod_response = $_REQUEST['x_cod_response'];
			switch ((int) $x_cod_response) {
				case 1:
					//echo "transacción aceptada";exit();
					$this->pro_confirmation($_REQUEST);
					break;
				case 2:
					//code transacción rechazada
					echo "transacción rechazada";exit();
					break;
				case 3:
					//code transacción pendiente
					echo "transacción pendiente";exit();
					break;
				case 4:
					//code transacción fallida
					echo "transacción fallida";exit();
					break;
			}
		} else {
			die("Firma no valida");
		}
	}

	public function go_fss($url){
		$url = str_replace('-','/',$url);
		redirect($url);
	}

	public function test_payco(){
		echo 'Pago finalizado';
	}

	//confirm server only
	public function pro_confirmation($arr_req){
		$arr_data = array();
		if(!empty($arr_req)){
			foreach($arr_req as $key => $row){
				$arr_data[$key] = $row;
			}
		}
		$params = array('referencia' => $arr_data['x_id_invoice'],'recibo' => $arr_data['x_transaction_id'],'ref_payco' => $arr_data['x_ref_payco'],'extra1' => $arr_data['x_extra1'],'extra2' => $arr_data['x_extra2'],'extra3' => $arr_data['x_extra3'],'monto' => $arr_data['amount_ok'],'moneda' => $arr_data['x_currency_code'],'respuesta' => $arr_data['x_response']);
		if(!empty($params['extra1'])){
			$func = 'pro_data_'.$params['extra1'];
			$resp =  $this->$func($params);
			$arr_data['estado'] = 'completado';
			$arr_data['c_fss'] = 'verificado';
			$last_payco = $this->default_model->default_insert_one_get_id("test_payco", $arr_data);
		}
	}

	public function pro_data($pms=''){
		$params = array('referencia' => $_POST['referencia'],'recibo' => $_POST['recibo'],'ref_payco' => $_POST['ref_payco'],'extra1' => $_POST['extra1'],'extra2' => $_POST['extra2'],'extra3' => $_POST['extra3'],'monto' => $_POST['monto'],'moneda' => $_POST['moneda'],'respuesta' => $_POST['respuesta']);
		if(!empty($params['extra1'])){
			$func = 'pro_data_'.$params['extra1'];
			$resp =  $this->$func($params);
			echo 'Ok';
		}
	}

	public function pro_data_prereserva_fss($params){
		$o = $this->default_model->default_get_one_where('reserva', array('id_reserva' => $params['extra2']));
		if(!empty($o->id_reserva)){
			if($o->estado_pago=='Aceptada'){
				return 'exist';
			} else {
				if($params['respuesta']=='Aceptada'){
					$upd = $this->default_model->default_update('reserva', 'id_reserva', $params['extra2'], array('referencia' => $params['referencia'],'recibo' => $params['recibo'],'estado_pago' => 'Aceptada','estado' => 'activo'));
					$o_sv_row = $this->default_model->default_get_one_where('plan', array('id_plan' => $o->producto));
					$cc_total = $o_sv_row->precio;
					
					$cc_total = ($o_sv_row->precio*$o->porciento)/100;
					
					$updt = $this->default_model->default_update('reserva', 'id_reserva', $o->id_reserva, array('abono' => $cc_total));
					//reserva_abono --- id_reserva_abono,reserva,valor,estado
					$values = array('reserva' => $o->id_reserva,'valor' => $cc_total,'estado' => 'activo');
					$n_last = $this->default_model->default_insert_one_get_id('reserva_abono', $values);
					
					
					$this->ad_ingr_fss($params['extra2'],$o->nombre,$cc_total,$params['extra3']);
					return $params['extra2'];
				}
			}
		} else {
			return 'exist';
		}
	}
	
	public function ad_ingr_fss($id_objeto,$pagado_por,$total,$id_us) {
		//ingreso --- id_ingreso,recibo,pagado_por,pagado_a,recibido_por,descripcion,valor,subtotal,impuesto,total,fecha,id_objeto,linea,estado
		$us = $this->default_model->default_get_one_where('usuario', array('id_usuario' => $id_us));
		$values = array('recibo' => '','pagado_por' => $pagado_por,'pagado_a' => 'Cataleya Spa','recibido_por' => $us->nombre.' '.$us->apellido,'recibido_user' => $us->id_usuario,'descripcion' => 'Abono Reserva','valor' => 0,'subtotal' => 0,'impuesto' => 0,'total' => $total,'fecha' => date('Y-m-d'),'id_objeto' => $id_objeto,'linea' => 'Spa','tipo' => 'epayco','estado' => 'activo');
		$n_last = $this->default_model->default_insert_one_get_id('ingreso', $values);
	}
}